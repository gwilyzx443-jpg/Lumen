package dev.lumen.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

public final class RenderUtil {
    private RenderUtil() {}

    /** Projektoru kameranin o anki konumu, bakis acisi ve FOV degeri ile ayarlar. */
    public static void begin(Projector p, MinecraftClient mc, int w, int h) {
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d pos = cam.getCameraPos();
        p.view(pos.x, pos.y, pos.z, cam.getYaw(), cam.getPitch(), mc.options.getFov().getValue(), w, h);
    }
}
