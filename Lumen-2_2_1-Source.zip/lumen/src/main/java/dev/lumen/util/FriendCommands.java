package dev.lumen.util;

import dev.lumen.Lumen;
import dev.lumen.core.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.List;

/** ".f add|remove|list" sohbet komutlarini yakalar; mantik FriendsManager.execute icindedir. */
public final class FriendCommands {
    private FriendCommands() {}

    /** true: mesaj bir ".f" komutuydu ve islendi (sunucuya/sohbete gonderilmemeli). */
    public static boolean handle(MinecraftClient mc, String message) {
        List<String> lines = FriendsManager.execute(message);
        if (lines == null) return false;
        if (mc.player != null) {
            for (String line : lines) mc.player.sendMessage(Text.literal(line), false);
        }
        Config.saveIfDirty(Lumen.MODULES); // liste hemen diske yazilsin (oyun cokse bile kaybolmasin)
        return true;
    }
}
