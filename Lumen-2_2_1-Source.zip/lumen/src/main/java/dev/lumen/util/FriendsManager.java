package dev.lumen.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Merkezi arkadas listesi: tum Combat modulleri hedef secerken bu sinifa (TargetManager.isValid uzerinden) bakar.
 * Minecraft'a bagimli degildir; bu yuzden tek basina test edilebilir.
 *
 * <p>Esleme buyuk/kucuk harf duyarsizdir. Oyuncular ve ozel adi olan varliklar (isim etiketi) isimle eslesir;
 * adsiz moblar (ornegin "Zombie") hicbir zaman arkadas sayilmaz.
 */
public final class FriendsManager {
    public static final int MAX_FRIENDS = 200;
    public static final int MAX_NAME = 32;
    /** Harf, rakam, alt cizgi, bosluk, nokta, kesme, tire. ',' ve '=' yok: dosya bicimini bozamaz. */
    private static final Pattern VALID = Pattern.compile("[\\p{L}\\p{N}_ .'\\-]{1," + MAX_NAME + "}");

    public enum Result { ADDED, REMOVED, DUPLICATE, NOT_FOUND, INVALID, FULL }

    /** anahtar (kucuk harf) -> ilk yazildigi haliyle isim; ekleme sirasi korunur. */
    private static final Map<String, String> friends = new LinkedHashMap<>();
    private static boolean protection = true;
    private static Runnable onChange = () -> { };
    private static String summaryCache;

    private FriendsManager() {}

    // ------------------------------------------------------------ durum

    /** Liste degisince cagrilir (ayar dosyasini "kirli" isaretlemek icin). */
    public static void setOnChange(Runnable r) {
        onChange = r == null ? () -> { } : r;
    }

    public static boolean protectionOn() {
        return protection;
    }

    public static void setProtection(boolean on) {
        protection = on;
    }

    public static int count() {
        return friends.size();
    }

    public static boolean isEmpty() {
        return friends.isEmpty();
    }

    public static List<String> list() {
        return new ArrayList<>(friends.values());
    }

    /** GUI icin tek satirlik ozet; liste degisince yeniden uretilir. */
    public static String summary() {
        if (summaryCache == null) summaryCache = friends.isEmpty() ? "-" : String.join(", ", friends.values());
        return summaryCache;
    }

    // ------------------------------------------------------------ islemler

    private static String key(String raw) {
        return raw.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    private static String display(String raw) {
        return raw.trim().replaceAll("\\s+", " ");
    }

    public static Result add(String raw) {
        if (raw == null) return Result.INVALID;
        String shown = display(raw);
        if (!VALID.matcher(shown).matches()) return Result.INVALID;
        String k = key(shown);
        if (friends.containsKey(k)) return Result.DUPLICATE;
        if (friends.size() >= MAX_FRIENDS) return Result.FULL;
        friends.put(k, shown);
        changed();
        return Result.ADDED;
    }

    public static Result remove(String raw) {
        if (raw == null || raw.isBlank()) return Result.INVALID;
        if (friends.remove(key(raw)) == null) return Result.NOT_FOUND;
        changed();
        return Result.REMOVED;
    }

    /** Ham isim arkadas listesinde mi? (Koruma acik/kapali bilgisine bakmaz.) */
    public static boolean isFriend(String name) {
        if (name == null || friends.isEmpty()) return false;
        return friends.containsKey(key(name));
    }

    /** Koruma aciksa ve isim listedeyse true: hedef secimi bu varligi atlamali. */
    public static boolean isProtected(String name) {
        return protection && isFriend(name);
    }

    private static void changed() {
        summaryCache = null;
        onChange.run();
    }

    // ------------------------------------------------------------ kalicilik

    /** Config dosyasina yazilacak deger: "a,b,c". */
    public static String serialize() {
        return String.join(",", friends.values());
    }

    /**
     * Config'ten yukler. Bozuk/tekrarlayan/gecersiz girdiler sessizce atlanir; en fazla MAX_FRIENDS.
     * Yukleme "degisiklik" sayilmaz (onChange cagrilmaz).
     */
    public static void deserialize(String raw) {
        friends.clear();
        summaryCache = null;
        if (raw == null) return;
        for (String part : raw.split(",")) {
            if (friends.size() >= MAX_FRIENDS) break;
            String shown = display(part);
            if (!VALID.matcher(shown).matches()) continue;
            friends.putIfAbsent(key(shown), shown);
        }
    }

    // ------------------------------------------------------------ sohbet komutlari

    public static String describe(Result r, String name) {
        String n = name == null ? "" : display(name);
        return switch (r) {
            case ADDED -> "Arkadas eklendi: " + n;
            case REMOVED -> "Arkadas silindi: " + n;
            case DUPLICATE -> "Zaten arkadas listesinde: " + n;
            case NOT_FOUND -> "Arkadas listesinde yok: " + n;
            case INVALID -> "Gecersiz isim (harf, rakam, _ . ' - ve bosluk; en fazla " + MAX_NAME + " karakter).";
            case FULL -> "Arkadas listesi dolu (en fazla " + MAX_FRIENDS + ").";
        };
    }

    private static List<String> usage() {
        return List.of(".f add <isim>  |  .f remove <isim>  |  .f list");
    }

    /**
     * ".f add|remove|list" komutunu calistirir ve ekrana yazilacak satirlari dondurur.
     * Mesaj bir ".f" komutu degilse null dondurur (normal sohbet mesaji olarak gonderilir).
     */
    public static List<String> execute(String message) {
        if (message == null) return null;
        String[] parts = message.trim().split("\\s+", 3);
        if (!parts[0].equalsIgnoreCase(".f")) return null;
        if (parts.length < 2) return usage();
        String arg = parts.length > 2 ? parts[2] : "";
        switch (parts[1].toLowerCase(Locale.ROOT)) {
            case "add":
                return arg.isBlank() ? usage() : List.of(describe(add(arg), arg));
            case "remove":
                return arg.isBlank() ? usage() : List.of(describe(remove(arg), arg));
            case "list": {
                String state = protection ? "ACIK" : "KAPALI";
                if (friends.isEmpty()) return List.of("Arkadas listesi bos. (Koruma: " + state + ")");
                return List.of("Arkadaslar (" + friends.size() + "), Koruma: " + state, String.join(", ", friends.values()));
            }
            default:
                return usage();
        }
    }
}
