package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.FriendsManager;
import net.minecraft.text.Text;

/**
 * Friends Protection: modul ACIKken arkadaslar hicbir Combat modulunun hedefi olmaz.
 * Liste ".f add/remove/list" komutlariyla ya da bu ayar ekranindan yonetilir; asil liste FriendsManager'dadir.
 * Liste bu modulun ayar dosyasina (config/lumen/friends.properties) kaydedilir.
 */
public final class Friends extends Feature {
    private final Setting.Info protection = add(new Setting.Info("Friends Protection",
            () -> FriendsManager.protectionOn() ? "ON" : "OFF"));
    private final Setting.Info count = add(new Setting.Info("Friend Count",
            () -> String.valueOf(FriendsManager.count())));
    private final Setting.Info listing = add(new Setting.Info("Friends List",
            FriendsManager::summary, FriendsManager::deserialize, FriendsManager::serialize));
    private final Setting.Text input = add(new Setting.Text("Friend Name", "", 16));
    private final Setting.Button addBtn = add(new Setting.Button("Add Friend", this::addFriend));
    private final Setting.Button removeBtn = add(new Setting.Button("Remove Friend", this::removeFriend));

    public Friends() {
        super("Friends", "Friends Protection: arkadaslar Combat hedefi olmaz (.f add / remove / list).", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        FriendsManager.setProtection(true);
    }

    @Override
    protected void onDisable() {
        FriendsManager.setProtection(false);
    }

    private void addFriend() {
        String name = input.get();
        FriendsManager.Result r = FriendsManager.add(name);
        if (r == FriendsManager.Result.ADDED) input.set("");
        say(FriendsManager.describe(r, name));
    }

    private void removeFriend() {
        String name = input.get();
        FriendsManager.Result r = FriendsManager.remove(name);
        if (r == FriendsManager.Result.REMOVED) input.set("");
        say(FriendsManager.describe(r, name));
    }

    private void say(String message) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(message), false);
    }
}
