package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import dev.lumen.util.Projector;
import dev.lumen.util.RenderUtil;
import dev.lumen.util.TargetManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Yalnizca yerel tek oyunculu dunyada (baska oyuncu yokken) ve yalnizca oyuncu olmayan varliklara
 * kamerayi yumusakca cevirir. Diger ortamlarda hicbir sey yapmaz.
 */
public final class AimAssist extends HudFeature {
    // Genel
    private final Setting.Num speed = add(new Setting.Num("Aim Speed", 40, 1, 100, 1));
    private final Setting.Num smooth = add(new Setting.Num("Smoothness", 30, 1, 100, 1));
    private final Setting.Num fov = add(new Setting.Num("FOV", 90, 1, 180, 1));
    private final Setting.Num range = add(new Setting.Num("Target Range", 4.5, 1, 10, 0.5));
    private final Setting.Num hSens = add(new Setting.Num("Horizontal Sensitivity", 100, 0, 200, 5).unit("%"));
    private final Setting.Num vSens = add(new Setting.Num("Vertical Sensitivity", 100, 0, 200, 5).unit("%"));
    private final Setting.Mode point = add(new Setting.Mode("Aim Priority", "Body", "Head", "Body", "Feet"));
    private final Setting.Bool hudIntegration = add(new Setting.Bool("Target HUD Integration", true));
    // Hedef kilidi
    private final Setting.Bool lock = add(new Setting.Bool("Target Lock", true));
    private final Setting.Bool showName = add(new Setting.Bool("Show Target Name", true));
    private final Setting.Bool lockIndicator = add(new Setting.Bool("Lock Indicator", true));
    private final Setting.Color indColor = add(new Setting.Color("Indicator Color", 0xE5484D));
    private final Setting.Bool clearOnLoss = add(new Setting.Bool("Clear Lock When Lost", true));
    private final Setting.Button lockBtn = add(new Setting.Button("Lock Crosshair Target", () -> TargetManager.lockCrosshair(mc)));
    private final Setting.Button clearBtn = add(new Setting.Button("Clear Target", TargetManager::clear));
    // Hedef filtreleri (Target Lock kapaliyken otomatik secim icin)
    private final Setting.Mode priority = add(new Setting.Mode("Target Priority", "Closest", "Closest", "Lowest Health", "Crosshair"));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    private final Setting.Bool hostileOnly = add(new Setting.Bool("Hostile Only", false));
    private final Setting.Bool invisible = add(new Setting.Bool("Invisible Entities", false));

    private final Projector proj = new Projector();
    private LivingEntity current, autoTarget;
    private boolean currentLocked;
    private String status = "Aim: idle";
    private int tickCount;
    private float dYaw, dPitch;

    public AimAssist() {
        super("Aim Assist", "Hedefe yumusak nisan (tek oyunculu, oyuncular haric). Kilitli hedef varsa onu, yoksa Target Lock kapaliyken filtrelere gore otomatik secer.", Category.COMBAT, 90, 32);
    }

    @Override
    protected void onEnable() {
        hint("Aim Assist: tek oyunculuda G ile hedef kilitle (Target Lock kapaliysa otomatik secer)");
    }

    @Override
    protected void onDisable() {
        reset();
    }

    @Override
    public void onWorldChange() {
        reset();
    }

    /** HUD'da gosterilen durum metni. */
    public String status() {
        return status;
    }

    private void reset() {
        current = null;
        autoTarget = null;
        currentLocked = false;
        tickCount = 0;
        status = "Aim: idle";
    }

    @Override
    public void onTick() {
        current = null;
        currentLocked = false;
        if (!TargetManager.isSafeWorld(mc)) {
            autoTarget = null;
            status = "Aim: singleplayer only";
            return;
        }
        if (mc.currentScreen != null) return;
        ClientPlayerEntity p = mc.player;
        LivingEntity locked = TargetManager.get(mc);

        LivingEntity t;
        if (locked != null) {
            // Ortak hedef: kilitli hedef varsa (Target Lock acik ya da kapali) tum moduller ayni hedefi kullanir.
            t = locked;
            autoTarget = null;
            if (clearOnLoss.get() && p.distanceTo(t) > range.get() * 1.5) {
                TargetManager.clear(); // hedef menzilden cikti: kilidi temizle
                t = null;
            }
        } else if (lock.get()) {
            t = null; // Target Lock acik: kullanici hedef kilitleyene kadar bekle
            autoTarget = null;
        } else {
            if (autoTarget != null && (!TargetManager.isValid(mc, autoTarget) || p.distanceTo(autoTarget) > range.get())) {
                autoTarget = null;
            }
            if (++tickCount % 3 == 0) autoTarget = pickAuto();
            t = autoTarget;
        }
        if (t == null) {
            status = lock.get() ? "Aim: lock a target (G)" : "Aim: searching...";
            return;
        }

        current = t;
        currentLocked = t == locked;
        String name = t.getName().getString();
        status = "Aim: " + name + (currentLocked ? " [LOCK]" : " [AUTO]");
        if (hudIntegration.get()) TargetManager.setAssist(t);
        if (p.distanceTo(t) > range.get()) {
            status += " (out of range)";
            return;
        }

        deltas(t);
        if (Math.hypot(dYaw, dPitch) > fov.get() / 2.0) { // gorus alani disinda
            status += " (outside FOV)";
            return;
        }

        float f = (float) Math.min(1.0, speed.get() / 100.0 / (1.0 + smooth.get() / 10.0));
        float sy = MathHelper.clamp(dYaw * f * (float) (hSens.get() / 100.0), -20f, 20f);
        float sp = MathHelper.clamp(dPitch * f * (float) (vSens.get() / 100.0), -20f, 20f);
        p.setYaw(p.getYaw() + sy);
        p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90f, 90f));
    }

    /** dYaw / dPitch alanlarini hedefe gore ayarlar. */
    private void deltas(LivingEntity t) {
        ClientPlayerEntity p = mc.player;
        double frac = point.is("Head") ? 0.9 : point.is("Body") ? 0.55 : 0.1;
        Vec3d eye = p.getEyePos();
        double dx = t.getX() - eye.x;
        double dy = t.getY() + t.getHeight() * frac - eye.y;
        double dz = t.getZ() - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        dYaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        dPitch = pitch - p.getPitch();
    }

    private LivingEntity pickAuto() {
        if (!mobs.get()) return null;
        ClientPlayerEntity p = mc.player;
        double r = range.get();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().expand(r), x -> TargetManager.isValid(mc, x))) {
            LivingEntity le = (LivingEntity) e;
            if (hostileOnly.get() && !(le instanceof Monster)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            double d = p.distanceTo(le);
            if (d > r) continue;
            deltas(le);
            double ang = Math.hypot(dYaw, dPitch);
            if (ang > fov.get() / 2.0) continue;
            double score = priority.is("Lowest Health") ? le.getHealth() : priority.is("Crosshair") ? ang : d;
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (showName.get()) Draw.label(ctx, mc.textRenderer, status, px(), py());
        if (current == null) return;
        if (lockIndicator.get() && current.isAlive()) {
            RenderUtil.begin(proj, mc, w, h);
            if (proj.project(current.getX(), current.getY() + current.getHeight() / 2.0, current.getZ())) {
                double half = Math.max(5.0, Math.min(90.0,
                        proj.pixelsPerBlock() * Math.max(current.getWidth(), current.getHeight()) * 0.6));
                Draw.outline(ctx, (int) (proj.sx - half), (int) (proj.sy - half),
                        (int) (proj.sx + half), (int) (proj.sy + half), 2, 0xFF000000 | indColor.rgb());
            }
        }
    }
}
