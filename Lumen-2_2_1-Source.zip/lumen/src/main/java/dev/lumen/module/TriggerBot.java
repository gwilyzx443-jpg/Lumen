package dev.lumen.module;

import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.ChanceModel;
import dev.lumen.util.Clicks;
import dev.lumen.util.Draw;
import dev.lumen.util.Projector;
import dev.lumen.util.RenderUtil;
import dev.lumen.util.TargetManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Otomatik saldiri: yalnizca yerel tek oyunculu dunyada, oyuncu olmayan varliklara.
 * Istatistik (kendi vuruslarin), cooldown gostergesi, CPS ve gorsel isaret her dunyada calisir;
 * bunlar hicbir saldiriyi kendiliginden yapmaz.
 */
public final class TriggerBot extends HudFeature {
    // Genel
    private final Setting.Num delay = add(new Setting.Num("Delay", 50, 0, 1000, 10).unit("ms"));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown", 100, 0, 1000, 10).unit("ms"));
    private final Setting.Bool weaponCd = add(new Setting.Bool("Weapon Cooldown", true));
    private final Setting.Bool cdDisplay = add(new Setting.Bool("Attack Cooldown Display", true));
    private final Setting.Mode filter = add(new Setting.Mode("Target Filter", "Hostile Mobs", "Hostile Mobs", "All Mobs", "Passive Mobs"));
    private final Setting.Bool targetOnly = add(new Setting.Bool("Target Only", true));
    private final Setting.Bool integration = add(new Setting.Bool("Target HUD Integration", true));
    // Hit chance
    private final Setting.Num hit = add(new Setting.Num("Hit Chance", 100, 0, 100, 1).unit("%"));
    private final Setting.Num miss = add(new Setting.Num("Miss Chance", 0, 0, 100, 1).unit("%"));
    private final Setting.Bool randomized = add(new Setting.Bool("Randomized Training Mode", false));
    private final Setting.Num randomness = add(new Setting.Num("Randomness", 20, 0, 50, 5).unit("%"));
    // Diger
    private final Setting.Bool indicator = add(new Setting.Bool("Visual Indicator", true));
    private final Setting.Bool showCps = add(new Setting.Bool("CPS Display", false));
    private final Setting.Bool showStats = add(new Setting.Bool("Show Statistics", true));
    private final Setting.Button lockBtn = add(new Setting.Button("Lock Crosshair Target", () -> TargetManager.lockCrosshair(mc)));
    private final Setting.Button resetBtn = add(new Setting.Button("Reset Statistics", this::resetStats));

    private final Projector proj = new Projector();
    private Entity acquired;
    private long acquiredAt, next;
    private int hits, misses, attempts;
    private String status = "Trigger: idle";

    public TriggerBot() {
        super("Trigger Bot", "Tek oyunculu: nisan alinan mob'a vurur (Target Only + Target Filter birlikte gecerli). Istatistik her dunyada.", Category.COMBAT, 200, 40);
    }

    /** HUD'da gosterilen durum metni. */
    public String status() {
        return status;
    }

    public int hits() {
        return hits;
    }

    public int misses() {
        return misses;
    }

    public int attempts() {
        return attempts;
    }

    @Override
    protected void onEnable() {
        hint("Trigger Bot: tek oyunculuda calisir; Target Only aciksa once G ile hedef kilitle");
    }

    @Override
    protected void onDisable() {
        clearState();
    }

    @Override
    public void onWorldChange() {
        clearState();
    }

    /** Eski hedef ve zamanlayicilar birakilir (istatistikler korunur). */
    private void clearState() {
        acquired = null;
        acquiredAt = 0L;
        next = 0L;
        status = "Trigger: idle";
    }

    private void resetStats() {
        hits = 0;
        misses = 0;
        attempts = 0;
    }

    /** Oyuncu kendisi sol tiklayinca (her dunyada) kendi isabet istatistigini tutar. */
    public void onManualAttack() {
        if (mc.player == null || mc.currentScreen != null) return;
        HitResult hr = mc.crosshairTarget;
        if (hr == null) return;
        if (hr.getType() == HitResult.Type.ENTITY && ((EntityHitResult) hr).getEntity() instanceof LivingEntity) {
            hits++;
            attempts++;
        } else if (hr.getType() == HitResult.Type.MISS) {
            misses++;
            attempts++;
        }
    }

    private boolean passes(Entity e) {
        boolean monster = e instanceof Monster;
        return switch (filter.get()) {
            case "All Mobs" -> true;
            case "Passive Mobs" -> !monster;
            default -> monster;
        };
    }

    private long jitter(int ms) {
        if (!randomized.get() || ms == 0) return ms;
        double f = 1.0 + (ThreadLocalRandom.current().nextDouble() * 2 - 1) * randomness.get() / 100.0;
        return Math.max(0L, Math.round(ms * f));
    }

    @Override
    public void onTick() {
        if (!TargetManager.isSafeWorld(mc)) { // otomatik saldiri yok; istatistik/gorsel calismaya devam eder
            acquired = null;
            status = "Trigger: singleplayer only (stats still work)";
            return;
        }
        miss.set(Math.min(miss.i(), ChanceModel.maxMiss(hit.i()))); // hit + miss <= 100
        if (mc.currentScreen != null || mc.interactionManager == null) {
            acquired = null; // ekran acikken hedef/zamanlayici tutulmaz (kapaninca gecikme bastan baslar)
            return;
        }

        LivingEntity locked = TargetManager.get(mc);
        Entity e = mc.crosshairTarget instanceof EntityHitResult ehr ? ehr.getEntity() : null;
        if (e == null || !TargetManager.isValid(mc, e)) {
            acquired = null;
            status = targetOnly.get() && locked == null
                    ? "Trigger: lock a target (G) or turn off Target Only" : "Trigger: armed (no target)";
            return;
        }
        // Target Only ve Target Filter birlikte gecerlidir: kilitli hedef de secili filtreden gecmelidir.
        if (targetOnly.get() && e != locked) {
            acquired = null;
            status = locked == null ? "Trigger: lock a target (G) or turn off Target Only"
                    : "Trigger: aim at the locked target";
            return;
        }
        if (!passes(e)) {
            acquired = null;
            status = "Trigger: filtered out (" + filter.get() + ")";
            return;
        }

        long now = System.currentTimeMillis();
        if (e != acquired) {
            acquired = e;
            acquiredAt = now;
        }
        status = "Trigger: on target " + e.getName().getString();
        if (integration.get()) TargetManager.setAssist((LivingEntity) e);
        if (now - acquiredAt < jitter(delay.i())) return; // tepki gecikmesi
        if (now < next) return;
        if (weaponCd.get() && mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
        next = now + jitter(cooldown.i());

        switch (ChanceModel.roll(hit.i(), miss.i(), ThreadLocalRandom.current().nextInt(100))) {
            case HIT -> {
                mc.interactionManager.attackEntity(mc.player, e);
                mc.player.swingHand(Hand.MAIN_HAND);
                hits++;
                attempts++;
                if (Lumen.AIM.isEnabled()) Lumen.AIM.record(true);
            }
            case MISS -> {
                mc.player.swingHand(Hand.MAIN_HAND); // bos savurma
                misses++;
                attempts++;
                if (Lumen.AIM.isEnabled()) Lumen.AIM.record(false);
            }
            case SKIP -> { }
        }
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (mc.player == null) return;
        var tr = mc.textRenderer;
        int x = px(), y = py();
        if (showStats.get()) {
            Draw.label(ctx, tr, status, x, y);
            y += 14;
            Draw.label(ctx, tr, "Hits: " + hits + "  Misses: " + misses, x, y);
            y += 14;
            String acc = attempts == 0 ? "--" : Math.round(100f * hits / attempts) + "%";
            Draw.label(ctx, tr, "Attempts: " + attempts + "  Accuracy: " + acc, x, y);
            y += 14;
        }
        if (showCps.get()) {
            Draw.label(ctx, tr, "CPS: " + Clicks.left(System.currentTimeMillis()), x, y);
            y += 14;
        }
        float prog = Math.max(0f, Math.min(1f, mc.player.getAttackCooldownProgress(0f)));
        if (cdDisplay.get()) {
            ctx.fill(x, y, x + 80, y + 8, Draw.BG);
            ctx.fill(x, y, x + (int) (80 * prog), y + 8, Draw.lerpColor(0xFFE5484D, 0xFF46C25B, prog));
        }
        if (indicator.get() && mc.crosshairTarget instanceof EntityHitResult ehr
                && ehr.getEntity() instanceof LivingEntity le && le.isAlive()) {
            RenderUtil.begin(proj, mc, w, h);
            if (proj.project(le.getX(), le.getY() + le.getHeight() / 2.0, le.getZ())) {
                double half = Math.max(6.0, Math.min(90.0,
                        proj.pixelsPerBlock() * Math.max(le.getWidth(), le.getHeight()) * 0.6));
                Draw.outline(ctx, (int) (proj.sx - half), (int) (proj.sy - half),
                        (int) (proj.sx + half), (int) (proj.sy + half), 2, prog >= 1f ? 0xFF46C25B : 0xFFE5484D);
            }
        }
    }
}
