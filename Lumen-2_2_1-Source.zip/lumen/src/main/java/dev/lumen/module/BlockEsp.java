package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.BlockGroups;
import dev.lumen.util.BlockScanner;
import dev.lumen.util.Draw;
import dev.lumen.util.Projector;
import dev.lumen.util.RenderUtil;
import dev.lumen.util.TargetManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;
import java.util.Set;

/** Secilen bloklari cerceve + etiketle isaretler (2B ekran cercevesi). Yalnizca yerel tek oyunculu dunyada. */
public final class BlockEsp extends Feature {
    private static final Set<String> DEFAULT_ON = Set.of("Chest", "Ender Chest", "Spawner", "Ancient Debris");
    private static final int MAX_LABELS = 30;

    private final BlockGroups.Group[] groups = BlockGroups.ESP;
    private final Setting.Num range = add(new Setting.Num("Range", 24, 8, 32, 4));
    private final Setting.Num thick = add(new Setting.Num("Line Thickness", 1, 1, 4, 1));
    private final Setting.Bool showName = add(new Setting.Bool("Show Name", true));
    private final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    private final Setting.Bool[] on = new Setting.Bool[groups.length];
    private final Setting.Color[] col = new Setting.Color[groups.length];
    private final boolean[] enabled = new boolean[groups.length];
    private final BlockScanner scanner = new BlockScanner(groups);
    private final Projector proj = new Projector();

    public BlockEsp() {
        super("Block ESP", "Secilen bloklari isaretler (sadece tek oyunculu).", Category.WORLD);
        for (int i = 0; i < groups.length; i++) {
            on[i] = add(new Setting.Bool(groups[i].name(), DEFAULT_ON.contains(groups[i].name())));
        }
        for (int i = 0; i < groups.length; i++) {
            col[i] = add(new Setting.Color(groups[i].name() + " Color", groups[i].color()));
        }
    }

    @Override
    public void onTick() {
        if (!TargetManager.isSafeWorld(mc)) return;
        for (int i = 0; i < enabled.length; i++) enabled[i] = on[i].get();
        scanner.tick(mc, range.i(), enabled, 6000);
    }

    @Override
    protected void onDisable() {
        scanner.reset();
    }

    @Override
    public void onWorldChange() {
        scanner.reset();
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (!TargetManager.isSafeWorld(mc)) return;
        List<BlockScanner.Hit> hits = scanner.hits();
        if (hits.isEmpty()) return;
        RenderUtil.begin(proj, mc, w, h);
        TextRenderer tr = mc.textRenderer;
        boolean labels = showName.get() || showDist.get();
        int t = thick.i();
        int labelsDrawn = 0;
        for (BlockScanner.Hit hit : hits) {
            if (!enabled[hit.group()]) continue;
            double cx = hit.x() + 0.5, cy = hit.y() + 0.5, cz = hit.z() + 0.5;
            double dSq = mc.player.squaredDistanceTo(cx, cy, cz);
            double r = range.get();
            if (dSq > r * r) continue;
            if (!proj.project(cx, cy, cz)) continue;
            double half = Math.max(3.0, Math.min(80.0, proj.pixelsPerBlock() * 0.5));
            int x1 = (int) (proj.sx - half), y1 = (int) (proj.sy - half);
            int x2 = (int) (proj.sx + half), y2 = (int) (proj.sy + half);
            if (x2 < 0 || y2 < 0 || x1 > w || y1 > h) continue;
            int color = 0xFF000000 | col[hit.group()].rgb();
            Draw.outline(ctx, x1, y1, x2, y2, t, color);
            if (labels && labelsDrawn < MAX_LABELS) {
                String text = showName.get() ? groups[hit.group()].name() : "";
                if (showDist.get()) text += (text.isEmpty() ? "" : " ") + Math.round(Math.sqrt(dSq)) + "m";
                ctx.drawText(tr, text, x1, y1 - 10, color, true);
                labelsDrawn++;
            }
        }
    }
}
