package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import dev.lumen.util.Projector;
import dev.lumen.util.RenderUtil;
import dev.lumen.util.TargetManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Egitim/simulasyon modu. Yalnizca yerel tek oyunculu dunyada ve yalnizca kilitli, oyuncu olmayan hedefe karsi.
 * "Simulation Only" aciksa hicbir sey yerlestirmez/vurmaz; plani ve tahmini hasari gosterir.
 * Kapaliysa (ve varsayilan olarak yalnizca Creative modunda) kristali gercekten yerlestirir ve kirar.
 */
public final class AutoCrystal extends HudFeature {
    private final Setting.Bool sim = add(new Setting.Bool("Simulation Only", true));
    private final Setting.Bool creative = add(new Setting.Bool("Require Creative", true));
    private final Setting.Num placeDelay = add(new Setting.Num("Place Delay", 150, 0, 1000, 10).unit("ms"));
    private final Setting.Num breakDelay = add(new Setting.Num("Break Delay", 100, 0, 1000, 10).unit("ms"));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown", 250, 0, 2000, 50).unit("ms"));
    private final Setting.Num range = add(new Setting.Num("Search Range", 3, 1, 5, 1));
    private final Setting.Bool indicator = add(new Setting.Bool("Show Indicator", true));

    private final Projector proj = new Projector();
    private BlockPos plan;
    private LivingEntity planTarget;
    private String status = "Idle";
    private String dmgText = "";
    private long nextPlace, nextBreak;

    public AutoCrystal() {
        super("Auto Crystal", "Egitim/simulasyon: kilitli hedefe kristal plani (tek oyunculu). Hasar tahmini yaklasiktir.", Category.COMBAT, 90, 18);
    }

    @Override
    protected void onEnable() {
        hint("Auto Crystal: G ile hedef kilitle; simulasyonda hicbir sey yerlestirilmez, hasar yaklasiktir");
    }

    @Override
    protected void onDisable() {
        reset();
    }

    @Override
    public void onWorldChange() {
        reset();
    }

    /** HUD'da gosterilen durum ve tahmini hasar metni. */
    public String status() {
        return status;
    }

    public String estimate() {
        return dmgText;
    }

    private void reset() {
        plan = null;
        planTarget = null;
        dmgText = "";
        status = "Idle";
        nextPlace = 0L;
        nextBreak = 0L;
    }

    @Override
    public void onTick() {
        plan = null;
        planTarget = null;
        dmgText = "";
        if (!TargetManager.isSafeWorld(mc)) {
            status = "Only in singleplayer";
            return;
        }
        if (mc.currentScreen != null || mc.interactionManager == null) {
            status = "Paused (screen open)";
            return;
        }
        LivingEntity t = TargetManager.get(mc);
        if (t == null) {
            status = "No target (lock with G)";
            return;
        }
        planTarget = t;
        ClientPlayerEntity p = mc.player;
        boolean act = !sim.get() && (!creative.get() || p.isCreative());
        if (!sim.get() && !act) {
            status = "Creative required";
            return;
        }
        long now = System.currentTimeMillis();

        // 1) hedefin yakinindaki kristali kir
        EndCrystalEntity crystal = nearestCrystal(t);
        if (crystal != null) {
            plan = crystal.getBlockPos();
            dmgText = damageText(crystal.getX(), crystal.getY(), crystal.getZ(), t);
            if (!act) {
                status = "SIM: break crystal";
            } else if (p.squaredDistanceTo(crystal) > 20.25) {
                status = "Crystal out of reach";
            } else if (now >= nextBreak) {
                mc.interactionManager.attackEntity(p, crystal);
                p.swingHand(Hand.MAIN_HAND);
                nextBreak = now + breakDelay.i();
                nextPlace = now + cooldown.i();
                status = "Breaking crystal";
            } else {
                status = "Waiting (break delay)";
            }
            return;
        }

        // 2) yerlestirilecek yeri bul
        BlockPos base = findPlacement(t, p);
        if (base == null) {
            status = "No obsidian/bedrock near target";
            return;
        }
        plan = base.up();
        dmgText = damageText(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5, t);
        Hand hand = p.getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.MAIN_HAND
                : p.getOffHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND : null;
        if (!act) {
            status = "SIM: place crystal";
        } else if (hand == null) {
            status = "Hold End Crystal";
        } else if (now >= nextPlace) {
            Vec3d hit = Vec3d.ofCenter(base).add(0.0, 0.5, 0.0);
            mc.interactionManager.interactBlock(p, hand, new BlockHitResult(hit, Direction.UP, base, false));
            p.swingHand(hand);
            nextPlace = now + placeDelay.i();
            status = "Placing crystal";
        } else {
            status = "Waiting (place delay)";
        }
    }

    private EndCrystalEntity nearestCrystal(LivingEntity t) {
        Box box = t.getBoundingBox().expand(range.get() + 2.0);
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, box, c -> true);
        EndCrystalEntity best = null;
        double bd = Double.MAX_VALUE;
        for (EndCrystalEntity c : list) {
            double d = c.squaredDistanceTo(t);
            if (d < bd) {
                bd = d;
                best = c;
            }
        }
        return best;
    }

    private BlockPos findPlacement(LivingEntity t, ClientPlayerEntity p) {
        BlockPos base = t.getBlockPos();
        int r = range.i();
        Vec3d eye = p.getEyePos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    BlockState st = mc.world.getBlockState(m);
                    if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) continue;
                    if (!mc.world.getBlockState(m.up()).isAir() || !mc.world.getBlockState(m.up(2)).isAir()) continue;
                    // yerlestirme kutusunda (1x2x1) varlik varsa kristal konamaz
                    Box spot = new Box(m.getX(), m.getY() + 1.0, m.getZ(), m.getX() + 1.0, m.getY() + 3.0, m.getZ() + 1.0);
                    if (!mc.world.getOtherEntities(null, spot, x -> true).isEmpty()) continue;
                    if (eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5) > 20.25) continue;
                    double d = t.squaredDistanceTo(m.getX() + 0.5, m.getY() + 1.0, m.getZ() + 0.5);
                    if (d < bestD) {
                        bestD = d;
                        best = m.toImmutable();
                    }
                }
            }
        }
        return best;
    }

    /** Zirhsiz, engelsiz tahmini patlama hasari (yarim kalp cinsinden). */
    private static String damageText(double x, double y, double z, LivingEntity t) {
        double dx = t.getX() - x, dy = t.getY() - y, dz = t.getZ() - z;
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d >= 12.0) return "Est. dmg: 0 (approx)";
        double impact = 1.0 - d / 12.0;
        long dmg = Math.round((impact * impact + impact) / 2.0 * 84.0 + 1.0);
        return "Est. dmg: ~" + dmg + " HP (approx, no armor/blocks)";
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        Draw.label(ctx, mc.textRenderer, "Crystal: " + status, px(), py());
        if (!dmgText.isEmpty()) Draw.label(ctx, mc.textRenderer, dmgText, px(), py() + 14);
        if (!indicator.get() || plan == null || planTarget == null) return;

        RenderUtil.begin(proj, mc, w, h);
        if (proj.project(plan.getX() + 0.5, plan.getY() + 0.5, plan.getZ() + 0.5)) {
            double half = Math.max(4.0, Math.min(60.0, proj.pixelsPerBlock() * 0.5));
            Draw.outline(ctx, (int) (proj.sx - half), (int) (proj.sy - half),
                    (int) (proj.sx + half), (int) (proj.sy + half), 2, 0xFF46C25B);
        }
        if (proj.project(planTarget.getX(), planTarget.getY() + planTarget.getHeight() / 2.0, planTarget.getZ())) {
            double half = Math.max(4.0, Math.min(80.0, proj.pixelsPerBlock() * Math.max(planTarget.getWidth(), 0.6f)));
            Draw.outline(ctx, (int) (proj.sx - half), (int) (proj.sy - half),
                    (int) (proj.sx + half), (int) (proj.sy + half), 2, 0xFFE5484D);
        }
    }
}
