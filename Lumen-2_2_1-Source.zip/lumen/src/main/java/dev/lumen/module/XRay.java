package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.BlockGroups;
import dev.lumen.util.BlockScanner;
import dev.lumen.util.Draw;
import dev.lumen.util.Projector;
import dev.lumen.util.RenderUtil;
import dev.lumen.util.TargetManager;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Set;

/**
 * Cevherleri duvarlarin ardindan renkli isaretle gosterir (ekran uzerinde ust katman).
 * Dunyayi seffaflastirmaz. Yalnizca yerel tek oyunculu dunyada calisir.
 */
public final class XRay extends Feature {
    private static final Set<String> DEFAULT_ON = Set.of(
            "Diamond Ore", "Deepslate Diamond Ore", "Emerald Ore", "Gold Ore", "Iron Ore", "Ancient Debris");
    private static final String[][] PRESETS = {
            {"Diamond Block", "diamond_block"}, {"Gold Block", "gold_block"}, {"Emerald Block", "emerald_block"},
            {"Netherite Block", "netherite_block"}, {"Spawner", "spawner"}, {"Obsidian", "obsidian"},
            {"Chest", "chest"}, {"Ender Chest", "ender_chest"}, {"Beacon", "beacon"}};
    private static final String[] PRESET_OPTIONS = presetOptions();
    private static final int MAX_LABELS = 30;

    private final BlockGroups.Group[] groups = BlockGroups.ORES;
    private final int customIdx = groups.length - 1;
    private final Setting.Num dist = add(new Setting.Num("Render Distance", 16, 8, 32, 2));
    private final Setting.Num opacity = add(new Setting.Num("Opacity", 45, 10, 100, 5).unit("%"));
    private final Setting.Mode style = add(new Setting.Mode("Outline Mode", "Filled", "Filled", "Outline"));
    private final Setting.Bool showName = add(new Setting.Bool("Block Name", false));
    private final Setting.Bool showDist = add(new Setting.Bool("Distance Display", false));
    private final Setting.Mode preset = add(new Setting.Mode("Custom Block", "None", PRESET_OPTIONS));
    private final Setting.Text customId = add(new Setting.Text("Custom Block ID", "", 40));
    private final Setting.Bool[] on = new Setting.Bool[groups.length];
    private final Setting.Color[] col = new Setting.Color[groups.length];
    private final boolean[] enabled = new boolean[groups.length];
    private final BlockScanner scanner = new BlockScanner(groups);
    private final Projector proj = new Projector();
    private String appliedId;

    private static String[] presetOptions() {
        String[] o = new String[PRESETS.length + 2];
        o[0] = "None";
        o[1] = "Typed ID";
        for (int i = 0; i < PRESETS.length; i++) o[i + 2] = PRESETS[i][0];
        return o;
    }

    public XRay() {
        super("X-Ray", "Cevherleri duvar ardindan gosterir (sadece tek oyunculu).", Category.WORLD);
        for (int i = 0; i < groups.length; i++) {
            on[i] = add(new Setting.Bool(groups[i].name(), DEFAULT_ON.contains(groups[i].name())));
        }
        for (int i = 0; i < groups.length; i++) {
            col[i] = add(new Setting.Color(groups[i].name() + " Color", groups[i].color()));
        }
        add(new Setting.Button("Reset Colors", () -> {
            for (Setting.Color c : col) c.reset();
            dev.lumen.core.Config.markDirty();
        }));
    }

    private String wantedId() {
        if (preset.is("None")) return "";
        if (preset.is("Typed ID")) return customId.get().trim().toLowerCase();
        for (String[] p : PRESETS) {
            if (preset.is(p[0])) return p[1];
        }
        return "";
    }

    private static Block resolve(String id) {
        if (id.isEmpty()) return null;
        Identifier ident = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
        if (ident == null || !Registries.BLOCK.containsId(ident)) return null;
        Block b = Registries.BLOCK.get(ident);
        return b == Blocks.AIR ? null : b;
    }

    @Override
    public void onTick() {
        if (!TargetManager.isSafeWorld(mc)) return;
        String want = wantedId();
        if (!want.equals(appliedId)) { // ozel blok ayari aninda uygulanir
            appliedId = want;
            scanner.setCustom(customIdx, resolve(want));
        }
        for (int i = 0; i < enabled.length; i++) enabled[i] = on[i].get();
        scanner.tick(mc, dist.i(), enabled, 6000);
    }

    @Override
    protected void onDisable() {
        scanner.reset();
        appliedId = null;
    }

    @Override
    public void onWorldChange() {
        scanner.reset();
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (!TargetManager.isSafeWorld(mc)) return;
        List<BlockScanner.Hit> hits = scanner.hits();
        if (hits.isEmpty()) return;
        RenderUtil.begin(proj, mc, w, h);
        TextRenderer tr = mc.textRenderer;
        int alpha = ((int) (opacity.get() / 100.0 * 255)) << 24;
        boolean filled = style.is("Filled");
        boolean labels = showName.get() || showDist.get();
        double r = dist.get();
        int labelsDrawn = 0;
        for (BlockScanner.Hit hit : hits) {
            if (!enabled[hit.group()]) continue;
            double cx = hit.x() + 0.5, cy = hit.y() + 0.5, cz = hit.z() + 0.5;
            double dSq = mc.player.squaredDistanceTo(cx, cy, cz);
            if (dSq > r * r) continue;
            if (!proj.project(cx, cy, cz)) continue;
            double half = Math.max(2.0, Math.min(80.0, proj.pixelsPerBlock() * 0.5));
            int x1 = (int) (proj.sx - half), y1 = (int) (proj.sy - half);
            int x2 = (int) (proj.sx + half), y2 = (int) (proj.sy + half);
            if (x2 < 0 || y2 < 0 || x1 > w || y1 > h) continue;
            int rgb = col[hit.group()].rgb();
            if (filled) ctx.fill(x1, y1, x2, y2, alpha | rgb);
            else Draw.outline(ctx, x1, y1, x2, y2, 1, 0xFF000000 | rgb);
            if (labels && labelsDrawn < MAX_LABELS) {
                String text = showName.get() ? groups[hit.group()].name() : "";
                if (showDist.get()) text += (text.isEmpty() ? "" : " ") + Math.round(Math.sqrt(dSq)) + "m";
                ctx.drawText(tr, text, x1, y1 - 10, 0xFF000000 | rgb, true);
                labelsDrawn++;
            }
        }
    }
}
