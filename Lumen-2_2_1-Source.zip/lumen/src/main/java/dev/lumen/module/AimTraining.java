package dev.lumen.module;

import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import dev.lumen.util.TargetManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Yalnizca tek oyunculu dunyada calisir. Canli varliklara karsi isabet oranini sayar.
 * "Auto Hit" (varsayilan kapali) dusman moblara nisan alinca, silah dolunca vurur.
 */
public final class AimTraining extends HudFeature {
    private final Setting.Bool showStats = add(new Setting.Bool("Show Stats", true));
    private final Setting.Bool autoHit = add(new Setting.Bool("Auto Hit", false));
    private final Setting.Bool reset = add(new Setting.Bool("Reset Stats", false));

    private int hits, swings;
    private String text = "Accuracy: --";

    public AimTraining() {
        super("Aim Training", "Tek oyunculuda isabet orani ve istege bagli otomatik vurus.", Category.COMBAT, 4, 40);
    }

    public int hits() {
        return hits;
    }

    public int swings() {
        return swings;
    }

    /** TriggerBot gibi moduller sonucu buradan bildirir. */
    public void record(boolean hit) {
        swings++;
        if (hit) hits++;
        refresh();
    }

    /** Oyuncu sol tiklayinca cagrilir. */
    public void onAttack() {
        if (!TargetManager.isSafeWorld(mc)) return;
        HitResult hr = mc.crosshairTarget;
        if (hr == null) return;
        if (hr.getType() == HitResult.Type.ENTITY && ((EntityHitResult) hr).getEntity() instanceof LivingEntity) {
            hits++;
            swings++;
            refresh();
        } else if (hr.getType() == HitResult.Type.MISS) {
            swings++;
            refresh();
        }
    }

    @Override
    public void onTick() {
        if (reset.get()) {
            reset.set(false);
            hits = 0;
            swings = 0;
            refresh();
        }
        if (!autoHit.get() || !TargetManager.isSafeWorld(mc) || mc.currentScreen != null
                || mc.interactionManager == null) return;
        if (Lumen.TRIGGER != null && Lumen.TRIGGER.isEnabled()) return; // saldiriyi Trigger Bot yonetir: cift vurus olmasin
        if (mc.crosshairTarget instanceof EntityHitResult e
                && e.getEntity() instanceof LivingEntity le && le instanceof Monster && le.isAlive()
                && TargetManager.isValid(mc, le) // arkadas korumasi
                && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc.interactionManager.attackEntity(mc.player, le);
            mc.player.swingHand(Hand.MAIN_HAND);
            hits++;
            swings++;
            refresh();
        }
    }

    private void refresh() {
        text = swings == 0 ? "Accuracy: --"
                : "Accuracy: " + Math.round(100f * hits / swings) + "% (" + hits + "/" + swings + ")";
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (showStats.get() && TargetManager.isSafeWorld(mc)) Draw.label(ctx, mc.textRenderer, text, px(), py());
    }
}
