package dev.lumen.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Tum modullerin tabani. (Ad "Module" degil: java.lang.Module ile karismasin.) */
public abstract class Feature {
    private static final String[] NONE = new String[0];

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    // GUI animasyon durumu
    public float toggleAnim;
    public float expandAnim;
    public boolean expanded;

    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private boolean enabled;

    protected Feature(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    void applyEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) {
            try {
                onEnable();
            } catch (RuntimeException | LinkageError e) {
                // Baslatma basarisiz: modul "acik" gorunup yarim durumda kalmasin; durum temizlenir, hata ustte loglanir.
                enabled = false;
                try {
                    onDisable();
                } catch (RuntimeException | LinkageError cleanup) {
                    e.addSuppressed(cleanup);
                }
                throw e;
            }
        } else {
            onDisable();
        }
    }

    /** Bu modul acilirken kapatilacak modullerin adlari. */
    public String[] conflicts() {
        return NONE;
    }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Dunya/oyuncu degisince (giris, cikis, boyut degisimi, olum) cagrilir: eski varlik referanslari burada birakilir. */
    public void onWorldChange() {}

    /** Ekranin ustunde kisa bir ipucu gosterir (oyuncu yoksa sessizce atlanir). */
    protected void hint(String message) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(message), true);
    }

    public void onTick() {}

    public void onHud(DrawContext ctx, int width, int height) {}
}
