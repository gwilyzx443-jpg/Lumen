package dev.lumen.core;

import dev.lumen.Lumen;

import java.util.function.Consumer;
import java.util.function.Supplier;

public abstract class Setting<T> {
    public final String name;
    protected final T def;
    protected T value;
    public float anim; // GUI animasyon durumu

    protected Setting(String name, T def) {
        this.name = name;
        this.def = def;
        this.value = def;
    }

    public T get() {
        return value;
    }

    /** Config dosyasina yazilsin mi? (Button yazilmaz) */
    public boolean persistent() {
        return true;
    }

    /** Varsayilan degere doner. */
    public void reset() {
        value = def;
        sync();
    }

    /** Degisen degere bagli yardimci durumlari (indeks, konum) yeniler. */
    protected void sync() {}

    public abstract void load(String raw);

    public abstract String save();

    public static final class Bool extends Setting<Boolean> {
        public Bool(String name, boolean def) {
            super(name, def);
            anim = def ? 1f : 0f;
        }

        public void set(boolean v) {
            value = v;
        }

        public void toggle() {
            value = !value;
        }

        @Override
        public void load(String raw) {
            value = Boolean.parseBoolean(raw);
            anim = value ? 1f : 0f;
        }

        @Override
        public String save() {
            return value.toString();
        }
    }

    public static final class Num extends Setting<Double> {
        public final double min, max, step;
        public String unit = "";

        public Num(String name, double def, double min, double max, double step) {
            super(name, def);
            this.min = min;
            this.max = max;
            this.step = step;
        }

        /** GUI'de degerin yaninda gosterilen birim (ornek: "%"). */
        public Num unit(String u) {
            this.unit = u;
            return this;
        }

        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }

        public int i() {
            return (int) Math.round(value);
        }

        @Override
        public void load(String raw) {
            try {
                set(Double.parseDouble(raw));
            } catch (NumberFormatException ignored) {
                // bozuk deger: mevcut deger kalir
            }
        }

        @Override
        public String save() {
            return Double.toString(value);
        }
    }

    /** Acilir liste (dropdown). */
    public static final class Mode extends Setting<String> {
        public final String[] options;
        private int index;

        public Mode(String name, String def, String... options) {
            super(name, def);
            this.options = options;
            sync();
            this.value = options[index];
        }

        public boolean is(String option) {
            return value.equals(option);
        }

        public int index() {
            return index;
        }

        public void select(int i) {
            index = Math.floorMod(i, options.length);
            value = options[index];
        }

        public void next() {
            select(index + 1);
        }

        public void prev() {
            select(index - 1);
        }

        @Override
        protected void sync() {
            index = 0;
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(value)) index = i;
            }
        }

        @Override
        public void load(String raw) {
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(raw)) select(i);
            }
        }

        @Override
        public String save() {
            return value;
        }
    }

    /** Renk secici: renk tonu kaydiricisi (0..0.92) + sag uca beyaz. Deger 0xRRGGBB. */
    public static final class Color extends Setting<Integer> {
        private float pos;

        public Color(String name, int rgb) {
            super(name, rgb & 0xFFFFFF);
            pos = posOf(value);
        }

        public int rgb() {
            return value;
        }

        public float pos() {
            return pos;
        }

        public void setPos(float p) {
            pos = Math.max(0f, Math.min(1f, p));
            value = fromPos(pos);
        }

        @Override
        protected void sync() {
            pos = posOf(value);
        }

        @Override
        public void load(String raw) {
            try {
                value = Integer.parseInt(raw.trim(), 16) & 0xFFFFFF;
                pos = posOf(value);
            } catch (NumberFormatException ignored) {
                // bozuk deger: mevcut renk kalir
            }
        }

        @Override
        public String save() {
            return String.format("%06X", value);
        }

        public static int fromPos(float p) {
            if (p >= 0.92f) return 0xFFFFFF;
            return hsv(p / 0.92f, 0.85f, 1f);
        }

        static float posOf(int rgb) {
            float r = ((rgb >> 16) & 0xFF) / 255f, g = ((rgb >> 8) & 0xFF) / 255f, b = (rgb & 0xFF) / 255f;
            float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
            if (max <= 0f || (max - min) / max < 0.3f) return 1f; // gri/beyaz
            float d = max - min;
            float h;
            if (max == r) h = ((g - b) / d) % 6f;
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
            if (h < 0f) h += 1f;
            return Math.min(0.91f, h * 0.92f);
        }

        static int hsv(float h, float s, float v) {
            float hh = (h - (float) Math.floor(h)) * 6f;
            int i = (int) hh;
            float f = hh - i;
            float p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
            float r, g, b;
            switch (i % 6) {
                case 0 -> { r = v; g = t; b = p; }
                case 1 -> { r = q; g = v; b = p; }
                case 2 -> { r = p; g = v; b = t; }
                case 3 -> { r = p; g = q; b = v; }
                case 4 -> { r = t; g = p; b = v; }
                default -> { r = v; g = p; b = q; }
            }
            return ((int) (r * 255 + .5f) << 16) | ((int) (g * 255 + .5f) << 8) | (int) (b * 255 + .5f);
        }
    }

    /** Metin girisi (klavye ile). Blok kimligi gibi kisa degerler icin. */
    public static final class Text extends Setting<String> {
        public final int maxLen;

        public Text(String name, String def, int maxLen) {
            super(name, def);
            this.maxLen = maxLen;
        }

        public void set(String v) {
            value = v.length() > maxLen ? v.substring(0, maxLen) : v;
        }

        @Override
        public void load(String raw) {
            set(raw);
        }

        @Override
        public String save() {
            return value;
        }
    }

    /** Tiklaninca islem yapan dugme (Statistics Reset, Reset Colors gibi). */
    public static final class Button extends Setting<Runnable> {
        public Button(String name, Runnable action) {
            super(name, action);
        }

        public void run() {
            try {
                value.run();
            } catch (RuntimeException e) {
                // oyun etkilenmesin ama hata gizlenmesin: kaynagi logda gorunur
                Lumen.LOGGER.warn("Dugme '{}' hata verdi: {}", name, e.toString());
            }
        }

        @Override
        public boolean persistent() {
            return false;
        }

        @Override
        public void load(String raw) {}

        @Override
        public String save() {
            return "";
        }
    }

    /**
     * Salt okunur satir: ad + anlik deger (ornegin "Friend Count: 3"). Tiklayinca bir sey yapmaz ve
     * "Reset to Defaults" ile sifirlanmaz. Istege bagli olarak kaydedilir/yuklenir (ornegin arkadas listesi).
     */
    public static final class Info extends Setting<Supplier<String>> {
        private final Consumer<String> loader;
        private final Supplier<String> saver;

        public Info(String name, Supplier<String> shown) {
            this(name, shown, null, null);
        }

        public Info(String name, Supplier<String> shown, Consumer<String> loader, Supplier<String> saver) {
            super(name, shown);
            this.loader = loader;
            this.saver = saver;
        }

        /** GUI'de gosterilen metin; hata verirse bos metin (GUI cizimi cokmesin). */
        public String text() {
            try {
                String s = value.get();
                return s == null ? "" : s;
            } catch (RuntimeException e) {
                return "";
            }
        }

        @Override
        public boolean persistent() {
            return saver != null;
        }

        @Override
        public void reset() {
            // salt okunur: varsayilana donmez (arkadas listesi yanlislikla silinmesin)
        }

        @Override
        public void load(String raw) {
            if (loader != null) loader.accept(raw);
        }

        @Override
        public String save() {
            return saver == null ? "" : saver.get();
        }
    }
}
