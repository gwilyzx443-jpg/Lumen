import dev.lumen.core.ConfigFormat;
import dev.lumen.core.Setting;
import dev.lumen.util.ChanceModel;
import dev.lumen.util.FriendsManager;
import dev.lumen.util.FriendsManager.Result;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minecraft gerektirmeyen parcalarin gercek testi (FriendsManager, ConfigFormat, Setting, ChanceModel).
 * Calistirma: selftest/run.sh   ->  cikis kodu 0 = hepsi gecti.
 * Minecraft'a bagli kisimlar (GUI, event, hedefleme) burada TEST EDILEMEZ; oyun icinde denenmelidir.
 */
public final class SelfTest {
    static int pass, fail;

    static void check(String name, boolean ok) {
        if (ok) pass++; else fail++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
    }

    static void eq(String name, Object expected, Object actual) {
        boolean ok = expected == null ? actual == null : expected.equals(actual);
        check(ok ? name : name + "  (beklenen=" + expected + ", gelen=" + actual + ")", ok);
    }

    static void reset() {
        FriendsManager.deserialize("");
        FriendsManager.setProtection(true);
        FriendsManager.setOnChange(null);
    }

    public static void main(String[] args) throws Exception {
        friends();
        commands();
        persistence();
        settings();
        chance();
        GameTest.run();
        System.out.println("\nSonuc: " + pass + " gecti, " + fail + " basarisiz");
        System.exit(fail == 0 ? 0 : 1);
    }

    // ------------------------------------------------------------------ FriendsManager
    static void friends() {
        System.out.println("== FriendsManager");
        reset();
        int[] changes = {0};
        FriendsManager.setOnChange(() -> changes[0]++);

        eq("add -> ADDED", Result.ADDED, FriendsManager.add("Steve"));
        eq("ayni isim farkli harf -> DUPLICATE", Result.DUPLICATE, FriendsManager.add("sTEVE"));
        eq("tekrar eklenmedi (sayi 1)", 1, FriendsManager.count());
        eq("goruntu adi ilk yazilan hal", List.of("Steve"), FriendsManager.list());
        eq("onChange yalnizca gercek degisimde (1)", 1, changes[0]);

        eq("bos isim INVALID", Result.INVALID, FriendsManager.add("   "));
        eq("virgullu isim INVALID", Result.INVALID, FriendsManager.add("a,b"));
        eq("'=' iceren INVALID", Result.INVALID, FriendsManager.add("x=y"));
        eq("satir sonu bosluga cevrilir (dosyaya satir sonu girmez)", Result.ADDED, FriendsManager.add("bad\nname"));
        check("saklanan isimde satir sonu yok", FriendsManager.list().stream().noneMatch(n -> n.contains("\n") || n.contains("\r")));
        check("serialize satir sonu icermez", !FriendsManager.serialize().contains("\n"));
        eq("'bad name' ile ayni kisi sayilir", Result.DUPLICATE, FriendsManager.add("BAD NAME"));
        eq("33 karakter INVALID", Result.INVALID, FriendsManager.add("a".repeat(33)));
        eq("32 karakter gecerli", Result.ADDED, FriendsManager.add("b".repeat(32)));
        eq("null INVALID", Result.INVALID, FriendsManager.add(null));
        eq("bosluklu isim gecerli", Result.ADDED, FriendsManager.add("Bob  the   Cow"));
        eq("bosluklar tek bosluga indi", true, FriendsManager.list().contains("Bob the Cow"));
        eq("bosluk farkli yazim DUPLICATE", Result.DUPLICATE, FriendsManager.add("bob THE cow"));

        check("isFriend buyuk/kucuk harf duyarsiz", FriendsManager.isFriend("sTeVe"));
        check("isFriend bilinmeyen -> false", !FriendsManager.isFriend("Alex"));
        check("isFriend null guvenli", !FriendsManager.isFriend(null));
        check("adsiz mob adi ('Zombie') arkadas degil", !FriendsManager.isFriend("Zombie"));

        check("koruma acikken isProtected", FriendsManager.isProtected("steve"));
        FriendsManager.setProtection(false);
        check("koruma kapaliyken isProtected false", !FriendsManager.isProtected("steve"));
        FriendsManager.setProtection(true);

        int before = changes[0];
        eq("remove (buyuk/kucuk harf duyarsiz) -> REMOVED", Result.REMOVED, FriendsManager.remove("STEVE"));
        eq("remove olmayan -> NOT_FOUND", Result.NOT_FOUND, FriendsManager.remove("steve"));
        eq("remove bos -> INVALID", Result.INVALID, FriendsManager.remove(" "));
        eq("onChange remove'da 1 kez", before + 1, changes[0]);
        check("silinen artik arkadas degil", !FriendsManager.isFriend("Steve"));
        eq("summary guncellendi", false, FriendsManager.summary().contains("Steve"));

        reset();
        eq("bos listede summary '-'", "-", FriendsManager.summary());
        for (int i = 0; i < FriendsManager.MAX_FRIENDS; i++) FriendsManager.add("p" + i);
        eq("sinira kadar eklenir", FriendsManager.MAX_FRIENDS, FriendsManager.count());
        eq("sinir asilinca FULL", Result.FULL, FriendsManager.add("extra"));
        reset();
    }

    // ------------------------------------------------------------------ komutlar
    static void commands() {
        System.out.println("== .f komutlari");
        reset();
        eq("normal sohbet -> null", null, FriendsManager.execute("merhaba"));
        eq("'.fly' komut degil -> null", null, FriendsManager.execute(".fly"));
        eq("null mesaj -> null", null, FriendsManager.execute(null));
        check("'.f' tek basina -> kullanim", FriendsManager.execute(".f").get(0).contains(".f add"));
        check("'.f bilinmeyen' -> kullanim", FriendsManager.execute(".f foo").get(0).contains(".f add"));
        check("'.f add' isimsiz -> kullanim", FriendsManager.execute(".f add").get(0).contains(".f add"));
        check("'.f remove' isimsiz -> kullanim", FriendsManager.execute(".f remove  ").get(0).contains(".f add"));

        check(".f add Steve", FriendsManager.execute(".f add Steve").get(0).startsWith("Arkadas eklendi"));
        check(".F ADD alex (harf duyarsiz komut)", FriendsManager.execute(".F ADD alex").get(0).startsWith("Arkadas eklendi"));
        check(".f add steve tekrar", FriendsManager.execute(".f add steve").get(0).startsWith("Zaten"));
        check(".f add iki kelime", FriendsManager.execute(".f add Mavi Inek").get(0).contains("Mavi Inek"));
        eq("uc arkadas var", 3, FriendsManager.count());

        List<String> l = FriendsManager.execute(".f list");
        check(".f list sayiyi ve isimleri yazar", l.get(0).contains("(3)") && l.get(1).contains("Steve")
                && l.get(1).contains("alex") && l.get(1).contains("Mavi Inek"));
        FriendsManager.setProtection(false);
        check(".f list koruma KAPALI gosterir", FriendsManager.execute(".f list").get(0).contains("KAPALI"));
        FriendsManager.setProtection(true);

        check(".f remove ALEX", FriendsManager.execute(".f remove ALEX").get(0).startsWith("Arkadas silindi"));
        check(".f remove olmayan", FriendsManager.execute(".f remove yok").get(0).startsWith("Arkadas listesinde yok"));
        check(".f add gecersiz isim", FriendsManager.execute(".f add a=b").get(0).startsWith("Gecersiz"));
        reset();
        check("bos listede .f list", FriendsManager.execute(".f list").get(0).contains("bos"));
    }

    // ------------------------------------------------------------------ kalicilik (gercek dosya)
    static void persistence() throws Exception {
        System.out.println("== Kalicilik (gercek dosya)");
        reset();
        Path dir = Files.createTempDirectory("lumen-selftest");
        Path file = dir.resolve("friends.properties");

        FriendsManager.add("Steve");
        FriendsManager.add("Alex_99");
        FriendsManager.add("Mavi Inek");
        Map<String, String> m = new LinkedHashMap<>();
        m.put("_enabled", "true");
        m.put("Friends List", FriendsManager.serialize());
        ConfigFormat.writeAtomic(file, ConfigFormat.write(m));
        check("dosya yazildi", Files.isRegularFile(file));
        check("gecici .tmp dosyasi kalmadi", !Files.exists(dir.resolve("friends.properties.tmp")));

        // "oyunu yeniden ac": bellekteki liste silinir, dosyadan okunur
        reset();
        eq("yeniden aciliste liste bos", 0, FriendsManager.count());
        Map<String, String> back = ConfigFormat.parse(Files.readString(file, StandardCharsets.UTF_8));
        FriendsManager.deserialize(back.get("Friends List"));
        eq("liste geri yuklendi", List.of("Steve", "Alex_99", "Mavi Inek"), FriendsManager.list());
        eq("_enabled okundu", "true", back.get("_enabled"));

        // ustune yazma tam olmali (eski icerik karismaz)
        FriendsManager.remove("Steve");
        m.put("Friends List", FriendsManager.serialize());
        ConfigFormat.writeAtomic(file, ConfigFormat.write(m));
        Map<String, String> again = ConfigFormat.parse(Files.readString(file, StandardCharsets.UTF_8));
        eq("ustune yazma: guncel liste", "Alex_99,Mavi Inek", again.get("Friends List"));
        eq("ustune yazma: tek dosya", 1L, Files.list(dir).count());

        // bozuk / hileli dosya: cokmeden, gecerli kismi yukler
        FriendsManager.deserialize(",,, ,Steve,STEVE,a=b,bad\nname,Alex,\t," + "x".repeat(40) + ",ok.name");
        eq("bozuk girdi: yalnizca gecerli ve tekrarsiz", List.of("Steve", "bad name", "Alex", "ok.name"), FriendsManager.list());
        FriendsManager.deserialize(null);
        eq("null deger: liste bos, hata yok", 0, FriendsManager.count());
        String junk = new String(new byte[]{0, 1, 2, (byte) 0xFF, '\n', '=', '=', '#'}, StandardCharsets.ISO_8859_1);
        check("bozuk dosya parse edilir (istisna yok)", ConfigFormat.parse(junk) != null);

        // yukleme degisiklik sayilmaz
        int[] c = {0};
        FriendsManager.setOnChange(() -> c[0]++);
        FriendsManager.deserialize("a,b,c");
        eq("deserialize onChange cagirmaz", 0, c[0]);

        // 200+ girdili dosya
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 500; i++) sb.append("n").append(i).append(',');
        FriendsManager.deserialize(sb.toString());
        eq("500 girdili dosya 200'e kirpilir", FriendsManager.MAX_FRIENDS, FriendsManager.count());

        reset();
        try (var s = Files.walk(dir)) {
            s.sorted((a, b) -> b.compareTo(a)).forEach(p -> p.toFile().delete());
        }
    }

    // ------------------------------------------------------------------ Setting
    static void settings() {
        System.out.println("== Setting");
        var num = new Setting.Num("Range", 4.5, 1, 10, 0.5);
        num.set(99);
        eq("Num ust sinira kirpilir", 10.0, num.get());
        num.set(-5);
        eq("Num alt sinira kirpilir", 1.0, num.get());
        num.set(4.7);
        eq("Num adima yuvarlanir", 4.5, num.get());
        num.load("not-a-number");
        eq("Num bozuk deger: onceki kalir", 4.5, num.get());
        num.load("7.2");
        eq("Num load/save", "7.0", num.save());

        var bool = new Setting.Bool("B", false);
        bool.load("true");
        check("Bool load", bool.get());
        bool.reset();
        check("Bool reset", !bool.get());

        var mode = new Setting.Mode("M", "Body", "Head", "Body", "Feet");
        mode.load("Feet");
        eq("Mode load", "Feet", mode.get());
        mode.load("YOK");
        eq("Mode gecersiz secenek: degismez", "Feet", mode.get());
        mode.next();
        eq("Mode next (basa sarar)", "Head", mode.get());

        var color = new Setting.Color("C", 0xE5484D);
        color.load("zzzz");
        eq("Color bozuk deger: onceki kalir", "E5484D", color.save());
        color.load("00FF00");
        eq("Color load", "00FF00", color.save());

        var text = new Setting.Text("T", "", 4);
        text.set("abcdefgh");
        eq("Text maksimum uzunluga kirpilir", "abcd", text.get());

        // Info
        String[] store = {"a,b"};
        var info = new Setting.Info("Friends List", () -> store[0], v -> store[0] = v, () -> store[0]);
        check("Info (kayitli) persistent", info.persistent());
        info.load("x,y");
        eq("Info load", "x,y", info.save());
        info.reset();
        eq("Info reset listeyi silmez", "x,y", info.save());
        check("Info salt okunur (kaydedilmez) varyanti", !new Setting.Info("N", () -> "1").persistent());
        eq("Info.text hata verirse bos", "", new Setting.Info("E", () -> { throw new IllegalStateException(); }).text());
        eq("Info.text null -> bos", "", new Setting.Info("N", () -> null).text());

        // Button hatasi gizlenmez: loglanir, oyunu cokertmez
        int w0 = org.slf4j.Logger.warns;
        new Setting.Button("Boom", () -> { throw new IllegalStateException("test"); }).run();
        eq("Button hatasi loglandi", w0 + 1, org.slf4j.Logger.warns);
        int[] ran = {0};
        new Setting.Button("Ok", () -> ran[0]++).run();
        eq("Button calisir", 1, ran[0]);
    }

    // ------------------------------------------------------------------ ChanceModel
    static void chance() {
        System.out.println("== ChanceModel");
        eq("maxMiss(100)=0", 0, ChanceModel.maxMiss(100));
        eq("maxMiss(30)=70", 70, ChanceModel.maxMiss(30));
        eq("maxMiss(150)=0 (negatif olmaz)", 0, ChanceModel.maxMiss(150));
        eq("roll < hit -> HIT", ChanceModel.Outcome.HIT, ChanceModel.roll(60, 20, 59));
        eq("roll = hit -> MISS", ChanceModel.Outcome.MISS, ChanceModel.roll(60, 20, 60));
        eq("roll = hit+miss -> SKIP", ChanceModel.Outcome.SKIP, ChanceModel.roll(60, 20, 80));
        eq("miss, 100-hit ile sinirlanir: roll 99 hala MISS", ChanceModel.Outcome.MISS, ChanceModel.roll(90, 50, 99));
        int m90 = 0, s90 = 0;
        for (int r = 0; r < 100; r++) {
            var o = ChanceModel.roll(90, 50, r);
            if (o == ChanceModel.Outcome.MISS) m90++;
            if (o == ChanceModel.Outcome.SKIP) s90++;
        }
        check("hit=90, miss=50 istense bile 10 MISS, 0 SKIP", m90 == 10 && s90 == 0);
        int hits = 0, misses = 0, skips = 0;
        for (int r = 0; r < 100; r++) {
            switch (ChanceModel.roll(70, 20, r)) {
                case HIT -> hits++;
                case MISS -> misses++;
                case SKIP -> skips++;
            }
        }
        check("100 zarda dagilim 70/20/10", hits == 70 && misses == 20 && skips == 10);
    }
}
