package org.slf4j;

/** Yalnizca selftest icin: gercek slf4j yerine gecen kucuk taklit (uyari/hata sayar, son hatayi tutar). */
public class Logger {
    public static int warns, errors;
    public static Throwable lastError;
    public static String lastMessage = "";

    public void warn(String format, Object a, Object b) {
        warns++;
        lastMessage = format + " | " + a + " | " + b;
    }

    public void warn(String format, Object a) {
        warns++;
        lastMessage = format + " | " + a;
    }

    public void error(String format, Object... args) {
        errors++;
        lastMessage = format;
        Object last = args.length > 0 ? args[args.length - 1] : null;
        lastError = last instanceof Throwable t ? t : null;
    }
}
