package net.minecraft.entity.decoration;

import net.minecraft.entity.LivingEntity;

public class ArmorStandEntity extends LivingEntity {}
