package net.minecraft.entity.decoration;

import net.minecraft.entity.Entity;

public class EndCrystalEntity extends Entity {}
