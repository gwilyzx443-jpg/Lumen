package net.minecraft.entity.passive;

import net.minecraft.entity.LivingEntity;

public class TameableEntity extends LivingEntity {
    public boolean tamed;
    public boolean isTamed() { return tamed; }
}
