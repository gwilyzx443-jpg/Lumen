package net.minecraft.entity;

public class LivingEntity extends Entity {
    public float health = 20f, maxHealth = 20f;
    public int armor;
    public boolean alive = true;
    public boolean isAlive() { return alive && !removed; }
    public float getHealth() { return health; }
    public float getMaxHealth() { return maxHealth; }
    public int getArmor() { return armor; }
}
