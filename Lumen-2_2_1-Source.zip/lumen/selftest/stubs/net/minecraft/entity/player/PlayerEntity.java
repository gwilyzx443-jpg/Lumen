package net.minecraft.entity.player;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class PlayerEntity extends LivingEntity {
    public boolean creative;
    public float cooldown = 1.0f;
    public ItemStack main = new ItemStack(new Item()), off = new ItemStack(new Item());
    public int swings;

    public boolean isCreative() { return creative; }
    public float getAttackCooldownProgress(float baseTime) { return cooldown; }
    public ItemStack getMainHandStack() { return main; }
    public ItemStack getOffHandStack() { return off; }
    public void swingHand(Hand h) { swings++; }
    public Vec3d getEyePos() { return new Vec3d(x, y + 1.62, z); }
}
