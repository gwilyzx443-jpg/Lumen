package net.minecraft.entity;

import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Selftest taklidi: gercek Entity'nin yalnizca Lumen'in kullandigi kismi. */
public class Entity {
    private static int nextId = 1;
    public final int id = nextId++;
    public boolean removed, invisible;
    public String customName;
    public String typeName = "Entity";
    public double x, y, z;
    public float width = 0.6f, height = 1.8f, yaw, pitch;

    public int getId() { return id; }
    public boolean isRemoved() { return removed; }
    public boolean isInvisible() { return invisible; }
    public boolean hasCustomName() { return customName != null; }
    public Text getCustomName() { return customName == null ? null : Text.literal(customName); }
    public Text getName() { return Text.literal(customName != null ? customName : typeName); }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public void setYaw(float v) { yaw = v; }
    public void setPitch(float v) { pitch = v; }
    public BlockPos getBlockPos() { return new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z)); }
    public Box getBoundingBox() {
        return new Box(x - width / 2, y, z - width / 2, x + width / 2, y + height, z + width / 2);
    }
    public double squaredDistanceTo(Entity o) { return squaredDistanceTo(o.x, o.y, o.z); }
    public double squaredDistanceTo(double ox, double oy, double oz) {
        double a = x - ox, b = y - oy, c = z - oz;
        return a * a + b * b + c * c;
    }
    public float distanceTo(Entity o) { return (float) Math.sqrt(squaredDistanceTo(o)); }
}
