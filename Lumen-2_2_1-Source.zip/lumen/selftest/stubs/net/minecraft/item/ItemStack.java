package net.minecraft.item;
public class ItemStack {
    public final Item item;
    public ItemStack(Item item) { this.item = item; }
    public boolean isOf(Item i) { return item == i; }
}
