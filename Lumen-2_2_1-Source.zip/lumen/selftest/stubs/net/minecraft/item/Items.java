package net.minecraft.item;
public final class Items {
    public static final Item END_CRYSTAL = new Item();
    public static final Item DIAMOND_SWORD = new Item();
    private Items() {}
}
