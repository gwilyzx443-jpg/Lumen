package net.minecraft.client.gui;

import net.minecraft.client.font.TextRenderer;

public class DrawContext {
    public int fills, texts;
    public void fill(int x1, int y1, int x2, int y2, int color) { fills++; }
    public void drawText(TextRenderer tr, String s, int x, int y, int color, boolean shadow) { texts++; }
}
