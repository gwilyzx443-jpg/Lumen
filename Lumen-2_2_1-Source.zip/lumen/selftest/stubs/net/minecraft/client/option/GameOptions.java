package net.minecraft.client.option;
public class GameOptions { public KeyBinding useKey = new KeyBinding(); }
