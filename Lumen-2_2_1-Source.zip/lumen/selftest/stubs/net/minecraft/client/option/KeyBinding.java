package net.minecraft.client.option;
public class KeyBinding { public boolean pressed; public boolean isPressed() { return pressed; } }
