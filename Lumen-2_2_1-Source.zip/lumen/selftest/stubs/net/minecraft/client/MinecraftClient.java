package net.minecraft.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.HitResult;

public class MinecraftClient {
    private static final MinecraftClient I = new MinecraftClient();
    public ClientPlayerEntity player;
    public ClientWorld world;
    public HitResult crosshairTarget;
    public Screen currentScreen;
    public ClientPlayerInteractionManager interactionManager = new ClientPlayerInteractionManager();
    public TextRenderer textRenderer = new TextRenderer();
    public net.minecraft.client.option.GameOptions options = new net.minecraft.client.option.GameOptions();
    public boolean singleplayer = true;

    public static MinecraftClient getInstance() { return I; }
    public boolean isInSingleplayer() { return singleplayer; }
}
