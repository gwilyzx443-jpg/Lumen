package net.minecraft.client.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

public class ClientWorld {
    public final List<Entity> entities = new ArrayList<>();
    public final Map<BlockPos, Block> blocks = new HashMap<>();

    public List<PlayerEntity> getPlayers() {
        List<PlayerEntity> out = new ArrayList<>();
        for (Entity e : entities) if (e instanceof PlayerEntity p) out.add(p);
        return out;
    }
    public Entity getEntityById(int id) {
        for (Entity e : entities) if (e.getId() == id) return e;
        return null;
    }
    public List<Entity> getOtherEntities(Entity except, Box box, Predicate<? super Entity> pred) {
        List<Entity> out = new ArrayList<>();
        for (Entity e : entities) {
            if (e == except || e.isRemoved()) continue;
            if (box != null && !box.intersects(e.getBoundingBox())) continue;
            if (pred.test(e)) out.add(e);
        }
        return out;
    }
    public <T extends Entity> List<T> getEntitiesByClass(Class<T> cls, Box box, Predicate<? super T> pred) {
        List<T> out = new ArrayList<>();
        for (Entity e : entities) {
            if (cls.isInstance(e) && !e.isRemoved() && box.intersects(e.getBoundingBox()) && pred.test(cls.cast(e))) out.add(cls.cast(e));
        }
        return out;
    }
    public int getBottomY() { return -64; }
    public int getHeight() { return 384; }
    public int lookups;
    public BlockState getBlockState(BlockPos p) { lookups++; return new BlockState(blocks.getOrDefault(p, Blocks.AIR)); }
}
