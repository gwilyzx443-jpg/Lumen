package net.minecraft.client.network;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

import java.util.ArrayList;
import java.util.List;

public class ClientPlayerInteractionManager {
    public final List<Entity> attacked = new ArrayList<>();
    public final List<BlockHitResult> interacted = new ArrayList<>();
    public void attackEntity(PlayerEntity p, Entity e) { attacked.add(e); }
    public void interactBlock(PlayerEntity p, Hand h, BlockHitResult r) { interacted.add(r); }
}
