package net.minecraft.client.network;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClientPlayerEntity extends PlayerEntity {
    public final List<String> messages = new ArrayList<>();
    public void sendMessage(Text t, boolean overlay) { messages.add(t.getString()); }
}
