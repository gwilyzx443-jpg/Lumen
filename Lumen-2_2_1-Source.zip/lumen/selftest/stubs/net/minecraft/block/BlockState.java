package net.minecraft.block;
public class BlockState {
    public final Block block;
    public BlockState(Block b) { block = b; }
    public boolean isOf(Block b) { return block == b; }
    public Block getBlock() { return block; }
    public boolean isAir() { return block == Blocks.AIR; }
}
