package net.minecraft.block;
public final class Blocks {
    public static final Block AIR = new Block();
    public static final Block OBSIDIAN = new Block();
    public static final Block BEDROCK = new Block();
    public static final Block STONE = new Block();
    private Blocks() {}
}
