package net.minecraft.util.hit;

import net.minecraft.entity.Entity;

public class EntityHitResult extends HitResult {
    private final Entity e;
    public EntityHitResult(Entity e) { super(Type.ENTITY); this.e = e; }
    public Entity getEntity() { return e; }
}
