package net.minecraft.util.hit;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class BlockHitResult extends HitResult {
    public final BlockPos pos;
    public BlockHitResult(Vec3d hit, Direction side, BlockPos pos, boolean inside) { super(Type.BLOCK); this.pos = pos; }
}
