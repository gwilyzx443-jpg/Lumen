package net.minecraft.util.hit;

public abstract class HitResult {
    public enum Type { MISS, BLOCK, ENTITY }
    private final Type type;
    protected HitResult(Type t) { type = t; }
    public Type getType() { return type; }
}
