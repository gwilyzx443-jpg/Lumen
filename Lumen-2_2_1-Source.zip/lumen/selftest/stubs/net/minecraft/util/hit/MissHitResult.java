package net.minecraft.util.hit;

public class MissHitResult extends HitResult {
    public MissHitResult() { super(Type.MISS); }
}
