package net.minecraft.util.math;

public class Box {
    public final double minX, minY, minZ, maxX, maxY, maxZ;
    public Box(double x1, double y1, double z1, double x2, double y2, double z2) {
        minX = x1; minY = y1; minZ = z1; maxX = x2; maxY = y2; maxZ = z2;
    }
    public Box expand(double v) { return new Box(minX - v, minY - v, minZ - v, maxX + v, maxY + v, maxZ + v); }
    public boolean intersects(Box o) {
        return minX < o.maxX && maxX > o.minX && minY < o.maxY && maxY > o.minY && minZ < o.maxZ && maxZ > o.minZ;
    }
}
