package net.minecraft.util.math;

import java.util.Objects;

public class BlockPos {
    protected int x, y, z;
    public BlockPos(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }
    public BlockPos up() { return new BlockPos(x, y + 1, z); }
    public BlockPos up(int n) { return new BlockPos(x, y + n, z); }
    @Override public boolean equals(Object o) { return o instanceof BlockPos b && b.x == x && b.y == y && b.z == z; }
    @Override public int hashCode() { return Objects.hash(x, y, z); }

    public static class Mutable extends BlockPos {
        public Mutable() { super(0, 0, 0); }
        public Mutable set(int x, int y, int z) { this.x = x; this.y = y; this.z = z; return this; }
        public BlockPos toImmutable() { return new BlockPos(x, y, z); }
    }
}
