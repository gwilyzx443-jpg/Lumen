package net.minecraft.util.math;

public final class MathHelper {
    private MathHelper() {}
    public static float clamp(float v, float min, float max) { return v < min ? min : Math.min(v, max); }
    public static float wrapDegrees(float d) {
        d = d % 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }
}
