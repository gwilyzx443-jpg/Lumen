package net.minecraft.util.math;

public class Vec3d {
    public final double x, y, z;
    public Vec3d(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
    public Vec3d add(double dx, double dy, double dz) { return new Vec3d(x + dx, y + dy, z + dz); }
    public double squaredDistanceTo(double ox, double oy, double oz) {
        double a = x - ox, b = y - oy, c = z - oz;
        return a * a + b * b + c * c;
    }
    public static Vec3d ofCenter(BlockPos p) { return new Vec3d(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5); }
}
