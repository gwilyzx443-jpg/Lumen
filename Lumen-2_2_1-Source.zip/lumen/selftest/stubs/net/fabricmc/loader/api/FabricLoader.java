package net.fabricmc.loader.api;

import java.nio.file.Path;

public class FabricLoader {
    public static Path configDir;
    private static final FabricLoader I = new FabricLoader();

    public static FabricLoader getInstance() { return I; }

    public Path getConfigDir() { return configDir; }
}
