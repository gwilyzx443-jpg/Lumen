package dev.lumen.util;

import net.minecraft.client.MinecraftClient;

/** Yalnizca selftest icin: kamera/projeksiyon cizimi test edilmez. */
public final class RenderUtil {
    private RenderUtil() {}

    public static void begin(Projector p, MinecraftClient mc, int w, int h) {}
}
