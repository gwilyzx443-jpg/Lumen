package dev.lumen.util;

import net.minecraft.block.Block;

/** Yalnizca selftest icin: BlockScanner'in ihtiyac duydugu Group kaydi. */
public final class BlockGroups {
    public record Group(String name, int color, Block[] blocks) {}
    private BlockGroups() {}
}
