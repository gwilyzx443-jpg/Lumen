package dev.lumen;

import dev.lumen.core.ModuleManager;
import dev.lumen.module.AimTraining;
import dev.lumen.module.TriggerBot;

/** Yalnizca selftest icin: Fabric'e bagli gercek Lumen sinifinin statik alanlari. */
public final class Lumen {
    public static final org.slf4j.Logger LOGGER = new org.slf4j.Logger();
    public static ModuleManager MODULES = new ModuleManager();
    public static AimTraining AIM;
    public static TriggerBot TRIGGER;
}
