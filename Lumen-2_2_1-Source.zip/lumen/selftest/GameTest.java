import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.Config;
import dev.lumen.core.Feature;
import dev.lumen.core.ModuleManager;
import dev.lumen.core.Setting;
import dev.lumen.module.AimAssist;
import dev.lumen.module.AimTraining;
import dev.lumen.module.AutoCrystal;
import dev.lumen.module.Friends;
import dev.lumen.module.TargetControl;
import dev.lumen.module.TargetHud;
import dev.lumen.module.TriggerBot;
import dev.lumen.util.BlockGroups;
import dev.lumen.util.BlockScanner;
import dev.lumen.util.FriendCommands;
import dev.lumen.util.FriendsManager;
import dev.lumen.util.TargetManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.MissHitResult;
import net.minecraft.util.math.BlockPos;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Oyun mantigi testleri: gercek Lumen modul kodu, selftest/stubs altindaki Minecraft taklitleriyle calisir.
 * Taklitler gercek Minecraft degildir; bunlar mantigi dogrular, oyun ici testin yerini tutmaz.
 */
final class GameTest {
    static class Zombie extends LivingEntity implements Monster { Zombie() { typeName = "Zombie"; } }
    static class Cow extends LivingEntity { Cow() { typeName = "Cow"; } }
    static class Wolf extends TameableEntity { Wolf() { typeName = "Wolf"; } }

    static final MinecraftClient mc = MinecraftClient.getInstance();
    static ClientWorld world;
    static ClientPlayerEntity player;
    static ModuleManager mm;

    // ------------------------------------------------------------------ yardimcilar
    static void check(String n, boolean ok) { SelfTest.check(n, ok); }
    static void eq(String n, Object e, Object a) { SelfTest.eq(n, e, a); }

    static void newWorld() {
        world = new ClientWorld();
        player = new ClientPlayerEntity();
        player.typeName = "Player";
        world.entities.add(player);
        mc.world = world;
        mc.player = player;
        mc.singleplayer = true;
        mc.currentScreen = null;
        mc.crosshairTarget = null;
        mc.interactionManager = new ClientPlayerInteractionManager();
        TargetManager.clear();
        TargetManager.consumeLost();
        FriendsManager.deserialize("");
        FriendsManager.setProtection(true);
        FriendsManager.setOnChange(null);
        mm = new ModuleManager();
        Lumen.MODULES = mm;
        Lumen.AIM = new AimTraining();
        Lumen.TRIGGER = new TriggerBot();
    }

    static <T extends Entity> T spawn(T e, double x, double y, double z) {
        e.x = x; e.y = y; e.z = z;
        world.entities.add(e);
        return e;
    }

    static <F extends Feature> F on(F f) {
        mm.register(f);
        mm.set(f, true);
        return f;
    }

    @SuppressWarnings("unchecked")
    static <S extends Setting<?>> S st(Feature f, String name) {
        for (Setting<?> s : f.settings) if (s.name.equals(name)) return (S) s;
        throw new IllegalArgumentException("ayar yok: " + f.name + " / " + name);
    }

    static void num(Feature f, String name, double v) { ((Setting.Num) st(f, name)).set(v); }
    static void bool(Feature f, String name, boolean v) { ((Setting.Bool) st(f, name)).set(v); }
    static void mode(Feature f, String name, String v) { ((Setting.Mode) st(f, name)).load(v); }
    static void press(Feature f, String name) { ((Setting.Button) st(f, name)).run(); }

    static void look(Entity e) { mc.crosshairTarget = new EntityHitResult(e); }
    static void ticks(Feature f, int n) { for (int i = 0; i < n; i++) f.onTick(); }
    static int attacks() { return mc.interactionManager.attacked.size(); }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) { } }

    static void run() throws Exception {
        targetManager();
        targetControl();
        aimAssist();
        triggerBot();
        autoCrystal();
        aimTraining();
        errorIsolation();
        configPersistence();
        friendsIntegration();
        guiSettings();
        interactions();
        scanner();
        registration();
    }

    // ------------------------------------------------------------------ TargetManager
    static void targetManager() {
        System.out.println("== TargetManager");
        newWorld();
        check("tek oyunculu + tek oyuncu: guvenli dunya", TargetManager.isSafeWorld(mc));
        ClientPlayerEntity other = new ClientPlayerEntity();
        world.entities.add(other);
        check("dunyada 2. oyuncu: guvenli degil", !TargetManager.isSafeWorld(mc));
        world.entities.remove(other);
        mc.singleplayer = false;
        check("tek oyunculu degil (sunucu): guvenli degil", !TargetManager.isSafeWorld(mc));
        mc.singleplayer = true;
        mc.world = null;
        check("dunya yok: guvenli degil, istisna yok", !TargetManager.isSafeWorld(mc));
        mc.world = world;

        Zombie z = spawn(new Zombie(), 0, 0, 4);
        check("zombi gecerli", TargetManager.isValid(mc, z));
        check("inek gecerli", TargetManager.isValid(mc, spawn(new Cow(), 3, 0, 3)));
        check("oyuncu gecersiz", !TargetManager.isValid(mc, other));
        check("kendin gecersiz", !TargetManager.isValid(mc, player));
        check("zirh askisi gecersiz", !TargetManager.isValid(mc, spawn(new ArmorStandEntity(), 1, 0, 1)));
        Wolf wolf = spawn(new Wolf(), 2, 0, 2);
        check("evcillesmemis kurt gecerli", TargetManager.isValid(mc, wolf));
        wolf.tamed = true;
        check("evcil kurt gecersiz", !TargetManager.isValid(mc, wolf));
        Zombie dead = spawn(new Zombie(), 5, 0, 5);
        dead.alive = false;
        check("olu varlik gecersiz", !TargetManager.isValid(mc, dead));
        Zombie gone = spawn(new Zombie(), 6, 0, 6);
        gone.removed = true;
        check("silinmis varlik gecersiz", !TargetManager.isValid(mc, gone));
        check("null gecersiz", !TargetManager.isValid(mc, null));

        // arkadas korumasi (isim etiketli varlik)
        Zombie bob = spawn(new Zombie(), 1, 0, 5);
        bob.customName = "Bob";
        check("isim etiketli zombi arkadas degilken gecerli", TargetManager.isValid(mc, bob));
        FriendsManager.add("bOB");
        check("arkadas (harf duyarsiz) gecersiz", !TargetManager.isValid(mc, bob));
        check("adsiz zombi 'Zombie' adiyla eslesmez", FriendsManager.isFriend("Zombie") == false && TargetManager.isValid(mc, z));
        FriendsManager.add("Zombie");
        check("listede 'Zombie' olsa bile ADSIZ zombi korunmaz", TargetManager.isValid(mc, z));
        FriendsManager.setProtection(false);
        check("koruma kapaliyken arkadas gecerli", TargetManager.isValid(mc, bob));
        FriendsManager.setProtection(true);
        FriendsManager.remove("bob");
        check("arkadas silinince hemen gecerli", TargetManager.isValid(mc, bob));
        FriendsManager.deserialize("");

        // kilit yasam dongusu
        int v0 = TargetManager.version();
        TargetManager.lock(z);
        check("lock: get hedefi dondurur", TargetManager.get(mc) == z && TargetManager.hasLock());
        check("lock surumu artirir", TargetManager.version() > v0);
        z.alive = false;
        check("hedef olunce get null", TargetManager.get(mc) == null);
        check("olunce 'kayboldu' bir kez true", TargetManager.consumeLost() && !TargetManager.consumeLost());
        z.alive = true;

        TargetManager.lock(z);
        world.entities.remove(z);
        check("hedef dunyadan silinince (kimlik) get null + kayboldu", TargetManager.get(mc) == null && TargetManager.consumeLost());
        world.entities.add(z);

        TargetManager.lock(z);
        mc.singleplayer = false;
        check("guvenli olmayan dunyada kilit temizlenir (kayboldu sayilmaz)",
                TargetManager.get(mc) == null && !TargetManager.hasLock() && !TargetManager.consumeLost());
        mc.singleplayer = true;

        TargetManager.lock(bob);
        FriendsManager.add("Bob");
        check("kilitliyken arkadas eklenirse hedef birakilir", TargetManager.get(mc) == null && TargetManager.consumeLost());
        FriendsManager.deserialize("");

        // crosshair kilidi
        TargetManager.clear();
        look(z);
        TargetManager.toggleCrosshair(mc);
        check("toggleCrosshair kilitler", TargetManager.get(mc) == z);
        TargetManager.toggleCrosshair(mc);
        check("ayni hedefe tekrar: kilit kalkar", !TargetManager.hasLock());
        TargetManager.toggleCrosshair(mc);
        mc.crosshairTarget = new MissHitResult();
        TargetManager.toggleCrosshair(mc);
        check("baska yere bakinca kilit kalkar", !TargetManager.hasLock());
        look(world.entities.stream().filter(e -> e instanceof ArmorStandEntity).findFirst().get());
        TargetManager.lockCrosshair(mc);
        check("lockCrosshair zirh askisini kilitlemez", !TargetManager.hasLock());
        FriendsManager.add("Bob");
        look(bob);
        TargetManager.lockCrosshair(mc);
        check("lockCrosshair arkadasi kilitlemez", !TargetManager.hasLock());
        FriendsManager.deserialize("");

        // en yakin
        world.entities.removeIf(e -> e != player);
        Zombie near = spawn(new Zombie(), 0, 0, 3);
        spawn(new Zombie(), 0, 0, 6);
        spawn(new ArmorStandEntity(), 0, 0, 1);
        Cow bobCow = spawn(new Cow(), 0, 0, 2);
        bobCow.customName = "Bob";
        FriendsManager.add("bob");
        check("nearest: arkadas ve zirh askisi atlanir", TargetManager.nearest(mc, 10) == near);
        check("nearest: menzil disi null", TargetManager.nearest(mc, 2) == null);

        TargetManager.setAssist(near);
        check("assist gecerliyse doner", TargetManager.assist(mc) == near);
        near.alive = false;
        check("assist gecersizse temizlenir", TargetManager.assist(mc) == null);
        FriendsManager.deserialize("");
    }

    // ------------------------------------------------------------------ TargetControl (Auto Reselect)
    static void targetControl() {
        System.out.println("== TargetControl / Auto Reselect");
        newWorld();
        TargetControl tc = on(new TargetControl());
        Zombie a = spawn(new Zombie(), 0, 0, 4);
        Zombie b = spawn(new Zombie(), 0, 0, 6);
        TargetManager.lock(a);
        ticks(tc, 1);
        check("kilitli hedef korunur", TargetManager.get(mc) == a);
        a.alive = false;
        ticks(tc, 12);
        check("hedef olunce Auto Reselect en yakin gecerliyi secer", TargetManager.get(mc) == b);

        newWorld();
        tc = on(new TargetControl());
        a = spawn(new Zombie(), 0, 0, 4);
        b = spawn(new Zombie(), 0, 0, 6);
        TargetManager.lock(a);
        bool(tc, "Auto Reselect", false);
        a.alive = false;
        ticks(tc, 12);
        check("Auto Reselect kapaliyken yeniden secmez", !TargetManager.hasLock());

        newWorld();
        tc = on(new TargetControl());
        a = spawn(new Zombie(), 0, 0, 4);
        b = spawn(new Zombie(), 0, 0, 6);
        TargetManager.lock(a);
        a.alive = false;
        ticks(tc, 3);          // hedef kayboldu, arama basladi (henuz 10 tick dolmadi)
        TargetManager.clear(); // kullanici hedefi birakti (G / Clear Target)
        ticks(tc, 15);
        check("kullanici hedefi birakinca suren arama durur", !TargetManager.hasLock());

        newWorld();
        tc = on(new TargetControl());
        a = spawn(new Zombie(), 0, 0, 4);
        spawn(new Zombie(), 0, 0, 6);
        TargetManager.lock(a);
        mm.set(tc, false);
        a.alive = false;
        TargetManager.get(mc); // modul kapaliyken kayboldu bayragi kalir
        mm.set(tc, true);
        ticks(tc, 12);
        check("modul yeniden acilinca eski 'kayboldu' yeniden secimi tetiklemez", !TargetManager.hasLock());

        newWorld();
        tc = on(new TargetControl());
        Zombie c = spawn(new Zombie(), 0, 0, 5);
        bool(tc, "Lock Nearest", true);
        ticks(tc, 1);
        check("Lock Nearest en yakini kilitler ve bayragi sifirlar",
                TargetManager.get(mc) == c && !((Setting.Bool) st(tc, "Lock Nearest")).get());
        bool(tc, "Clear Target", true);
        ticks(tc, 1);
        check("Clear Target kilidi kaldirir", !TargetManager.hasLock());
        mc.singleplayer = false;
        TargetManager.lock(c);
        ticks(tc, 1);
        check("guvenli olmayan dunyada kilit temizlenir", !TargetManager.hasLock());
    }

    // ------------------------------------------------------------------ AimAssist
    static void aimAssist() {
        System.out.println("== Aim Assist");
        newWorld();
        AimAssist aa = on(new AimAssist());
        Zombie z = spawn(new Zombie(), -2, 0, 4); // saga/sola ~26.6 derece
        ticks(aa, 1);
        check("Target Lock acik + kilit yok: bekler, donmez", player.yaw == 0f && player.pitch == 0f);
        check("bekleme durumu aciklayici", aa.status().contains("lock a target"));

        TargetManager.lock(z);
        ticks(aa, 1);
        check("kilitli hedefe dogru doner (yaw artti)", player.yaw > 0f && player.yaw < 26.6f);
        check("Aim Speed/Smoothness: adim ~2.66 derece", Math.abs(player.yaw - 2.66f) < 0.1f);
        check("pitch de hedefe dogru (asagi)", player.pitch > 0f);
        check("durum hedef adini ve [LOCK] yazar", aa.status().contains("Zombie") && aa.status().contains("[LOCK]"));

        player.yaw = 0; player.pitch = 0;
        num(aa, "Aim Speed", 100); num(aa, "Smoothness", 1);
        ticks(aa, 1);
        check("hizli ayar: adim 20 dereceyle sinirli", Math.abs(player.yaw - 20f) < 0.001f);

        player.yaw = 0; player.pitch = 0;
        num(aa, "Aim Speed", 40); num(aa, "Smoothness", 30);
        num(aa, "Horizontal Sensitivity", 0);
        ticks(aa, 1);
        check("Horizontal Sensitivity 0: yaw degismez, pitch degisir", player.yaw == 0f && player.pitch > 0f);
        player.pitch = 0;
        num(aa, "Horizontal Sensitivity", 100); num(aa, "Vertical Sensitivity", 0);
        ticks(aa, 1);
        check("Vertical Sensitivity 0: pitch degismez, yaw degisir", player.pitch == 0f && player.yaw > 0f);
        num(aa, "Vertical Sensitivity", 100);

        player.yaw = 0; player.pitch = 0;
        num(aa, "FOV", 20);
        ticks(aa, 1);
        check("FOV disindaki hedefe donmez", player.yaw == 0f && aa.status().contains("outside FOV"));
        num(aa, "FOV", 90);

        num(aa, "Target Range", 3);
        ticks(aa, 1);
        check("menzil disindaki hedefe donmez", player.yaw == 0f && aa.status().contains("out of range"));
        num(aa, "Target Range", 4.5);

        // menzilden cikan kilit temizlenir
        z.z = 20;
        ticks(aa, 1);
        check("hedef cok uzaklasinca kilit birakilir (Clear Lock When Lost)", !TargetManager.hasLock());
        z.z = 4;

        // guvenli olmayan dunya
        TargetManager.lock(z);
        mc.singleplayer = false;
        player.yaw = 0;
        ticks(aa, 1);
        check("sunucuda donmez", player.yaw == 0f && aa.status().contains("singleplayer only"));
        mc.singleplayer = true;

        // ekran acikken donmez
        mc.currentScreen = new Screen();
        ticks(aa, 1);
        check("ekran acikken donmez", player.yaw == 0f);
        mc.currentScreen = null;

        // otomatik hedef (Target Lock kapali)
        newWorld();
        aa = on(new AimAssist());
        bool(aa, "Target Lock", false);
        spawn(new ArmorStandEntity(), 0, 0, 2);
        Cow bobCow = spawn(new Cow(), 1, 0, 3);
        bobCow.customName = "Bob";
        FriendsManager.add("Bob");
        ticks(aa, 3);
        check("otomatik secim: yalnizca arkadas/zirh askisi varsa hedef yok, donmez", player.yaw == 0f);
        Zombie auto = spawn(new Zombie(), -2, 0, 4);
        ticks(aa, 3);
        check("otomatik secim gecerli mobu bulur ve doner", player.yaw > 0f && aa.status().contains("[AUTO]"));
        FriendsManager.deserialize("");

        // hostile only
        newWorld();
        aa = on(new AimAssist());
        bool(aa, "Target Lock", false);
        spawn(new Cow(), -2, 0, 4);
        bool(aa, "Hostile Only", true);
        ticks(aa, 3);
        check("Hostile Only: inege donmez", player.yaw == 0f);
        bool(aa, "Hostile Only", false);
        ticks(aa, 3);
        check("Hostile Only kapali: inege doner", player.yaw > 0f);

        // gorunmez varliklar
        newWorld();
        aa = on(new AimAssist());
        bool(aa, "Target Lock", false);
        Zombie inv = spawn(new Zombie(), -2, 0, 4);
        inv.invisible = true;
        ticks(aa, 3);
        check("Invisible Entities kapali: gorunmezi secmez", player.yaw == 0f);
        bool(aa, "Invisible Entities", true);
        ticks(aa, 3);
        check("Invisible Entities acik: gorunmezi secer", player.yaw > 0f);

        // ORTAK HEDEF: Target Lock kapaliyken bile kilitli hedef varsa herkes onu kullanir
        newWorld();
        aa = on(new AimAssist());
        bool(aa, "Target Lock", false);
        Zombie left = spawn(new Zombie(), -2, 0, 4);  // yaw +
        Zombie right = spawn(new Zombie(), 2, 0, 4);  // yaw - (ayni uzaklik, aksi yon)
        TargetManager.lock(right);
        ticks(aa, 3);
        check("Target Lock kapali + kilit var: kilitli (sagdaki) hedefe doner, yakin olana degil", player.yaw < 0f);

        // hedef kaybolunca eski hedefi birakir
        right.alive = false;
        float yawBefore = player.yaw;
        ticks(aa, 3);
        check("kilitli hedef olunce eski hedefi birakir (otomatige gecer)", TargetManager.get(mc) == null && player.yaw > yawBefore);

        // dunya degisimi: eski dunyanin varligina donmemeli
        newWorld();
        aa = on(new AimAssist());
        bool(aa, "Target Lock", false);
        spawn(new Zombie(), -2, 0, 4);
        ticks(aa, 3);
        float moved = player.yaw;
        check("(hazirlik) otomatik hedefe dondu", moved > 0f);
        ClientWorld oldWorld = world;
        newWorld2(aa);
        ticks(aa, 4);
        check("dunya degisince eski dunyanin hedefi birakilir", player.yaw == 0f);
        check("(oldWorld referansi) hedefsiz yeni dunya", oldWorld != world);

        // NPE guvencesi
        mc.world = null;
        mc.player = null;
        boolean ok = true;
        try { aa.onTick(); aa.onHud(new DrawContext(), 100, 100); } catch (RuntimeException e) { ok = false; }
        check("dunya/oyuncu yokken istisna yok", ok);
    }

    /** Lumen.onInitializeClient'taki dunya degisimi akisinin ayni sirasi: yeni dunya + temizlik + worldChanged. */
    static void newWorld2(Feature... keep) {
        ModuleManager old = mm;
        world = new ClientWorld();
        player = new ClientPlayerEntity();
        world.entities.add(player);
        mc.world = world;
        mc.player = player;
        mc.crosshairTarget = null;
        TargetManager.clear();
        old.worldChanged();
    }

    // ------------------------------------------------------------------ TriggerBot
    static TriggerBot freshTrigger() {
        newWorld();
        TriggerBot tb = on(new TriggerBot());
        Lumen.TRIGGER = tb;
        num(tb, "Delay", 0);
        num(tb, "Cooldown", 0);
        return tb;
    }

    static void triggerBot() {
        System.out.println("== Trigger Bot");
        TriggerBot tb = freshTrigger();
        Zombie z = spawn(new Zombie(), 0, 0, 3);
        Cow cow = spawn(new Cow(), 1, 0, 3);

        look(z);
        ticks(tb, 2);
        check("Target Only acik + kilit yok: saldirmaz", attacks() == 0);
        check("durum nedeni aciklar", tb.status().contains("lock a target"));
        check("saldirmayinca istatistik artmaz", tb.hits() == 0 && tb.attempts() == 0 && tb.misses() == 0);

        TargetManager.lock(z);
        ticks(tb, 1);
        check("kilitli zombi + Hostile filtre: vurur", attacks() == 1 && tb.hits() == 1 && tb.attempts() == 1);

        // Target Only + Target Filter birlikte
        TargetManager.lock(cow);
        look(cow);
        int a0 = attacks();
        ticks(tb, 1);
        check("Target Only: kilitli INEK + Hostile Mobs filtresi: vurmaz (filtre de gecerli)", attacks() == a0 && tb.status().contains("filtered"));
        mode(tb, "Target Filter", "All Mobs");
        ticks(tb, 1);
        check("All Mobs: kilitli inek vurulur", attacks() == a0 + 1);
        mode(tb, "Target Filter", "Passive Mobs");
        TargetManager.lock(z);
        look(z);
        a0 = attacks();
        ticks(tb, 1);
        check("Passive Mobs: kilitli zombi vurulmaz", attacks() == a0);
        TargetManager.lock(cow);
        look(cow);
        ticks(tb, 1);
        check("Passive Mobs: kilitli inek vurulur", attacks() == a0 + 1);

        // Target Only kapali: yalnizca filtre
        bool(tb, "Target Only", false);
        TargetManager.clear();
        mode(tb, "Target Filter", "Hostile Mobs");
        look(z); a0 = attacks(); ticks(tb, 1);
        check("Target Only kapali + Hostile: zombi vurulur", attacks() == a0 + 1);
        look(cow); a0 = attacks(); ticks(tb, 1);
        check("Target Only kapali + Hostile: inek vurulmaz", attacks() == a0);
        mode(tb, "Target Filter", "Passive Mobs");
        look(cow); a0 = attacks(); ticks(tb, 1);
        check("Target Only kapali + Passive: inek vurulur", attacks() == a0 + 1);
        look(z); a0 = attacks(); ticks(tb, 1);
        check("Target Only kapali + Passive: zombi vurulmaz", attacks() == a0);
        mode(tb, "Target Filter", "All Mobs");
        look(z); a0 = attacks(); ticks(tb, 1);
        look(cow); ticks(tb, 1);
        check("Target Only kapali + All Mobs: ikisi de vurulur", attacks() == a0 + 2);

        // gecersiz varliklar ve arkadas
        ArmorStandEntity stand = spawn(new ArmorStandEntity(), 0, 0, 2);
        look(stand); a0 = attacks(); ticks(tb, 3);
        check("zirh askisina vurmaz (All Mobs bile)", attacks() == a0);
        Wolf wolf = spawn(new Wolf(), 0, 0, 2);
        wolf.tamed = true;
        look(wolf); ticks(tb, 3);
        check("evcil kurda vurmaz (All Mobs bile)", attacks() == a0);
        Zombie bob = spawn(new Zombie(), 0, 0, 2);
        bob.customName = "Bob";
        FriendsManager.add("BOB");
        look(bob); ticks(tb, 3);
        check("arkadasa vurmaz", attacks() == a0);
        FriendsManager.remove("bob");
        ticks(tb, 1);
        check("arkadas silinince ayni tick'ten itibaren hedef olur", attacks() == a0 + 1);

        // silah cooldown
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        look(z);
        player.cooldown = 0.5f;
        ticks(tb, 3);
        check("Weapon Cooldown acik: silah dolmadan vurmaz", attacks() == 0);
        player.cooldown = 1.0f;
        ticks(tb, 1);
        check("silah dolunca vurur", attacks() == 1);
        player.cooldown = 0.5f;
        bool(tb, "Weapon Cooldown", false);
        ticks(tb, 1);
        check("Weapon Cooldown kapali: dolmadan vurur", attacks() == 2);

        // Cooldown (ms)
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        num(tb, "Cooldown", 200);
        look(z);
        ticks(tb, 3);
        check("Cooldown 200ms: hizli tick'lerde tek vurus", attacks() == 1);
        sleep(260);
        ticks(tb, 1);
        check("Cooldown bitince tekrar vurur", attacks() == 2);

        // Delay (ms)
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        num(tb, "Delay", 300);
        look(z);
        ticks(tb, 2);
        check("Delay 300ms: hedef alinir alinmaz vurmaz", attacks() == 0);
        sleep(340);
        ticks(tb, 1);
        check("Delay dolunca vurur", attacks() == 1);

        // kapatinca zamanlayici/hedef temizlenir
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        num(tb, "Delay", 300);
        look(z);
        ticks(tb, 1);
        sleep(340);
        mm.set(tb, false);
        mm.set(tb, true);
        ticks(tb, 1);
        check("kapat-ac: eski hedef/zamanlayici temizlenir, gecikme bastan baslar", attacks() == 0);

        // ekran acikken hedef tutulmaz
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        num(tb, "Delay", 250);
        look(z);
        ticks(tb, 1);
        mc.currentScreen = new Screen();
        sleep(300);
        ticks(tb, 1);
        mc.currentScreen = null;
        ticks(tb, 1);
        check("ekran acikken saldirmaz ve kapaninca gecikme bastan baslar", attacks() == 0);

        // istatistik: HIT / MISS / SKIP
        tb = freshTrigger();
        z = spawn(new Zombie(), 0, 0, 3);
        bool(tb, "Target Only", false);
        look(z);
        num(tb, "Hit Chance", 0); num(tb, "Miss Chance", 100);
        ticks(tb, 5);
        check("Hit 0 / Miss 100: bos savurur, vurmaz", attacks() == 0 && tb.misses() == 5 && tb.attempts() == 5 && tb.hits() == 0);
        check("bos savurma el sallar", player.swings == 5);
        num(tb, "Hit Chance", 0); num(tb, "Miss Chance", 0);
        ticks(tb, 5);
        check("Hit 0 / Miss 0 (SKIP): istatistik artmaz", tb.attempts() == 5 && attacks() == 0);
        num(tb, "Hit Chance", 100); num(tb, "Miss Chance", 50);
        ticks(tb, 1);
        check("Hit 100: miss sinirlanir ve vurur", attacks() == 1 && ((Setting.Num) st(tb, "Miss Chance")).i() == 0);
        press(tb, "Reset Statistics");
        check("Reset Statistics sifirlar", tb.hits() == 0 && tb.misses() == 0 && tb.attempts() == 0);

        // kendi tiklarin (her dunyada)
        mc.singleplayer = false;
        look(z);
        tb.onManualAttack();
        mc.crosshairTarget = new MissHitResult();
        tb.onManualAttack();
        check("sunucuda kendi tiklarin sayilir (1 isabet, 1 kacirma)", tb.hits() == 1 && tb.misses() == 1 && tb.attempts() == 2);
        mc.currentScreen = new Screen();
        look(z);
        tb.onManualAttack();
        mc.currentScreen = null;
        check("ekran acikken tiklama sayilmaz", tb.attempts() == 2);
        int atkBefore = attacks();
        ticks(tb, 3);
        check("sunucuda otomatik saldiri yok", attacks() == atkBefore);
        check("sunucuda durum aciklayici", tb.status().contains("singleplayer only"));
    }

    // ------------------------------------------------------------------ AutoCrystal
    static AutoCrystal crystalSetup(Zombie[] target) {
        newWorld();
        AutoCrystal ac = on(new AutoCrystal());
        Zombie z = spawn(new Zombie(), 1.5, 0, 1.5);
        world.blocks.put(new BlockPos(2, -1, 1), Blocks.OBSIDIAN);
        TargetManager.lock(z);
        target[0] = z;
        return ac;
    }

    static void autoCrystal() {
        System.out.println("== Auto Crystal");
        Zombie[] t = new Zombie[1];
        AutoCrystal ac = crystalSetup(t);
        check("varsayilan: Simulation Only ACIK", ((Setting.Bool) st(ac, "Simulation Only")).get());
        check("varsayilan: Require Creative ACIK", ((Setting.Bool) st(ac, "Require Creative")).get());
        ticks(ac, 1);
        check("simulasyon: yerlestirme plani gosterir", ac.status().equals("SIM: place crystal"));
        check("simulasyon: hicbir sey yerlestirmez/vurmaz", mc.interactionManager.interacted.isEmpty() && attacks() == 0);
        check("hasar tahmini 'yaklasik' diye isaretli", ac.estimate().contains("approx") && ac.estimate().contains("~"));

        mc.currentScreen = new Screen();
        ticks(ac, 1);
        check("ekran acikken duraklar ve dogru mesaj verir", ac.status().startsWith("Paused"));
        mc.currentScreen = null;
        mc.singleplayer = false;
        ticks(ac, 1);
        check("sunucuda: 'Only in singleplayer'", ac.status().equals("Only in singleplayer"));
        mc.singleplayer = true;

        TargetManager.clear();
        ticks(ac, 1);
        check("hedef yokken aciklayici durum", ac.status().contains("No target"));

        ac = crystalSetup(t);
        world.blocks.clear();
        ticks(ac, 1);
        check("obsidyen yoksa hata vermez, aciklar", ac.status().contains("No obsidian"));

        ac = crystalSetup(t);
        Cow blocker = spawn(new Cow(), 2.5, 0, 1.5); // yerlestirme kutusunda varlik
        ticks(ac, 1);
        check("yerlestirme kutusunda varlik varsa o nokta secilmez", ac.status().contains("No obsidian"));
        world.entities.remove(blocker);
        ticks(ac, 1);
        check("varlik gidince nokta tekrar uygun", ac.status().equals("SIM: place crystal"));

        // sim kapali + Creative gerekli + Survival
        ac = crystalSetup(t);
        bool(ac, "Simulation Only", false);
        ticks(ac, 1);
        check("Survival + Require Creative: yerlestirmez, 'Creative required'", ac.status().equals("Creative required") && mc.interactionManager.interacted.isEmpty());

        // sim kapali + Creative: gercek yerlestirme (bekleme sureleriyle)
        player.creative = true;
        ticks(ac, 1);
        check("kristal elde degilse uyarir", ac.status().equals("Hold End Crystal") && mc.interactionManager.interacted.isEmpty());
        player.main = new ItemStack(Items.END_CRYSTAL);
        num(ac, "Place Delay", 200);
        ticks(ac, 1);
        check("Creative + kristal: yerlestirir", mc.interactionManager.interacted.size() == 1);
        ticks(ac, 2);
        check("Place Delay: hizli tick'lerde tekrar yerlestirmez", mc.interactionManager.interacted.size() == 1);
        sleep(260);
        ticks(ac, 1);
        check("bekleme bitince tekrar yerlestirir", mc.interactionManager.interacted.size() == 2);

        // mevcut kristali kirma
        ac = crystalSetup(t);
        EndCrystalEntity crystal = spawn(new EndCrystalEntity(), 2.5, 0, 1.5);
        ticks(ac, 1);
        check("simulasyonda kristal kirma plani", ac.status().equals("SIM: break crystal") && attacks() == 0);
        bool(ac, "Simulation Only", false);
        player.creative = true;
        ticks(ac, 1);
        check("Creative: menzildeki kristali kirar", attacks() == 1 && ac.status().equals("Breaking crystal"));
        crystal.x = 30;
        ticks(ac, 1);
        check("menzil disi kristale saldirmaz", attacks() == 1);

        // kapatinca temizlik
        ac = crystalSetup(t);
        ticks(ac, 1);
        mm.set(ac, false);
        check("kapatinca durum ve plan temizlenir", ac.status().equals("Idle") && ac.estimate().isEmpty());
    }

    // ------------------------------------------------------------------ AimTraining
    static void aimTraining() {
        System.out.println("== Aim Training");
        newWorld();
        AimTraining at = on(new AimTraining());
        Lumen.AIM = at;
        Zombie z = spawn(new Zombie(), 0, 0, 3);
        look(z);
        bool(at, "Auto Hit", true);
        ticks(at, 1);
        check("Auto Hit: tek oyunculuda zombiye vurur", attacks() == 1 && at.hits() == 1);
        player.cooldown = 0.5f;
        ticks(at, 1);
        check("silah dolmadan vurmaz", attacks() == 1);
        player.cooldown = 1f;

        Zombie bob = spawn(new Zombie(), 0, 0, 2);
        bob.customName = "Bob";
        FriendsManager.add("bob");
        look(bob);
        ticks(at, 1);
        check("Auto Hit arkadasa vurmaz", attacks() == 1);
        FriendsManager.deserialize("");

        look(spawn(new Cow(), 0, 0, 2));
        ticks(at, 1);
        check("Auto Hit yalnizca dusman (Monster) mobu hedefler", attacks() == 1);

        look(z);
        mc.singleplayer = false;
        ticks(at, 1);
        check("sunucuda Auto Hit calismaz (ortak guvenli dunya kontrolu)", attacks() == 1);
        at.onAttack();
        check("sunucuda istatistik de sayilmaz", at.swings() == 1);
        mc.singleplayer = true;

        ClientPlayerEntity second = new ClientPlayerEntity();
        world.entities.add(second);
        ticks(at, 1);
        check("dunyada baska oyuncu varken Auto Hit calismaz", attacks() == 1);
        world.entities.remove(second);

        TriggerBot tb = on(new TriggerBot());
        Lumen.TRIGGER = tb;
        ticks(at, 1);
        check("Trigger Bot aciksa Auto Hit saldirmaz (cift vurus yok)", attacks() == 1);
        mm.set(tb, false);

        mc.crosshairTarget = new MissHitResult();
        int before = at.swings();
        at.onAttack();
        check("bosa tiklama kacirma olarak sayilir", at.swings() == before + 1 && at.hits() == 1);
        bool(at, "Reset Stats", true);
        ticks(at, 1);
        check("Reset Stats istatistigi sifirlar ve bayragi indirir", at.hits() == 0 && at.swings() == 0);
    }

    // ------------------------------------------------------------------ hata yalitimi
    static class Probe extends Feature {
        int ticks, disables, worldChanges, huds;
        RuntimeException enableFail, tickFail;
        Error tickLinkage, hudLinkage;
        boolean disableFails, worldFails;
        String[] conflict = new String[0];

        Probe(String name) { super(name, "test", Category.MISC); }
        @Override protected void onEnable() { if (enableFail != null) throw enableFail; }
        @Override protected void onDisable() { disables++; if (disableFails) throw new IllegalStateException("kapatma hatasi"); }
        @Override public void onTick() {
            ticks++;
            if (tickFail != null) throw tickFail;
            if (tickLinkage != null) throw tickLinkage;
        }
        @Override public void onHud(DrawContext c, int w, int h) {
            huds++;
            if (hudLinkage != null) throw hudLinkage;
        }
        @Override public void onWorldChange() { worldChanges++; if (worldFails) throw new IllegalStateException("dunya hatasi"); }
        @Override public String[] conflicts() { return conflict; }
    }

    static void errorIsolation() {
        System.out.println("== ModuleManager / hata yalitimi");
        newWorld();
        Probe good = on(new Probe("Good"));
        Probe boom = new Probe("Boom");
        boom.enableFail = new IllegalStateException("acilis hatasi");
        mm.register(boom);
        int e0 = org.slf4j.Logger.errors;
        mm.set(boom, true);
        check("onEnable hata verirse modul ACIK kalmaz", !boom.isEnabled());
        check("basarisiz acilista onDisable temizligi cagrilir", boom.disables == 1);
        check("hata gercek istisnayla loglanir (yigin izi)", org.slf4j.Logger.errors == e0 + 1
                && org.slf4j.Logger.lastError == boom.enableFail);
        mm.tick();
        check("basarisiz modul tick almaz, diger modul calisir", boom.ticks == 0 && good.ticks == 1);

        Probe link = new Probe("Link");
        link.enableFail = null;
        mm.register(link);
        mm.set(link, true);
        link.tickLinkage = new NoSuchMethodError("class_9999.method_1");
        e0 = org.slf4j.Logger.errors;
        mm.tick();
        check("API uyumsuzlugu (NoSuchMethodError) tek modulu kapatir, istemci cokmez", !link.isEnabled() && good.isEnabled());
        check("hata bir kez loglandi", org.slf4j.Logger.errors == e0 + 1);
        mm.tick(); mm.tick();
        check("ayni hata tekrar tekrar yazilmaz, saglam modul her tick calisir", org.slf4j.Logger.errors == e0 + 1 && good.ticks == 4);

        Probe tickBoom = on(new Probe("TickBoom"));
        tickBoom.tickFail = new IllegalArgumentException("tick hatasi");
        e0 = org.slf4j.Logger.errors;
        mm.tick();
        mm.tick();
        check("tick hatasi: modul kapanir, tek log", !tickBoom.isEnabled() && org.slf4j.Logger.errors == e0 + 1 && tickBoom.ticks == 1);

        Probe hudBoom = on(new Probe("HudBoom"));
        hudBoom.hudLinkage = new NoClassDefFoundError("x");
        mm.renderHud(new DrawContext(), 100, 100);
        check("HUD cizim hatasi (LinkageError) modulu kapatir", !hudBoom.isEnabled() && good.huds == 1);

        Probe a = on(new Probe("A"));
        Probe b = on(new Probe("B"));
        a.conflict = new String[]{"B"};
        mm.set(a, false);
        mm.set(a, true);
        check("catisan modul: A acilinca B kapanir", a.isEnabled() && !b.isEnabled());

        Probe off = on(new Probe("OffBoom"));
        off.disableFails = true;
        mm.set(off, false);
        check("onDisable hata verse de modul kapali ve istemci calisir", !off.isEnabled());

        Probe w1 = on(new Probe("W1")), w2 = new Probe("W2");
        mm.register(w2);
        w1.worldFails = true;
        e0 = org.slf4j.Logger.errors;
        mm.worldChanged();
        check("worldChanged tum modullere (kapali dahil) ulasir, hata digerlerini durdurmaz",
                w1.worldChanges == 1 && w2.worldChanges == 1 && good.worldChanges == 1 && org.slf4j.Logger.errors == e0 + 1);
    }

    // ------------------------------------------------------------------ Config kaliciligi (gercek dosya)
    static List<Feature> allCombat() {
        List<Feature> l = new ArrayList<>();
        l.add(new AimTraining());
        l.add(new TargetHud());
        l.add(new TargetControl());
        l.add(new AimAssist());
        l.add(new TriggerBot());
        l.add(new AutoCrystal());
        l.add(new Friends());
        return l;
    }

    static String snapshot(ModuleManager m) {
        StringBuilder sb = new StringBuilder();
        for (Feature f : m.all()) {
            sb.append(f.name).append(" enabled=").append(f.isEnabled()).append('\n');
            for (Setting<?> s : f.settings) if (s.persistent()) sb.append("  ").append(s.name).append('=').append(s.save()).append('\n');
        }
        return sb.toString();
    }

    static void configPersistence() throws Exception {
        System.out.println("== Config (gercek dosya)");
        Path dir = Files.createTempDirectory("lumen-config");
        FabricLoader.configDir = dir;
        newWorld();
        FriendsManager.setOnChange(Config::markDirty);

        ModuleManager m1 = new ModuleManager();
        for (Feature f : allCombat()) m1.register(f);
        Lumen.MODULES = m1;
        Feature aim = m1.in(Category.COMBAT).stream().filter(f -> f.name.equals("Aim Assist")).findFirst().get();
        Feature trig = m1.in(Category.COMBAT).stream().filter(f -> f.name.equals("Trigger Bot")).findFirst().get();
        Feature fr = m1.in(Category.COMBAT).stream().filter(f -> f.name.equals("Friends")).findFirst().get();
        m1.set(aim, true);
        m1.set(trig, true);
        m1.set(fr, true);
        num(aim, "Aim Speed", 77); num(aim, "FOV", 120); num(aim, "Target Range", 6.5);
        mode(aim, "Aim Priority", "Head");
        bool(aim, "Target Lock", false);
        ((Setting.Color) st(aim, "Indicator Color")).load("00FF88");
        num(trig, "Delay", 120); num(trig, "Cooldown", 400); mode(trig, "Target Filter", "All Mobs");
        bool(trig, "Target Only", false);
        FriendsManager.add("Steve"); FriendsManager.add("Alex_9");
        Config.markDirty();
        Config.saveIfDirty(m1);
        check("Combat modullerinin ayar dosyalari yazildi",
                Files.isRegularFile(dir.resolve("lumen/aim-assist.properties"))
                        && Files.isRegularFile(dir.resolve("lumen/trigger-bot.properties"))
                        && Files.isRegularFile(dir.resolve("lumen/friends.properties")));
        check("friends.properties listeyi icerir",
                Files.readString(dir.resolve("lumen/friends.properties"), StandardCharsets.UTF_8).contains("Friends List=Steve,Alex_9"));
        String before = snapshot(m1);

        // "oyunu yeniden ac"
        FriendsManager.deserialize("");
        ModuleManager m2 = new ModuleManager();
        for (Feature f : allCombat()) m2.register(f);
        Lumen.MODULES = m2;
        Config.load(m2);
        eq("yeniden acilista TUM ayarlar ve acik/kapali durumlar ayni", before, snapshot(m2));
        eq("arkadas listesi yeniden acilista korundu", List.of("Steve", "Alex_9"), FriendsManager.list());
        check("Friends Protection (modul acik) korundu", FriendsManager.protectionOn());

        // degisiklik olmadan tekrar kaydetme dosyayi yeniden yazmaz
        long mod = Files.getLastModifiedTime(dir.resolve("lumen/aim-assist.properties")).toMillis();
        Config.markDirty();
        Config.saveIfDirty(m2);
        check("icerik ayniysa dosya yeniden yazilmaz", Files.getLastModifiedTime(dir.resolve("lumen/aim-assist.properties")).toMillis() == mod);

        // GUI "Reset to Defaults" arkadas listesini silmez
        Feature fr2 = m2.in(Category.COMBAT).stream().filter(f -> f.name.equals("Friends")).findFirst().get();
        for (Setting<?> s : fr2.settings) s.reset();
        eq("Reset to Defaults arkadas listesini silmez", 2, FriendsManager.count());

        // bozuk dosya
        Files.writeString(dir.resolve("lumen/aim-assist.properties"),
                "_enabled=maybe\nAim Speed=abc\nFOV=9999\nAim Priority=Nope\nIndicator Color=ZZZ\nTarget Range=-5\n=bos\nkirik satir\n#yorum\n", StandardCharsets.UTF_8);
        Files.write(dir.resolve("lumen/trigger-bot.properties"), new byte[]{(byte) 0xFF, (byte) 0xFE, 0, 1, 2, '\n', (byte) 0x80});
        Files.writeString(dir.resolve("lumen/friends.properties"), "_enabled=true\nFriends List=,,,a=b,Steve,STEVE,x\u0000y,,veryveryveryveryveryveryveryverylongname1\n", StandardCharsets.UTF_8);
        FriendsManager.deserialize("");
        ModuleManager m3 = new ModuleManager();
        for (Feature f : allCombat()) m3.register(f);
        Lumen.MODULES = m3;
        int w0 = org.slf4j.Logger.warns;
        boolean ok = true;
        try { Config.load(m3); } catch (RuntimeException e) { ok = false; }
        check("bozuk ayar dosyalari oyunu cokertmez", ok);
        Feature aim3 = m3.in(Category.COMBAT).stream().filter(f -> f.name.equals("Aim Assist")).findFirst().get();
        eq("gecersiz sayi: varsayilan kalir", "40.0", ((Setting.Num) st(aim3, "Aim Speed")).save());
        eq("sinir disi sayi sinira kirpilir", "180.0", ((Setting.Num) st(aim3, "FOV")).save());
        eq("negatif menzil alt sinira kirpilir", "1.0", ((Setting.Num) st(aim3, "Target Range")).save());
        eq("gecersiz secenek: varsayilan kalir", "Body", ((Setting.Mode) st(aim3, "Aim Priority")).get());
        eq("gecersiz renk: varsayilan kalir", "E5484D", ((Setting.Color) st(aim3, "Indicator Color")).save());
        check("_enabled=maybe -> kapali", !aim3.isEnabled());
        Feature trig3 = m3.in(Category.COMBAT).stream().filter(f -> f.name.equals("Trigger Bot")).findFirst().get();
        eq("okunamayan (bozuk bayt) dosya: varsayilanlar", "50.0", ((Setting.Num) st(trig3, "Delay")).save());
        eq("bozuk arkadas listesi: yalnizca gecerli ve tekrarsiz", List.of("Steve"), FriendsManager.list());
        check("okunamayan dosyanin sebebi loglandi", org.slf4j.Logger.warns > w0);

        // atomik yazma: gecici dosya kalmaz
        FriendsManager.setOnChange(Config::markDirty);
        FriendsManager.add("Zed");
        Config.saveIfDirty(m3);
        try (var s = Files.list(dir.resolve("lumen"))) {
            check("kayit sonrasi .tmp dosyasi kalmadi", s.noneMatch(p -> p.toString().endsWith(".tmp")));
        }
        FriendsManager.setOnChange(null);
    }

    // ------------------------------------------------------------------ Friends: komut + GUI senkron
    static void friendsIntegration() throws Exception {
        System.out.println("== Friends: komut <-> GUI senkron");
        Path dir = Files.createTempDirectory("lumen-friends");
        FabricLoader.configDir = dir;
        newWorld();
        FriendsManager.setOnChange(Config::markDirty);
        Friends fr = on(new Friends());
        Lumen.MODULES = mm;

        check("sohbet mesaji komut degilse false", !FriendCommands.handle(mc, "merhaba"));
        check(".f add komutu islenir (true)", FriendCommands.handle(mc, ".f add Bob"));
        check("komut sonucu oyuncuya yazilir", player.messages.get(player.messages.size() - 1).startsWith("Arkadas eklendi"));
        check("komut listeyi HEMEN diske yazar", Files.readString(dir.resolve("lumen/friends.properties"), StandardCharsets.UTF_8).contains("Bob"));
        eq("GUI 'Friend Count' komutla senkron", "1", ((Setting.Info) st(fr, "Friend Count")).text());
        eq("GUI 'Friends List' komutla senkron", "Bob", ((Setting.Info) st(fr, "Friends List")).text());
        eq("GUI 'Friends Protection' ON", "ON", ((Setting.Info) st(fr, "Friends Protection")).text());

        ((Setting.Text) st(fr, "Friend Name")).set("zed");
        press(fr, "Add Friend");
        check("GUI Add Friend listeye ekler ve alani temizler", FriendsManager.isFriend("ZED") && ((Setting.Text) st(fr, "Friend Name")).get().isEmpty());
        FriendCommands.handle(mc, ".f list");
        check(".f list GUI'den eklenen arkadasi da gosterir", player.messages.get(player.messages.size() - 1).contains("zed"));
        ((Setting.Text) st(fr, "Friend Name")).set("BOB");
        press(fr, "Remove Friend");
        check("GUI Remove Friend (harf duyarsiz) siler", !FriendsManager.isFriend("bob") && FriendsManager.count() == 1);
        press(fr, "Remove Friend");
        check("bos isimle silmek hata vermez", FriendsManager.count() == 1);
        FriendCommands.handle(mc, ".f remove ZED");
        eq("komutla silince GUI sayaci 0", "0", ((Setting.Info) st(fr, "Friend Count")).text());

        mm.set(fr, false);
        eq("modul KAPALI: Friends Protection OFF", "OFF", ((Setting.Info) st(fr, "Friends Protection")).text());
        check("koruma kapaliyken arkadas hedeflenebilir", !FriendsManager.protectionOn());
        mm.set(fr, true);
        check("modul acilinca koruma geri gelir", FriendsManager.protectionOn());
        FriendsManager.setOnChange(null);
    }

    // ------------------------------------------------------------------ GUI ayarlari dogrulamasi
    static void guiSettings() throws Exception {
        System.out.println("== GUI ayar dogrulamasi");
        newWorld();
        List<Feature> mods = allCombat();
        for (Feature f : mods) mm.register(f);

        List<String> names = new ArrayList<>();
        boolean allCombat = true, descs = true;
        for (Feature f : mods) {
            allCombat &= f.category == Category.COMBAT;
            descs &= f.description != null && f.description.length() > 10;
            names.add(f.name);
        }
        check("7 Combat modulunun hepsi Combat kategorisinde", allCombat && mm.in(Category.COMBAT).size() == 7);
        check("modul aciklamalari dolu", descs);
        check("modul adlari benzersiz", names.stream().distinct().count() == names.size());

        for (Feature f : mods) {
            List<String> sn = new ArrayList<>();
            boolean bad = false;
            String why = "";
            for (Setting<?> s : f.settings) {
                sn.add(s.name);
                if (s.name == null || s.name.isBlank()) { bad = true; why = "bos ad"; }
                if (s instanceof Setting.Num n) {
                    if (!(n.min < n.max) || !(n.step > 0)) { bad = true; why = n.name + " aralik/adim"; }
                    double d = n.get();
                    if (d < n.min || d > n.max) { bad = true; why = n.name + " varsayilan aralik disi"; }
                    n.set(1e12);
                    if (n.get() != n.max) { bad = true; why = n.name + " ust sinir"; }
                    n.set(-1e12);
                    if (n.get() != n.min) { bad = true; why = n.name + " alt sinir"; }
                    n.reset();
                } else if (s instanceof Setting.Mode m) {
                    if (m.options.length == 0 || !java.util.Arrays.asList(m.options).contains(m.get())) { bad = true; why = m.name + " secenekler"; }
                    for (int i = 0; i < m.options.length; i++) {
                        m.select(i);
                        String saved = m.save();
                        m.select(0);
                        m.load(saved);
                        if (!m.get().equals(m.options[i])) { bad = true; why = m.name + " " + m.options[i] + " kaydet/yukle"; }
                    }
                    m.reset();
                } else if (s instanceof Setting.Text t) {
                    if (t.maxLen <= 0) { bad = true; why = t.name + " maxLen"; }
                }
                if (s.persistent()) {
                    String before = s.save();
                    s.load(before);
                    if (!before.equals(s.save())) { bad = true; why = s.name + " kaydet/yukle kararli degil"; }
                }
            }
            check(f.name + ": ayarlar gecerli (" + sn.size() + " ayar)" + (bad ? "  -> " + why : ""), !bad);
            check(f.name + ": ayar adlari benzersiz", sn.stream().distinct().count() == sn.size());
        }

        // kullanilmayan GUI ayari taramasi (kaynak kodu)
        Pattern decl = Pattern.compile("private final Setting\\.(Bool|Num|Mode|Color|Text) (\\w+) = add\\(");
        List<String> unused = new ArrayList<>();
        for (String mod : new String[]{"AimAssist", "AimTraining", "AutoCrystal", "TargetControl", "TargetHud", "TriggerBot"}) {
            String src = Files.readString(Path.of("src/main/java/dev/lumen/module/" + mod + ".java"), StandardCharsets.UTF_8);
            Matcher m = decl.matcher(src);
            while (m.find()) {
                String var = m.group(2);
                Matcher use = Pattern.compile("\\b" + var + "\\b").matcher(src);
                int c = 0;
                while (use.find()) c++;
                if (c < 2) unused.add(mod + "." + var);
            }
        }
        check("kullanilmayan (islevsiz) GUI ayari yok" + (unused.isEmpty() ? "" : "  -> " + unused), unused.isEmpty());
    }

    // ------------------------------------------------------------------ moduller arasi etkilesim
    static void interactions() {
        System.out.println("== Moduller arasi etkilesim");
        newWorld();
        AimAssist aa = on(new AimAssist());
        TriggerBot tb = on(new TriggerBot());
        Lumen.TRIGGER = tb;
        TargetControl tc = on(new TargetControl());
        TargetHud hud = on(new TargetHud());
        num(tb, "Delay", 0); num(tb, "Cooldown", 0);
        Zombie a = spawn(new Zombie(), -2, 0, 4);
        Zombie b = spawn(new Zombie(), 2, 0, 4);

        TargetManager.lock(b);
        look(a); // nisan A'da ama kilit B'de
        mm.tick();
        check("Trigger Bot (Target Only) kilitli olmayan A'ya vurmaz", attacks() == 0);
        check("Aim Assist kilitli B'ye doner (yaw < 0)", player.yaw < 0f);
        look(b);
        mm.tick();
        check("nisan kilitli B'ye gelince Trigger Bot B'ye vurur", attacks() == 1 && mc.interactionManager.attacked.get(0) == b);

        FriendsManager.deserialize("");
        b.customName = "Bob";
        FriendsManager.add("bob");
        look(b);
        int atk = attacks();
        mm.tick();
        check("kilitliyken arkadas eklenince Aim Assist, Trigger Bot ve Target HUD ayni tick'te hedefi birakir",
                attacks() == atk && TargetManager.get(mc) != b);
        FriendsManager.deserialize("");

        // dunya degisimi: tum modullerde eski referans temizligi
        TargetManager.lock(a);
        mm.tick();
        ClientWorld old = world;
        newWorld2();
        Lumen.MODULES.worldChanged();
        mm.worldChanged();
        check("dunya degisiminde kilit temizlenir", !TargetManager.hasLock());
        boolean ok = true;
        try { mm.tick(); mm.renderHud(new DrawContext(), 200, 100); } catch (RuntimeException e) { ok = false; }
        check("yeni dunyada tick/HUD istisnasiz", ok && old != world);
        check("hicbir modul hata nedeniyle kapanmadi", aa.isEnabled() && tb.isEnabled() && tc.isEnabled() && hud.isEnabled());
    }

    // ------------------------------------------------------------------ BlockScanner (Block ESP / X-Ray ortak tarayici)
    static void scanner() {
        System.out.println("== BlockScanner (Block ESP / X-Ray)");
        newWorld();
        BlockGroups.Group[] g = {
                new BlockGroups.Group("Obs", 0xFF00FF, new Block[]{Blocks.OBSIDIAN}),
                new BlockGroups.Group("Bed", 0x00FF00, new Block[]{Blocks.BEDROCK})};
        BlockScanner sc = new BlockScanner(g);
        world.blocks.put(new BlockPos(3, 0, 2), Blocks.OBSIDIAN);
        world.blocks.put(new BlockPos(-4, 1, 0), Blocks.BEDROCK);
        boolean[] en = {true, true};

        sc.tick(mc, 8, en, 1000); // yaricap 8 -> 17^3 = 4913 blok
        check("tick basina butce asilmaz (<= 1000 blok sorgusu)", world.lookups <= 1000);
        for (int i = 0; i < 3; i++) sc.tick(mc, 8, en, 1000);
        check("tarama bitmeden sonuc yayinlanmaz (parca parca)", sc.hits().isEmpty());
        sc.tick(mc, 8, en, 1000);
        check("tarama bitince iki blok da bulunur", sc.hits().size() == 2);
        check("bloklar dogru gruba atanir", sc.hits().stream().anyMatch(h -> h.x() == 3 && h.z() == 2 && h.group() == 0)
                && sc.hits().stream().anyMatch(h -> h.x() == -4 && h.group() == 1));

        en[1] = false;
        for (int i = 0; i < 5; i++) sc.tick(mc, 8, en, 1000);
        check("kapali grup sonuca girmez", sc.hits().size() == 1 && sc.hits().get(0).group() == 0);

        // dunya degisti: eski sonuclar atilir, yeni dunyada yeniden taranir
        ClientWorld old = world;
        world = new ClientWorld();
        player = new ClientPlayerEntity();
        world.entities.add(player);
        mc.world = world;
        mc.player = player;
        sc.tick(mc, 8, en, 1000);
        check("dunya degisince eski dunyanin sonuclari atilir", sc.hits().isEmpty() && old != world);

        sc.reset();
        check("reset sonuclari temizler", sc.hits().isEmpty());
        mc.world = null;
        boolean ok = true;
        try { sc.tick(mc, 8, en, 1000); } catch (RuntimeException e) { ok = false; }
        check("dunya yokken tarama istisna vermez", ok);

        // Block ESP modulu: dunya degisim kancasi tarayiciyi sifirlar (istisnasiz)
    }

    // ------------------------------------------------------------------ kayit: tekrar yok, kategoriler, sira
    static void registration() throws Exception {
        System.out.println("== Modul kaydi / kategoriler");
        Path modDir = Path.of("src/main/java/dev/lumen/module");
        String lumen = Files.readString(Path.of("src/main/java/dev/lumen/Lumen.java"), StandardCharsets.UTF_8);
        List<String> classes = new ArrayList<>();
        List<String> names = new ArrayList<>();
        java.util.Set<String> cats = new java.util.TreeSet<>();
        Pattern sup = Pattern.compile("super\\(\"([^\"]+)\",\\s*\"[^\"]*\",\\s*Category\\.(\\w+)");
        try (var s = Files.list(modDir)) {
            for (Path p : (Iterable<Path>) s.sorted()::iterator) {
                String cls = p.getFileName().toString().replace(".java", "");
                classes.add(cls);
                Matcher m = sup.matcher(Files.readString(p, StandardCharsets.UTF_8));
                if (m.find()) { names.add(m.group(1)); cats.add(m.group(2)); }
            }
        }
        eq("20 modul sinifi var", 20, classes.size());
        eq("her modulun adi ve kategorisi okunabildi", classes.size(), names.size());
        check("modul adlari benzersiz", names.stream().distinct().count() == names.size());
        eq("altı kategorinin hepsi dolu (Click GUI paneli)", "COMBAT,HUD,MISC,MOVEMENT,RENDER,WORLD", String.join(",", cats));
        List<String> dup = new ArrayList<>(), missing = new ArrayList<>();
        for (String c : classes) {
            Matcher m = Pattern.compile("new " + c + "\\(").matcher(lumen);
            int n = 0;
            while (m.find()) n++;
            if (n > 1) dup.add(c);
            if (n == 0) missing.add(c);
        }
        check("hicbir modul iki kez olusturulmuyor" + (dup.isEmpty() ? "" : "  -> " + dup), dup.isEmpty());
        check("her modul Lumen'de kayitli" + (missing.isEmpty() ? "" : "  -> " + missing), missing.isEmpty());
        check("Friends, ayarlar yuklenmeden once kaydedilip varsayilan acik yapiliyor",
                lumen.indexOf("new Friends()") < lumen.indexOf("MODULES.set(FRIENDS, true)")
                        && lumen.indexOf("MODULES.set(FRIENDS, true)") < lumen.indexOf("Config.load(MODULES)"));
        check("dunya/oyuncu degisimi kancasi Lumen'de bagli", lumen.contains("MODULES.worldChanged()"));
        for (String scan : new String[]{"BlockEsp", "XRay"}) {
            String src = Files.readString(modDir.resolve(scan + ".java"), StandardCharsets.UTF_8);
            check(scan + ": dunya degisiminde tarayici sifirlanir (eski dunya RAM'de kalmaz)",
                    Pattern.compile("public void onWorldChange\\(\\)\\s*\\{\\s*scanner\\.reset\\(\\);").matcher(src).find());
        }
    }
}
