#!/bin/sh
# Minecraft gerektirmeyen test duzeni: gercek Lumen kaynaklari, selftest/stubs altindaki kucuk Minecraft taklitleriyle
# derlenir ve calistirilir. Gereksinim: JDK 21 (javac). Proje kokunden: sh selftest/run.sh
# NOT: taklitler Minecraft API'sini TAHMIN eder; bu duzen mantigi dogrular, gercek derlemenin yerini TUTMAZ.
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
SRC=src/main/java/dev/lumen
STUBS=$(find selftest/stubs -name '*.java')
javac -d "$OUT" -encoding UTF-8 $STUBS \
  $SRC/core/Category.java $SRC/core/Config.java $SRC/core/ConfigFormat.java $SRC/core/Feature.java \
  $SRC/core/HudFeature.java $SRC/core/ModuleManager.java $SRC/core/Setting.java \
  $SRC/util/FriendsManager.java $SRC/util/FriendCommands.java $SRC/util/TargetManager.java \
  $SRC/util/BlockScanner.java $SRC/util/ChanceModel.java $SRC/util/Clicks.java $SRC/util/Draw.java $SRC/util/Projector.java \
  $SRC/module/Friends.java $SRC/module/TargetControl.java $SRC/module/TriggerBot.java \
  $SRC/module/AimAssist.java $SRC/module/AimTraining.java $SRC/module/AutoCrystal.java $SRC/module/TargetHud.java \
  selftest/SelfTest.java selftest/GameTest.java
java -cp "$OUT" SelfTest
