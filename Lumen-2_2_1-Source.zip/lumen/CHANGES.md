# Lumen 2.2 -> 2.2.1 (tek birlesik kaynak agaci)

Tek agac: 2.2 mimarisi korundu; ayni sinifin iki kopyasi yok (41 .java dosyasi, testte dogrulanir).
`lumen-project-friends.zip` (onceki teslim) bu agacla degistirildi.

## Bulunan hatalar -> duzeltme
| # | Hata | Duzeltme |
|---|------|----------|
| 1 | `Feature.applyEnabled`: `onEnable` hata verirse modul "acik" kaliyordu | Geri alma + temizlik (`onDisable`) + hata ustte loglanir |
| 2 | Hatalar `toString()` ile loglaniyordu (yigin izi yok); `NoSuchMethodError` gibi API uyumsuzlugu istemciyi cokertebilirdi | Tam yigin izi; `LinkageError` yakalanir, yalniz o modul kapanir |
| 3 | Dunya/oyuncu degisince modullerdeki eski varlik referanslari kaliyordu (eski dunyadaki mobe nisan alma) | `Feature.onWorldChange` + `ModuleManager.worldChanged` + `Lumen` kimlik izleme |
| 4 | Aim Assist: Target Lock kapaliyken kilitli hedefi yok sayip baska hedef seciyordu (Trigger Bot ile celisme) | Kilitli hedef varsa tum moduller ayni hedefi kullanir |
| 5 | Trigger Bot: Target Only acikken Target Filter hic kullanilmiyordu | Ikisi birlikte gecerli; HUD nedeni yazar |
| 6 | Trigger Bot: kapatinca/ekran acilinca eski hedef ve zamanlayici kaliyordu (gecikme atlaniyordu) | Temizlik eklendi |
| 7 | Zirh askisi ve evcil hayvanlar gecerli hedefti ("All Mobs" ile vurulabiliyordu) | `TargetManager.isValid` disliyor |
| 8 | `TargetManager.clear()` kullanici "hedefi birak" deyince suren Auto Reselect aramasini durdurmuyordu | Her temizlikte surum artar |
| 9 | Target Manager: modul kapaliyken kalan eski "hedef kayboldu" yeniden acilista aramayi tetikliyordu | `onEnable` temizler |
| 10 | Auto Crystal: ekran acikken "Only in singleplayer" yaziyordu (yanlis neden) | Ayri durum: "Paused (screen open)" |
| 11 | Auto Crystal: yerlestirme kutusundaki varlik kontrol edilmiyordu; hasar tahmini "kesin" gorunuyordu | Varlik kontrolu; "approx" etiketi |
| 12 | Aim Training Auto Hit kendi (daha zayif) dunya kontrolunu kullaniyor, Trigger Bot ile cift vurabiliyordu | Ortak `isSafeWorld`; Trigger Bot aciksa saldirmaz; arkadas korumasi |
| 13 | Ayar dosyasi dogrudan yaziliyordu (yazarken kapanirsa yarim dosya) | Gecici dosya + atomik tasima |
| 14 | `Setting.Button` hatalari sessizce yutuyordu | Loglanir |
| 15 | Bozuk tek ayar tum modulun yuklemesini durdurabilirdi | Ayar bazinda yakalanir ve loglanir |
| 16 | BlockEsp/X-Ray tarayicilari menude eski `ClientWorld`'u bellekte tutuyordu | `onWorldChange` -> `scanner.reset()` |
| 17 | Kucuk ekranda ayar ekraninda negatif gorunum yuksekligi | `Math.max` korumasi |

## Eklenenler
Friends: `.f add/remove/list`, kalici liste (`config/lumen/friends.properties`), Combat > Friends GUI bolumu (Friends Protection, Friend Count,
Friends List, Friend Name, Add Friend, Remove Friend), tek merkezli koruma (`TargetManager.isValid`). `Setting.Info` (salt okunur satir).
HUD durum satirlari (Aim Assist, Trigger Bot) ve acilista ipucu mesaji. Selftest (316 kontrol), mutasyon kaydi, GitHub Actions derleme dosyasi.

## Bilerek DEGISTIRILMEYENLER
Tek oyunculu + baska oyuncu yok sarti, oyuncularin hedeflenememesi, Auto Crystal varsayilanlari (Simulation Only, Require Creative),
ChanceModel/Randomized Training (egitim istatistigi; genisletilmedi). Anti-cheat atlatma/tespit gizleme/log gizleme eklenmedi.

## Dogrulanamayanlar (bu ortamda Minecraft/Fabric/ag yok)
- Gercek derleme (Loom + yarn 1.21.11) YAPILMADI; JAR uretilmedi.
- Yeni cagrilan API adlari yarn 1.21.11'de dogrulanamadi: `ClientSendMessageEvents.ALLOW_CHAT`, `Entity.hasCustomName/getCustomName`,
  `TameableEntity.isTamed`, `net.minecraft.entity.decoration.ArmorStandEntity`, `ClientWorld.getOtherEntities(null, Box, Predicate)`.
  Derleme hatasi cikarsa once bunlara bakilir.
- GUI cizimi, tus baglari, gercek tick/HUD akisi ve `Fabric` modu tanima oyunda denenmedi.

## Derleme duzeltmesi (GitHub Actions ilk calisma)
- `RenderUtil`: yarn 1.21.11'de `Camera.getPos()` yok, `Camera.getCameraPos()` var -> duzeltildi (tek derleme hatasiydi).
- Workflow: Gradle 9.2.1; Fabric Loader 0.18.4.
