# Lumen 2.2.1 (Fabric, Minecraft 1.21.11)

Gereksinimler: JDK 21, Fabric Loader >= 0.18.1, Fabric API (1.21.11).
Derleme: Gradle 9.x + JDK 21 ile `gradle clean build` -> `build/libs/Lumen-2.2.1-1.21.11.jar`. Bilgisayarsiz: projeyi GitHub'a yukle, `.github/workflows/build.yml` JAR'i bulutta uretir (Actions > Artifacts). Gradle wrapper projede YOK.
Kurulum: eski lumen jar'ini sil, yenisini `mods` klasorune at.

ClickGUI: Right Shift. Modul: sol tik ac/kapat, sag tik o modulun ayar ekrani.
Ayarlar: config/lumen/<modul>.properties (modul basina ayri dosya).
Hedef sec/kaldir: G (Controls > Lumen).

Aim Assist, otomatik Trigger Bot saldirisi, Auto Crystal, X-Ray ve Block ESP yalnizca yerel tek oyunculu dunyada
(baska oyuncu yokken) calisir. HUD modulleri, Target HUD gosterimi ve Trigger Bot istatistikleri her dunyada calisir.

## Friends (arkadas korumasi)
Combat > Friends modulu: ACIK iken arkadaslar hicbir Combat modulunun hedefi olmaz (Aim Assist, Trigger Bot,
Auto Crystal, Target Manager, Aim Training "Auto Hit"). Tum Combat hedef secimi `TargetManager.isValid` uzerinden
gectigi icin koruma tek merkezdedir (`FriendsManager`). Ekleme/silme bir sonraki tick'te hemen gecerli olur.

Sohbet komutlari (sunucuya/sohbete gonderilmez, sonuc yalnizca sana yazilir):
- `.f add <isim>`    arkadas ekler (buyuk/kucuk harf duyarsiz, ayni isim iki kez eklenmez)
- `.f remove <isim>` arkadasi siler
- `.f list`          listeyi ve koruma durumunu yazar

GUI: Friends modulunun ayar ekrani (sag tik): Friends Protection, Friend Count, Friends List, Friend Name,
Add Friend, Remove Friend. Liste `config/lumen/friends.properties` dosyasinda saklanir ve yeniden acilista korunur.
Not: Combat zaten oyuncu olmayan varliklari hedefler; bu yuzden liste, oyuncu adlarina ve isim etiketi
(name tag) takilmis varliklara uygulanir. Adsiz moblar ("Zombie" gibi) hicbir zaman arkadas sayilmaz.

## Test
`sh selftest/run.sh` (JDK 21): Minecraft gerektirmeyen parcalari (FriendsManager, Setting, ConfigFormat, ChanceModel)
gercekten calistirip dogrular. GUI, event ve hedefleme oyun icinde denenmelidir.
Gradle wrapper projede yok: `gradle wrapper` ile uret ya da yerel Gradle ile `gradle clean build` calistir.

## Combat davranisi (kodla birebir)
Ortak kural (`TargetManager`): Combat yalnizca tek oyunculu dunyada, dunyada baska oyuncu yokken calisir.
Gecerli hedef = canli, silinmemis, kendin olmayan, **oyuncu olmayan**, zirh askisi olmayan, evcil (tame) hayvan olmayan,
arkadas olmayan canli varlik. Dunya/oyuncu degisince (giris-cikis, boyut, olum) tum hedef referanslari temizlenir.
- **Aim Assist:** kilitli hedef (G) varsa Target Lock acik/kapali fark etmeden hepsi onu kullanir. Kilit yoksa: Target Lock acikken bekler,
  kapaliyken filtrelere (Mobs/Hostile Only/Invisible/Priority/FOV/Range) gore otomatik secer. HUD durum satiri nedeni yazar.
- **Trigger Bot:** nisandaki hedefe vurur. Target Only acikken hedef kilitli olmali; Target Filter her iki modda da gecerlidir.
  Delay/Cooldown ms olarak uygulanir (tick = 50 ms cozunurluk); Weapon Cooldown acikken silah dolmadan vurmaz.
  Kapaninca/ekran acilinca/dunya degisince hedef ve zamanlayicilar temizlenir. Hit/Miss/Attempts yalnizca gercek vurus/bos savurma/kendi tiklarinda artar.
- **Auto Crystal:** varsayilan Simulation Only + Require Creative (degistirilmedi). Hasar yaklasiktir (zirh/blok/zorluk yok sayilir).
  Yerlestirme noktasinda varlik varsa o nokta secilmez.
- **Aim Training:** Auto Hit ayni guvenli dunya kontrolunu kullanir; Trigger Bot aciksa Auto Hit saldirmaz (cift vurus yok).
- **Friends:** korur: ozel adi (name tag) olan varliklar ve oyuncu adlari. Combat zaten oyunculari hedeflemez; adsiz moblar ("Zombie") korunmaz.

## Hata yalitimi
Bir modul acilirken hata verirse geri alinir (acik gorunup yarim kalmaz). Tick/HUD hatasi (LinkageError dahil) yalnizca o modulu kapatir ve
tam yigin iziyle bir kez loglanir. Ayar dosyalari gecici dosya + tasima ile yazilir; bozuk tek ayar yuklemeyi durdurmaz.

## Test
`sh selftest/run.sh` (JDK 21): gercek Lumen kaynaklari, `selftest/stubs` altindaki Minecraft taklitleriyle derlenip calisir (316 kontrol).
Taklitler Minecraft API'sini tahmin eder: mantigi dogrular, gercek derlemenin/oyun ici testin yerini TUTMAZ. Kayitlar: `selftest/TEST-LOG.txt`,
`selftest/MUTATION-LOG.txt`. Oyun ici test plani: `INGAME-TEST-PLAN.md`.

