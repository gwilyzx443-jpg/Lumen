# Oyun ici test plani (Minecraft 1.21.11 Fabric, tek oyunculu)
Her madde: yap -> beklenen. Gecmeyen madde "calismiyor" sayilir.

1. **Yukleme:** Mods listesinde Lumen 2.2.1 gorunur; Right Shift (varsayilan tus) Click GUI'yi acar; 6 panel: Combat(7), HUD(4), Misc(3), Movement(2), Render(2), World(2).
2. **Friends GUI:** Combat > Friends sag tik: Friend Name'e `bob` yaz, Add Friend -> Friend Count 1, List "bob". Sohbete `.f list` -> "Arkadaslar (1)". Oyunu kapat-ac -> liste duruyor.
3. **Komutlar:** `.f add Zed`, `.f add zed` (Zaten...), `.f remove ZED`, `.f` (kullanim). Mesajlar sunucuya/sohbete gitmez.
4. **Friend korumasi:** Isim etiketiyle "Bob" adli bir zombi olustur (name tag). Aim Assist/Trigger Bot/Target Manager ile hedef al -> secilmez. `.f remove bob` -> ayni tick'ten sonra hedeflenir.
5. **Aim Assist:** Aciliste ipucu mesaji. Target Lock acik + kilit yok -> HUD "lock a target (G)". G ile mobu kilitle -> nisan yumusakca doner. Target Lock kapali -> kilitsiz otomatik secer; kilit varsa kilidi kullanir. FOV/Range/Aim Speed/Smoothness degisikligi etkisini gosterir.
6. **Trigger Bot:** Target Only acik + kilit yok -> vurmaz, HUD nedeni yazar. Kilitli zombi + Hostile Mobs -> vurur. Kilitli inek + Hostile -> vurmaz ("filtered out"). Passive/All Mobs. Delay/Cooldown. Zirh askisi ve kendi kurdun vurulmaz. Kapat-ac -> gecikme bastan baslar.
7. **Auto Crystal:** Varsayilan simulasyon: hicbir sey yerlesmez/kirilmaz; plan ve "approx" hasar gorunur. Creative + Simulation Only kapali + kristal elde -> yerlestirir.
8. **Aim Training:** Auto Hit zombiyi vurur; Trigger Bot aciksa Auto Hit vurmaz.
9. **Dunya degisimi:** Hedef kilitliyken Nether'e gec / olup yeniden dogus / dunyadan cik-gir -> kilit ve HUD hedefi temizlenir, hata logu yok.
10. **LAN:** Dunyayi LAN'a ac, baska oyuncu katilinca Combat otomatik saldirisi durur ("singleplayer only").
11. **Log:** `logs/latest.log` icinde "Modul ... hata verdi" yoksa temiz; varsa tam yigin izini gonder.
12. **Performans:** Block ESP + X-Ray acik, F3'te FPS dususu gozle; menuye cikinca bellek serbest kalir.
