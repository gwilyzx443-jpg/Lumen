# Lumen (Fabric, Minecraft 1.21.11)

Gereksinimler: JDK 21, internet (ilk derlemede Gradle/Loom bagimliliklari iner).

## Derleme
1. https://fabricmc.net/develop/template adresinden 1.21.11 icin bir sablon indir
   ve icindeki `gradlew`, `gradlew.bat` ve `gradle/` klasorunu bu proje klasorune kopyala
   (gradle-wrapper.jar ikili dosya oldugu icin projeye dahil degil).
2. Bu klasorde:  `./gradlew build`   (Windows: `gradlew.bat build`)
3. Cikti: `build/libs/lumen-1.0.0+1.21.11.jar`  (`-sources` olmayan dosya)

## Kurulum
- Fabric Loader (>= 0.18.1) ve Fabric API (1.21.11) kurulu olmali.
- Jar'i `.minecraft/mods` klasorune at.
- ClickGUI: Right Shift (Ayarlar > Kontroller > Lumen'den degistirilebilir).
- Modul satirina sol tik: ac/kapat. Sag tik: ayarlari ac/kapat. Slider: surukle veya fare tekerlegi.
