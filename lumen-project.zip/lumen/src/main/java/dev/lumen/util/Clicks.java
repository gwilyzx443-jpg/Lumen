package dev.lumen.util;

import net.minecraft.client.MinecraftClient;

/** Son 1 saniyedeki tiklari sayar. Sabit boyutlu halka tampon, ek bellek tahsisi yok. */
public final class Clicks {
    private static final long[] LEFT = new long[64];
    private static final long[] RIGHT = new long[64];
    private static int li, ri;
    private static boolean prevRight;

    private Clicks() {}

    public static void addLeft() {
        LEFT[li] = System.currentTimeMillis();
        li = (li + 1) & 63;
    }

    /** Sag tik icin her tick'te tus durumunun degisimine bakilir. */
    public static void pollRight(MinecraftClient mc) {
        boolean down = mc.options.useKey.isPressed();
        if (down && !prevRight) {
            RIGHT[ri] = System.currentTimeMillis();
            ri = (ri + 1) & 63;
        }
        prevRight = down;
    }

    public static int left(long now) {
        return count(LEFT, now);
    }

    public static int right(long now) {
        return count(RIGHT, now);
    }

    private static int count(long[] ring, long now) {
        int c = 0;
        for (long t : ring) {
            if (t != 0 && now - t <= 1000) c++;
        }
        return c;
    }
}
