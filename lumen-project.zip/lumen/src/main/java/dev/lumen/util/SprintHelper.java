package dev.lumen.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class SprintHelper {
    private SprintHelper() {}

    /** Normal oyun kurallarina uyar: aclik, yavaslama, carpisma, nesne kullanimi. */
    public static void apply(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || p.isSprinting()) return;
        if (!mc.options.forwardKey.isPressed()) return;
        if (p.isSneaking() || p.isUsingItem() || p.horizontalCollision) return;
        if (p.getHungerManager().getFoodLevel() <= 6 && !p.getAbilities().allowFlying) return;
        p.setSprinting(true);
    }
}
