package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.util.SprintHelper;
import net.minecraft.text.Text;

public final class ToggleSprint extends Feature {
    private boolean latched;

    public ToggleSprint() {
        super("Toggle Sprint", "Tusla kosmayi ac/kapat (Controls'ten tus ata).", Category.MOVEMENT);
    }

    @Override
    public String[] conflicts() {
        return new String[]{"Auto Sprint"};
    }

    public void flip() {
        latched = !latched;
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("Toggle Sprint: " + (latched ? "ON" : "OFF")), true);
        }
    }

    @Override
    protected void onDisable() {
        latched = false;
    }

    @Override
    public void onTick() {
        if (latched) SprintHelper.apply(mc);
    }
}
