package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Clicks;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;

public final class CpsDisplay extends HudFeature {
    private final Setting.Bool right = add(new Setting.Bool("Right Click", true));
    private String text = "CPS: 0";

    public CpsDisplay() {
        super("CPS Display", "Saniyedeki tiklama sayisi.", Category.MISC, 4, 16);
    }

    @Override
    public void onTick() {
        long now = System.currentTimeMillis();
        int l = Clicks.left(now);
        text = right.get() ? "CPS: " + l + " | " + Clicks.right(now) : "CPS: " + l;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        Draw.label(ctx, mc.textRenderer, text, px(), py());
    }
}
