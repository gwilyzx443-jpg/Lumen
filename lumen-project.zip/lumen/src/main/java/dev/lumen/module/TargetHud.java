package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Antrenman icin: yalnizca tek oyunculu dunyada, nisan alinan canli varligin canini gosterir. */
public final class TargetHud extends Feature {
    private static final int BAR_W = 104;

    private final Setting.Num offX = add(new Setting.Num("Offset X", 16, -200, 200, 1));
    private final Setting.Num offY = add(new Setting.Num("Offset Y", 16, -200, 200, 1));

    private LivingEntity target;
    private LivingEntity drawn;
    private long lastSeen;
    private String name = "";
    private float hp, max = 20f, shown, alpha;

    public TargetHud() {
        super("Target HUD", "Nisan aldigin varligin canini gosterir (tek oyunculu).", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!mc.isInSingleplayer()) {
            target = null;
            return;
        }
        HitResult hr = mc.crosshairTarget;
        long now = System.currentTimeMillis();
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && le.isAlive()) {
            target = le;
            lastSeen = now;
        } else if (target != null && (now - lastSeen > 1500 || !target.isAlive() || target.isRemoved())) {
            target = null;
        }
    }

    @Override
    protected void onDisable() {
        target = null;
        drawn = null;
        alpha = 0f;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (target != null) {
            if (target != drawn) {
                drawn = target;
                shown = target.getHealth();
                alpha = 0f;
            }
            name = target.getName().getString();
            hp = target.getHealth();
            max = Math.max(1f, target.getMaxHealth());
            alpha += (1f - alpha) * 0.25f;
        } else {
            alpha += (0f - alpha) * 0.25f;
            if (alpha < 0.03f) return;
        }
        shown += (hp - shown) * 0.2f;

        int x = w / 2 + offX.i();
        int y = h / 2 + offY.i();
        var tr = mc.textRenderer;
        ctx.fill(x, y, x + 112, y + 32, Draw.alpha(Draw.BG, alpha));
        ctx.fill(x, y, x + 2, y + 32, Draw.alpha(Draw.ACCENT, alpha));
        ctx.drawText(tr, name, x + 6, y + 4, Draw.alpha(0xFFFFFFFF, alpha), true);

        float frac = Math.max(0f, Math.min(1f, shown / max));
        int bx = x + 6, by = y + 18;
        ctx.fill(bx, by, bx + BAR_W, by + 8, Draw.alpha(0xFF2A2A2A, alpha));
        int color = Draw.lerpColor(0xFFE5484D, 0xFF46C25B, frac);
        ctx.fill(bx, by, bx + (int) (BAR_W * frac), by + 8, Draw.alpha(color, alpha));
    }
}
