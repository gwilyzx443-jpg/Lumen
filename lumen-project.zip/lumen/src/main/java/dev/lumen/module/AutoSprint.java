package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.util.SprintHelper;

public final class AutoSprint extends Feature {
    public AutoSprint() {
        super("Auto Sprint", "Ileri giderken otomatik kosar.", Category.MOVEMENT);
    }

    @Override
    public String[] conflicts() {
        return new String[]{"Toggle Sprint"};
    }

    @Override
    public void onTick() {
        SprintHelper.apply(mc);
    }
}
