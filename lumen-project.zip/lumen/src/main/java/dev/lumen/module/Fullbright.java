package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Yalnizca istemci tarafinda gorsel gece gorusu efekti uygular; sunucuya paket gonderilmez. */
public final class Fullbright extends Feature {
    private boolean ours;

    public Fullbright() {
        super("Fullbright", "Karanlik alanlari aydinlatir.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.getStatusEffect(StatusEffects.NIGHT_VISION) == null) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, StatusEffectInstance.INFINITE, 0, false, false, false));
            ours = true;
        }
    }

    @Override
    protected void onDisable() {
        if (!ours || mc.player == null) {
            ours = false;
            return;
        }
        StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur != null && cur.isInfinite()) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        ours = false;
    }
}
