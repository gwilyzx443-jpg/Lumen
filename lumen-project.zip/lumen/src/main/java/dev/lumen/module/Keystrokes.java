package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Clicks;
import dev.lumen.util.Draw;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;

public final class Keystrokes extends HudFeature {
    private final Setting.Bool mouse = add(new Setting.Bool("Mouse Buttons", true));
    private final Setting.Bool space = add(new Setting.Bool("Space Bar", true));
    private final float[] anim = new float[7];
    private final String[] labels = {"W", "A", "S", "D"};
    private int frame;

    public Keystrokes() {
        super("Keystrokes", "WASD, fare ve bosluk tuslarini gosterir.", Category.RENDER, 4, 60);
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        TextRenderer tr = mc.textRenderer;
        GameOptions o = mc.options;
        if (frame++ % 60 == 0) { // tus atamasi degisirse etiketler guncellenir
            labels[0] = o.forwardKey.getBoundKeyLocalizedText().getString();
            labels[1] = o.leftKey.getBoundKeyLocalizedText().getString();
            labels[2] = o.backKey.getBoundKeyLocalizedText().getString();
            labels[3] = o.rightKey.getBoundKeyLocalizedText().getString();
        }
        int x = px(), y = py();
        box(ctx, tr, 0, o.forwardKey.isPressed(), labels[0], null, x + 24, y, 22, 22);
        box(ctx, tr, 1, o.leftKey.isPressed(), labels[1], null, x, y + 24, 22, 22);
        box(ctx, tr, 2, o.backKey.isPressed(), labels[2], null, x + 24, y + 24, 22, 22);
        box(ctx, tr, 3, o.rightKey.isPressed(), labels[3], null, x + 48, y + 24, 22, 22);
        int yy = y + 48;
        if (mouse.get()) {
            long now = System.currentTimeMillis();
            box(ctx, tr, 4, o.attackKey.isPressed(), "LMB", String.valueOf(Clicks.left(now)), x, yy, 35, 22);
            box(ctx, tr, 5, o.useKey.isPressed(), "RMB", String.valueOf(Clicks.right(now)), x + 37, yy, 35, 22);
            yy += 24;
        }
        if (space.get()) {
            box(ctx, tr, 6, o.jumpKey.isPressed(), "SPACE", null, x, yy, 72, 14);
        }
    }

    private void box(DrawContext ctx, TextRenderer tr, int i, boolean down, String label, String sub,
                     int x, int y, int w, int h) {
        anim[i] += ((down ? 1f : 0f) - anim[i]) * 0.3f;
        int bg = Draw.lerpColor(0x90000000, 0xD0FFFFFF, anim[i]);
        int fg = Draw.lerpColor(0xFFFFFFFF, 0xFF111111, anim[i]);
        ctx.fill(x, y, x + w, y + h, bg);
        if (sub == null) {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, fg, false);
        } else {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, fg, false);
            ctx.drawText(tr, sub, x + (w - tr.getWidth(sub)) / 2, y + 12, fg, false);
        }
    }
}
