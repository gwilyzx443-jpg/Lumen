package dev.lumen.module;

import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;

public final class Zoom extends Feature {
    private final Setting.Num fov = add(new Setting.Num("FOV", 30, 30, 90, 1));
    private final Setting.Num sens = add(new Setting.Num("Sensitivity", 0.4, 0.1, 1.0, 0.05));
    private boolean zooming;
    private int origFov;
    private double origSens;

    public Zoom() {
        super("Zoom", "Zoom tusunu basili tutunca yakinlastirir.", Category.RENDER);
    }

    @Override
    public void onTick() {
        boolean want = Lumen.zoomKey.isPressed() && mc.currentScreen == null;
        if (want && !zooming) start();
        else if (!want && zooming) restore();
    }

    @Override
    protected void onDisable() {
        restore();
    }

    private void start() {
        origFov = mc.options.getFov().getValue();
        origSens = mc.options.getMouseSensitivity().getValue();
        mc.options.getFov().setValue(fov.i());
        mc.options.getMouseSensitivity().setValue(origSens * sens.get());
        zooming = true;
    }

    /** Birden fazla yerden guvenle cagrilabilir. */
    public void restore() {
        if (!zooming) return;
        zooming = false;
        mc.options.getFov().setValue(origFov);
        mc.options.getMouseSensitivity().setValue(origSens);
    }
}
