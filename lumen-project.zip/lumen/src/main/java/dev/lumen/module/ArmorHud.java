package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public final class ArmorHud extends HudFeature {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private final Setting.Bool durability = add(new Setting.Bool("Durability Text", true));

    public ArmorHud() {
        super("Armor HUD", "Takili zirhlari ve dayanikliligi gosterir.", Category.RENDER, 4, 152);
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (mc.player == null) return;
        int x = px(), y = py();
        for (EquipmentSlot slot : SLOTS) {
            ItemStack s = mc.player.getEquippedStack(slot);
            if (s.isEmpty()) continue;
            ctx.drawItem(s, x, y);
            ctx.drawStackOverlay(mc.textRenderer, s, x, y);
            if (durability.get() && s.isDamageable()) {
                int left = s.getMaxDamage() - s.getDamage();
                float frac = left / (float) s.getMaxDamage();
                int color = Draw.lerpColor(0xFFE5484D, 0xFF46C25B, frac);
                ctx.drawText(mc.textRenderer, String.valueOf(left), x + 20, y + 4, color, true);
            }
            y += 18;
        }
    }
}
