package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;

public final class FpsDisplay extends HudFeature {
    private String text = "FPS: 0";

    public FpsDisplay() {
        super("FPS Display", "FPS gostergesi.", Category.MISC, 4, 4);
    }

    @Override
    public void onTick() {
        text = "FPS: " + mc.getCurrentFps();
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        Draw.label(ctx, mc.textRenderer, text, px(), py());
    }
}
