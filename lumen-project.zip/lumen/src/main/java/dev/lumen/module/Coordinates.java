package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;

public final class Coordinates extends HudFeature {
    private final Setting.Bool facing = add(new Setting.Bool("Show Direction", true));
    private String text = "XYZ: -";

    public Coordinates() {
        super("Coordinates", "Konum gostergesi.", Category.MISC, 4, 28);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        String s = String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        text = facing.get() ? s + " (" + mc.player.getHorizontalFacing().asString() + ")" : s;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        Draw.label(ctx, mc.textRenderer, text, px(), py());
    }
}
