package dev.lumen.core;

import dev.lumen.Lumen;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tek bir kucuk dosya: config/lumen.properties. Yalnizca ayar degisince yazilir. */
public final class Config {
    private static boolean dirty;

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("lumen.properties");
    }

    public static void markDirty() {
        dirty = true;
    }

    public static void load(ModuleManager mm) {
        Path p = file();
        if (!Files.isRegularFile(p)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(p)) {
            props.load(in);
        } catch (IOException e) {
            Lumen.LOGGER.warn("Ayar dosyasi okunamadi: {}", e.toString());
            return;
        }
        for (Feature f : mm.all()) {
            for (Setting<?> s : f.settings) {
                String v = props.getProperty(f.name + "." + s.name);
                if (v != null) s.load(v);
            }
            String en = props.getProperty(f.name + ".enabled");
            if (en != null) mm.set(f, Boolean.parseBoolean(en));
        }
    }

    public static void saveIfDirty(ModuleManager mm) {
        if (!dirty) return;
        Properties props = new Properties();
        for (Feature f : mm.all()) {
            props.setProperty(f.name + ".enabled", Boolean.toString(f.isEnabled()));
            for (Setting<?> s : f.settings) props.setProperty(f.name + "." + s.name, s.save());
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            props.store(out, "Lumen");
            dirty = false;
        } catch (IOException e) {
            Lumen.LOGGER.warn("Ayar dosyasi yazilamadi: {}", e.toString());
        }
    }
}
