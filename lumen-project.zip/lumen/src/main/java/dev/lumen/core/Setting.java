package dev.lumen.core;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    public float anim; // GUI animasyon durumu

    protected Setting(String name, T def) {
        this.name = name;
        this.value = def;
    }

    public T get() {
        return value;
    }

    public abstract void load(String raw);

    public abstract String save();

    public static final class Bool extends Setting<Boolean> {
        public Bool(String name, boolean def) {
            super(name, def);
            anim = def ? 1f : 0f;
        }

        public void set(boolean v) {
            value = v;
        }

        public void toggle() {
            value = !value;
        }

        @Override
        public void load(String raw) {
            value = Boolean.parseBoolean(raw);
            anim = value ? 1f : 0f;
        }

        @Override
        public String save() {
            return value.toString();
        }
    }

    public static final class Num extends Setting<Double> {
        public final double min, max, step;

        public Num(String name, double def, double min, double max, double step) {
            super(name, def);
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }

        public int i() {
            return (int) Math.round(value);
        }

        @Override
        public void load(String raw) {
            try {
                set(Double.parseDouble(raw));
            } catch (NumberFormatException ignored) {
                // bozuk deger: varsayilan kalir
            }
        }

        @Override
        public String save() {
            return Double.toString(value);
        }
    }
}
