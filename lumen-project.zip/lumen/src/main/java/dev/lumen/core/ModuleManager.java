package dev.lumen.core;

import dev.lumen.Lumen;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    private final List<Feature> all = new ArrayList<>();
    private final Map<Category, List<Feature>> byCategory = new EnumMap<>(Category.class);
    private Feature[] active = new Feature[0];

    public <F extends Feature> F register(F feature) {
        all.add(feature);
        byCategory.computeIfAbsent(feature.category, c -> new ArrayList<>()).add(feature);
        return feature;
    }

    public List<Feature> all() {
        return all;
    }

    public List<Feature> in(Category category) {
        return byCategory.getOrDefault(category, List.of());
    }

    /** Tek giris noktasi: acma/kapama + cakisma yonetimi. */
    public void set(Feature feature, boolean on) {
        if (on) {
            for (String other : feature.conflicts()) {
                for (Feature f : all) {
                    if (f.name.equals(other) && f.isEnabled()) apply(f, false);
                }
            }
        }
        apply(feature, on);
        active = all.stream().filter(Feature::isEnabled).toArray(Feature[]::new);
    }

    private void apply(Feature feature, boolean on) {
        try {
            feature.applyEnabled(on);
        } catch (RuntimeException e) {
            Lumen.LOGGER.warn("Modul '{}' hata verdi: {}", feature.name, e.toString());
        }
    }

    public void tick() {
        for (Feature f : active) {
            try {
                f.onTick();
            } catch (RuntimeException e) {
                fail(f, e);
            }
        }
    }

    public void renderHud(DrawContext ctx, int w, int h) {
        for (Feature f : active) {
            try {
                f.onHud(ctx, w, h);
            } catch (RuntimeException e) {
                fail(f, e);
            }
        }
    }

    // Hata veren modul kapatilir; boylece log tekrar tekrar basilmaz.
    private void fail(Feature f, RuntimeException e) {
        Lumen.LOGGER.warn("Modul '{}' hata verdi ve kapatildi: {}", f.name, e.toString());
        set(f, false);
    }
}
