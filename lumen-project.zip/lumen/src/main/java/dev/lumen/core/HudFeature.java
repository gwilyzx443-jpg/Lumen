package dev.lumen.core;

/** Ekranda belli bir konuma cizilen modullerin tabani (X/Y ayarlariyla). */
public abstract class HudFeature extends Feature {
    protected final Setting.Num x;
    protected final Setting.Num y;

    protected HudFeature(String name, String description, Category category, int defX, int defY) {
        super(name, description, category);
        this.x = add(new Setting.Num("X", defX, 0, 600, 1));
        this.y = add(new Setting.Num("Y", defY, 0, 400, 1));
    }

    protected int px() {
        return x.i();
    }

    protected int py() {
        return y.i();
    }
}
