package dev.lumen.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Tum modullerin tabani. (Ad "Module" degil: java.lang.Module ile karismasin.) */
public abstract class Feature {
    private static final String[] NONE = new String[0];

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    // GUI animasyon durumu
    public float toggleAnim;
    public float expandAnim;
    public boolean expanded;

    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private boolean enabled;

    protected Feature(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    void applyEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable();
        else onDisable();
    }

    /** Bu modul acilirken kapatilacak modullerin adlari. */
    public String[] conflicts() {
        return NONE;
    }

    protected void onEnable() {}

    protected void onDisable() {}

    public void onTick() {}

    public void onHud(DrawContext ctx, int width, int height) {}
}
