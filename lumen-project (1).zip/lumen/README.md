# Lumen 2.2 (Fabric, Minecraft 1.21.11)

Gereksinimler: JDK 21, Fabric Loader >= 0.18.1, Fabric API (1.21.11).
Derleme: `./gradlew clean build` -> `build/libs/lumen-2.2.0+1.21.11.jar` (`-sources` olmayan dosya)
Kurulum: eski lumen jar'ini sil, yenisini `mods` klasorune at.

ClickGUI: Right Shift. Modul: sol tik ac/kapat, sag tik o modulun ayar ekrani.
Ayarlar: config/lumen/<modul>.properties (modul basina ayri dosya).
Hedef sec/kaldir: G (Controls > Lumen).

Aim Assist, otomatik Trigger Bot saldirisi, Auto Crystal, X-Ray ve Block ESP yalnizca yerel tek oyunculu dunyada
(baska oyuncu yokken) calisir. HUD modulleri, Target HUD gosterimi ve Trigger Bot istatistikleri her dunyada calisir.
