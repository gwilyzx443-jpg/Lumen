package dev.lumen.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;

/**
 * Kilitli hedefi tutar. Hedef yalnizca kullanici secince (tus / GUI) veya
 * "Auto Reselect" aciksa kayip sonrasi degisir; baska varliklar odagi calmaz.
 * Tum hedef islemleri yalnizca yerel tek oyunculu dunyada calisir ve oyuncular hedeflenemez.
 */
public final class TargetManager {
    private static LivingEntity locked;
    private static boolean lost;
    private static int version;
    private static LivingEntity assist;
    private static long assistAt;

    private TargetManager() {}

    /** Yerel tek oyunculu dunya ve dunyada baska oyuncu yok (LAN'da arkadas varsa kapali). */
    public static boolean isSafeWorld(MinecraftClient mc) {
        return mc.player != null && mc.world != null && mc.isInSingleplayer()
                && mc.world.getPlayers().size() == 1;
    }

    public static boolean isValid(MinecraftClient mc, Entity e) {
        return e instanceof LivingEntity le && !(e instanceof PlayerEntity)
                && le.isAlive() && !le.isRemoved() && e != mc.player;
    }

    /** Gecerli kilitli hedefi dondurur; gecersizse temizler. */
    public static LivingEntity get(MinecraftClient mc) {
        if (locked == null) return null;
        if (!isSafeWorld(mc)) {
            locked = null;
            return null;
        }
        if (!isValid(mc, locked) || mc.world.getEntityById(locked.getId()) != locked) {
            locked = null;
            lost = true; // oldu ya da kayboldu
        }
        return locked;
    }

    /** Kullanici secimi. */
    public static void lock(LivingEntity e) {
        locked = e;
        lost = false;
        version++;
    }

    /** Otomatik yeniden secim: kullanici secimi sayilmaz. */
    public static void autoLock(LivingEntity e) {
        locked = e;
        lost = false;
    }

    public static void clear() {
        if (locked != null) version++;
        locked = null;
        assist = null;
        lost = false;
    }

    public static boolean hasLock() {
        return locked != null;
    }

    public static int version() {
        return version;
    }

    /** Hedef kayboldu mu? (bir kez true doner) */
    public static boolean consumeLost() {
        boolean l = lost;
        lost = false;
        return l;
    }

    /** Aim Assist / Trigger Bot'un o an kullandigi (kilitsiz) hedef; Target HUD gostermek icin okur. */
    public static void setAssist(LivingEntity e) {
        assist = e;
        assistAt = System.currentTimeMillis();
    }

    public static LivingEntity assist(MinecraftClient mc) {
        if (assist == null) return null;
        if (System.currentTimeMillis() - assistAt > 600 || !isSafeWorld(mc) || !isValid(mc, assist)) {
            assist = null;
            return null;
        }
        return assist;
    }

    /** Nisan alinan gecerli varligi kilitler (kilidi kaldirmaz). */
    public static void lockCrosshair(MinecraftClient mc) {
        if (!isSafeWorld(mc)) return;
        if (mc.crosshairTarget instanceof EntityHitResult ehr && isValid(mc, ehr.getEntity())) {
            lock((LivingEntity) ehr.getEntity());
        }
    }

    /** Nisan alinan gecerli varligi kilitler; baska yere bakiliyorsa kilidi kaldirir. */
    public static void toggleCrosshair(MinecraftClient mc) {
        if (!isSafeWorld(mc)) return;
        if (mc.crosshairTarget instanceof EntityHitResult ehr && isValid(mc, ehr.getEntity())) {
            LivingEntity le = (LivingEntity) ehr.getEntity();
            if (locked == le) clear();
            else lock(le);
        } else {
            clear();
        }
    }

    public static LivingEntity nearest(MinecraftClient mc, double range) {
        if (!isSafeWorld(mc)) return null;
        LivingEntity best = null;
        double bestD = range * range;
        Box box = mc.player.getBoundingBox().expand(range);
        for (Entity e : mc.world.getOtherEntities(mc.player, box, x -> isValid(mc, x))) {
            double d = mc.player.squaredDistanceTo(e);
            if (d < bestD) {
                bestD = d;
                best = (LivingEntity) e;
            }
        }
        return best;
    }
}
