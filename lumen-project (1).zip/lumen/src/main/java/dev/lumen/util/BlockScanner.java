package dev.lumen.util;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;

/**
 * Oyuncunun cevresindeki bloklari tick basina sabit butceyle (parca parca) tarar.
 * Boylece tek tick'te buyuk bir tarama yapilmaz; FPS dusmez. Sonuc, tarama tamamlaninca degisir.
 */
public final class BlockScanner {
    public record Hit(int x, int y, int z, int group) {}

    private static final int MAX_HITS = 700;

    private final IdentityHashMap<Block, Integer> lookup = new IdentityHashMap<>();
    private final BlockPos.Mutable pos = new BlockPos.Mutable();
    private List<Hit> current = new ArrayList<>();
    private List<Hit> building = new ArrayList<>();
    private int cursor, cx, cy, cz, radius = -1;
    private ClientWorld lastWorld;
    private int customGroup = -1;
    private Block customBlock;

    public BlockScanner(BlockGroups.Group[] groups) {
        for (int i = 0; i < groups.length; i++) {
            for (Block b : groups[i].blocks()) lookup.put(b, i);
        }
    }

    public List<Hit> hits() {
        return current;
    }

    /** Kullanicinin sectigi bloku (grup indeksine) baglar; null ise ozel blok kapatilir. */
    public void setCustom(int group, Block block) {
        if (customBlock != null && Integer.valueOf(customGroup).equals(lookup.get(customBlock))) {
            lookup.remove(customBlock);
        }
        customGroup = group;
        customBlock = block;
        if (block != null) lookup.putIfAbsent(block, group);
        current.removeIf(h -> h.group() == group);
        building.removeIf(h -> h.group() == group);
    }

    public void reset() {
        current = new ArrayList<>();
        building = new ArrayList<>();
        cursor = 0;
        radius = -1;
    }

    public void tick(MinecraftClient mc, int r, boolean[] enabled, int budget) {
        ClientWorld w = mc.world;
        if (w == null || mc.player == null) return;
        if (w != lastWorld) { // boyut degisti / yeni dunya: eski sonuclari at
            lastWorld = w;
            current = new ArrayList<>();
            building = new ArrayList<>();
            cursor = 0;
            radius = -1;
        }
        int side = 2 * r + 1;
        int total = side * side * side;

        if (cursor == 0 || r != radius) {
            if (r != radius) building.clear();
            radius = r;
            cursor = 0;
            BlockPos p = mc.player.getBlockPos();
            cx = p.getX();
            cy = p.getY();
            cz = p.getZ();
        }

        int bottom = w.getBottomY();
        int top = bottom + w.getHeight();
        int end = Math.min(total, cursor + budget);
        for (; cursor < end; cursor++) {
            int i = cursor;
            int y = cy - r + (i / side) % side;
            if (y < bottom || y >= top) continue;
            int x = cx - r + i % side;
            int z = cz - r + i / (side * side);
            Integer g = lookup.get(w.getBlockState(pos.set(x, y, z)).getBlock());
            if (g != null && enabled[g] && building.size() < MAX_HITS) building.add(new Hit(x, y, z, g));
        }

        if (cursor >= total) { // tarama bitti: sonucu yayinla
            List<Hit> old = current;
            current = building;
            building = old;
            building.clear();
            cursor = 0;
        }
    }
}
