package dev.lumen.util;

/** Dunya koordinatini ekran (GUI olcekli) pikseline cevirir. Minecraft'a bagimli degildir. */
public final class Projector {
    private double cx, cy, cz, fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect;
    private int sw, sh;

    /** Son project() cagrisinin sonucu. */
    public double sx, sy, depth;

    public void view(double x, double y, double z, float yawDeg, float pitchDeg, double fovDeg, int sw, int sh) {
        cx = x;
        cy = y;
        cz = z;
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        double cyaw = Math.cos(yaw), syaw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        fx = -syaw * cp;
        fy = -sp;
        fz = cyaw * cp;
        rx = -cyaw;
        rz = -syaw;
        ux = -syaw * sp;
        uy = cp;
        uz = cyaw * sp;
        tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
        this.sw = sw;
        this.sh = sh;
        aspect = (double) sw / Math.max(1, sh);
    }

    /** Nokta kameranin onundeyse true; sonuc sx, sy, depth alanlarinda. */
    public boolean project(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double d = dx * fx + dy * fy + dz * fz;
        if (d < 0.1) return false;
        double xr = dx * rx + dz * rz;
        double yu = dx * ux + dy * uy + dz * uz;
        sx = (xr / (d * tanHalf * aspect) * 0.5 + 0.5) * sw;
        sy = (0.5 - yu / (d * tanHalf) * 0.5) * sh;
        depth = d;
        return true;
    }

    /** Son projeksiyondaki derinlikte 1 blogun piksel boyu. */
    public double pixelsPerBlock() {
        return sh * 0.5 / (depth * tanHalf);
    }
}
