package dev.lumen.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int BG = 0x90000000;
    public static final int TEXT = 0xFFE6E6E6;
    public static final int DIM = 0xFF8A8A8A;
    public static final int ACCENT = 0xFF4F8CFF;
    public static final int ACCENT_DIM = 0x554F8CFF;

    private Draw() {}

    public static int alpha(int color, float a) {
        a = Math.max(0f, Math.min(1f, a));
        int al = (int) (((color >>> 24) & 0xFF) * a);
        return (al << 24) | (color & 0xFFFFFF);
    }

    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >>> s) & 0xFF;
            int cb = (b >>> s) & 0xFF;
            r |= ((int) (ca + (cb - ca) * t)) << s;
        }
        return r;
    }

    /** Koyu zeminli, solunda ince vurgu cizgisi olan HUD etiketi. */
    public static void label(DrawContext ctx, TextRenderer tr, String text, int x, int y) {
        int w = tr.getWidth(text) + 8;
        ctx.fill(x, y, x + w, y + 12, BG);
        ctx.fill(x, y, x + 1, y + 12, ACCENT);
        ctx.drawText(tr, text, x + 4, y + 2, 0xFFFFFFFF, true);
    }

    /** Ici bos dikdortgen cerceve (kalinlik t piksel). */
    public static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int t, int color) {
        ctx.fill(x1, y1, x2, y1 + t, color);
        ctx.fill(x1, y2 - t, x2, y2, color);
        ctx.fill(x1, y1 + t, x1 + t, y2 - t, color);
        ctx.fill(x2 - t, y1 + t, x2, y2 - t, color);
    }
}
