package dev.lumen.util;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

public final class BlockGroups {
    public record Group(String name, int color, Block[] blocks) {}

    /** Son eleman daima "Custom" (kullanicinin sectigi blok). */
    public static final Group[] ORES = {
            new Group("Diamond Ore", 0x4AEDD9, new Block[]{Blocks.DIAMOND_ORE}),
            new Group("Deepslate Diamond Ore", 0x2FB8A8, new Block[]{Blocks.DEEPSLATE_DIAMOND_ORE}),
            new Group("Emerald Ore", 0x17DD62, new Block[]{Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE}),
            new Group("Gold Ore", 0xFCEE4B, new Block[]{Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE}),
            new Group("Iron Ore", 0xD8AF93, new Block[]{Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE}),
            new Group("Coal Ore", 0x6E6E6E, new Block[]{Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE}),
            new Group("Redstone Ore", 0xFF3B30, new Block[]{Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE}),
            new Group("Lapis Ore", 0x2F5BFF, new Block[]{Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE}),
            new Group("Ancient Debris", 0xA0522D, new Block[]{Blocks.ANCIENT_DEBRIS}),
            new Group("Copper Ore", 0xE5855A, new Block[]{Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE}),
            new Group("Quartz Ore", 0xEDE6DB, new Block[]{Blocks.NETHER_QUARTZ_ORE}),
            new Group("Custom", 0xFF77FF, new Block[0]),
    };

    public static final Group[] ESP = {
            new Group("Chest", 0xE0A030, new Block[]{Blocks.CHEST, Blocks.TRAPPED_CHEST}),
            new Group("Ender Chest", 0xB04CFF, new Block[]{Blocks.ENDER_CHEST}),
            new Group("Barrel", 0xA8743C, new Block[]{Blocks.BARREL}),
            new Group("Spawner", 0xFF4F4F, new Block[]{Blocks.SPAWNER}),
            new Group("Obsidian", 0x7A4DFF, new Block[]{Blocks.OBSIDIAN}),
            new Group("Ancient Debris", 0xA0522D, new Block[]{Blocks.ANCIENT_DEBRIS}),
            new Group("Diamond Block", 0x4AEDD9, new Block[]{Blocks.DIAMOND_BLOCK}),
            new Group("Emerald Block", 0x17DD62, new Block[]{Blocks.EMERALD_BLOCK}),
    };

    private BlockGroups() {}
}
