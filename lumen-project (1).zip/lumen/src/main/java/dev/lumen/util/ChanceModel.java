package dev.lumen.util;

/**
 * Hit/Miss modeli: 0..99 arasi zarda  [0, hit) = HIT,  [hit, hit+miss) = MISS,  gerisi = SKIP (denemez).
 * Miss, en fazla (100 - hit) olabilir; boylece iki oran her zaman birbiriyle tutarlidir.
 */
public final class ChanceModel {
    public enum Outcome { HIT, MISS, SKIP }

    private ChanceModel() {}

    public static int maxMiss(int hit) {
        return Math.max(0, 100 - hit);
    }

    public static Outcome roll(int hit, int miss, int roll) {
        int m = Math.min(miss, maxMiss(hit));
        if (roll < hit) return Outcome.HIT;
        if (roll < hit + m) return Outcome.MISS;
        return Outcome.SKIP;
    }
}
