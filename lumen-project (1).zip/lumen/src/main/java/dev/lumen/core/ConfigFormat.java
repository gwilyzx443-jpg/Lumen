package dev.lumen.core;

import java.util.LinkedHashMap;
import java.util.Map;

/** Basit "anahtar=deger" dosya bicimi. Minecraft'a bagimli degildir. */
public final class ConfigFormat {
    private ConfigFormat() {}

    public static String slug(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
    }

    public static String write(Map<String, String> values) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : values.entrySet()) {
            sb.append(e.getKey()).append('=').append(e.getValue().replace('\n', ' ').replace('\r', ' ')).append('\n');
        }
        return sb.toString();
    }

    public static Map<String, String> parse(String text) {
        Map<String, String> out = new LinkedHashMap<>();
        for (String line : text.split("\n")) {
            if (line.isBlank() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            out.put(line.substring(0, eq), line.substring(eq + 1).stripTrailing());
        }
        return out;
    }
}
