package dev.lumen.core;

import dev.lumen.Lumen;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Her modul icin ayri dosya: config/lumen/<modul>.properties.
 * Yalnizca ayar degisince ve yalnizca icerigi degisen dosyalar yazilir.
 */
public final class Config {
    private static final Map<String, String> written = new HashMap<>();
    private static boolean dirty;

    private Config() {}

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("lumen");
    }

    private static Path legacy() {
        return FabricLoader.getInstance().getConfigDir().resolve("lumen.properties");
    }

    public static void markDirty() {
        dirty = true;
    }

    public static void load(ModuleManager mm) {
        Properties old = readLegacy();
        for (Feature f : mm.all()) {
            String slug = ConfigFormat.slug(f.name);
            Map<String, String> m = null;
            Path file = dir().resolve(slug + ".properties");
            if (Files.isRegularFile(file)) {
                try {
                    String text = Files.readString(file, StandardCharsets.UTF_8);
                    m = ConfigFormat.parse(text);
                    written.put(slug, text);
                } catch (IOException e) {
                    Lumen.LOGGER.warn("Ayar dosyasi okunamadi ({}): {}", slug, e.toString());
                }
            } else if (old != null) { // eski tek dosyadan tasima
                m = new LinkedHashMap<>();
                String prefix = f.name + ".";
                for (String key : old.stringPropertyNames()) {
                    if (key.startsWith(prefix)) {
                        String k = key.substring(prefix.length());
                        m.put(k.equals("enabled") ? "_enabled" : k, old.getProperty(key));
                    }
                }
            }
            if (m == null || m.isEmpty()) continue;
            for (Setting<?> s : f.settings) {
                if (!s.persistent()) continue;
                String v = m.get(s.name);
                if (v != null) s.load(v);
            }
            String en = m.get("_enabled");
            if (en != null) mm.set(f, Boolean.parseBoolean(en));
        }
    }

    private static Properties readLegacy() {
        Path p = legacy();
        if (!Files.isRegularFile(p)) return null;
        Properties props = new Properties();
        try (var in = Files.newInputStream(p)) {
            props.load(in);
            return props;
        } catch (IOException e) {
            return null;
        }
    }

    public static void saveIfDirty(ModuleManager mm) {
        if (!dirty) return;
        try {
            Files.createDirectories(dir());
            for (Feature f : mm.all()) {
                Map<String, String> m = new LinkedHashMap<>();
                m.put("_enabled", Boolean.toString(f.isEnabled()));
                for (Setting<?> s : f.settings) {
                    if (s.persistent()) m.put(s.name, s.save());
                }
                String text = ConfigFormat.write(m);
                String slug = ConfigFormat.slug(f.name);
                if (text.equals(written.get(slug))) continue;
                Files.writeString(dir().resolve(slug + ".properties"), text, StandardCharsets.UTF_8);
                written.put(slug, text);
            }
            Files.deleteIfExists(legacy()); // eski tek dosya artik gereksiz
            dirty = false;
        } catch (IOException e) {
            Lumen.LOGGER.warn("Ayarlar kaydedilemedi: {}", e.toString());
        }
    }
}
