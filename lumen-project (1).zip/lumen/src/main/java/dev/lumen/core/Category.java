package dev.lumen.core;

public enum Category {
    COMBAT("Combat"), RENDER("Render"), MOVEMENT("Movement"), PLAYER("Player"),
    WORLD("World"), HUD("HUD"), MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
