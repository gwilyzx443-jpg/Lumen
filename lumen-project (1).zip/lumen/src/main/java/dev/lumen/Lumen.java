package dev.lumen;

import dev.lumen.core.Config;
import dev.lumen.core.ModuleManager;
import dev.lumen.gui.ClickGuiScreen;
import dev.lumen.module.*;
import dev.lumen.util.Clicks;
import dev.lumen.util.TargetManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Lumen implements ClientModInitializer {
    public static final String ID = "lumen";
    public static final Logger LOGGER = LoggerFactory.getLogger("Lumen");
    public static final ModuleManager MODULES = new ModuleManager();

    public static KeyBinding openGuiKey;
    public static KeyBinding zoomKey;
    public static KeyBinding toggleSprintKey;
    public static KeyBinding selectTargetKey;

    public static AimTraining AIM;
    public static TriggerBot TRIGGER;
    public static ToggleSprint TOGGLE_SPRINT;
    public static Fullbright FULLBRIGHT;
    public static Zoom ZOOM;
    public static CpsDisplay CPS;
    public static Keystrokes KEYSTROKES;

    @Override
    public void onInitializeClient() {
        // Tus atamalari: Ayarlar > Kontroller > Lumen kategorisinden degistirilebilir.
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(ID, "main"));
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumen.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumen.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));
        toggleSprintKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumen.toggle_sprint", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        selectTargetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumen.select_target", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, cat));

        // Combat (siralama = tick sirasi: Target Manager, Aim Assist'ten once calisir)
        AIM = MODULES.register(new AimTraining());
        MODULES.register(new TargetHud());
        MODULES.register(new TargetControl());
        MODULES.register(new AimAssist());
        TRIGGER = MODULES.register(new TriggerBot());
        MODULES.register(new AutoCrystal());
        // Movement
        MODULES.register(new AutoSprint());
        TOGGLE_SPRINT = MODULES.register(new ToggleSprint());
        // Render
        FULLBRIGHT = MODULES.register(new Fullbright());
        ZOOM = MODULES.register(new Zoom());
        KEYSTROKES = MODULES.register(new Keystrokes());
        MODULES.register(new ArmorHud());
        MODULES.register(new PotionHud());
        // Misc
        MODULES.register(new FpsDisplay());
        CPS = MODULES.register(new CpsDisplay());
        MODULES.register(new Coordinates());
        // World
        MODULES.register(new XRay());
        MODULES.register(new BlockEsp());
        // HUD
        MODULES.register(new ElytraHud());

        Config.load(MODULES);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                ZOOM.restore(); // dunyadan cikarken FOV/hassasiyet geri yuklensin
                TargetManager.clear();
                return;
            }
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            while (toggleSprintKey.wasPressed()) {
                if (TOGGLE_SPRINT.isEnabled()) TOGGLE_SPRINT.flip();
            }
            while (selectTargetKey.wasPressed()) {
                if (client.currentScreen == null) TargetManager.toggleCrosshair(client);
            }
            if (CPS.isEnabled() || KEYSTROKES.isEnabled()) Clicks.pollRight(client);
            MODULES.tick();
        });

        ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
            if (CPS.isEnabled() || KEYSTROKES.isEnabled() || TRIGGER.isEnabled()) Clicks.addLeft();
            if (AIM.isEnabled()) AIM.onAttack();
            if (TRIGGER.isEnabled()) TRIGGER.onManualAttack();
            return false; // saldiriyi iptal etme
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of(ID, "hud"),
                (ctx, tickCounter) -> {
                    MinecraftClient c = MinecraftClient.getInstance();
                    if (c.player == null || c.options.hudHidden) return;
                    MODULES.renderHud(ctx, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
                });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ZOOM.restore();
            Config.saveIfDirty(MODULES);
        });
    }
}
