package dev.lumen.gui;

import dev.lumen.Lumen;
import dev.lumen.core.Config;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Bir modulun kendi ayar ekrani: Enable, slider, checkbox, dropdown, renk secici, varsayilana don, kaydirma. */
public final class ModuleScreen extends Screen {
    private static final int ROW_H = 20, ROW_GAP = 2, HEAD_H = 26, BAR_H = 22, OPT_H = 16;
    private static final int PANEL_BG = 0xF0121212, HEADER = 0xFF0A0A0A, ROW_BG = 0xF01A1A1A, ROW_HOVER = 0xF0242424;
    private static final int K_SET = 0, K_BACK = 1, K_ENABLE = 2, K_RESET = 3, K_OPT = 4, K_BAR = 5;

    private record Hit(int x, int y, int w, int h, int kind, Setting<?> s, int idx) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final Screen parent;
    private final Feature f;
    private final List<Hit> hits = new ArrayList<>();
    private float open, scroll;
    private int contentH, viewH, viewTop;
    private Hit dragging;
    private boolean scrollDrag, bgDrag;
    private Setting.Text editing;
    private Setting.Mode popup;
    private int popupX, popupY, popupW;

    public ModuleScreen(Screen parent, Feature f) {
        super(Text.literal(f.name));
        this.parent = parent;
        this.f = f;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Config.saveIfDirty(Lumen.MODULES);
        client.setScreen(parent);
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        open += (1f - open) * 0.2f;
        if (open > 0.995f) open = 1f;
        float a = open;
        TextRenderer tr = client.textRenderer;

        ctx.fill(0, 0, width, height, Draw.alpha(0xFF000000, 0.55f * a));
        int w = Math.min(280, width - 16);
        int x0 = (width - w) / 2;
        int top = 16 + Math.round((1f - a) * -12f);
        int bottom = height - 12;
        ctx.fill(x0, top, x0 + w, bottom, Draw.alpha(PANEL_BG, a));

        // baslik
        ctx.fill(x0, top, x0 + w, top + HEAD_H, Draw.alpha(HEADER, a));
        ctx.fill(x0, top + HEAD_H - 1, x0 + w, top + HEAD_H, Draw.alpha(Draw.ACCENT, a));
        ctx.drawText(tr, f.name, x0 + (w - tr.getWidth(f.name)) / 2, top + 9, Draw.alpha(0xFFFFFFFF, a), true);
        button(ctx, tr, "< Back", x0 + 6, top + 5, 46, 16, mx, my, a, 0xFF2A2A2A, Draw.TEXT);
        hits.add(new Hit(x0 + 6, top + 5, 46, 16, K_BACK, null, 0));

        f.toggleAnim = ease(f.toggleAnim, f.isEnabled() ? 1f : 0f, 0.25f);
        int ec = Draw.lerpColor(0xFF2A2A2A, Draw.ACCENT, f.toggleAnim);
        button(ctx, tr, f.isEnabled() ? "ON" : "OFF", x0 + w - 52, top + 5, 46, 16, mx, my, a, ec, 0xFFFFFFFF);
        hits.add(new Hit(x0 + w - 52, top + 5, 46, 16, K_ENABLE, null, 0));

        // varsayilana don
        int ry0 = top + HEAD_H + 4;
        button(ctx, tr, "Reset to Defaults", x0 + 6, ry0, w - 12, BAR_H - 6, mx, my, a, 0xFF2A2A2A, Draw.TEXT);
        hits.add(new Hit(x0 + 6, ry0, w - 12, BAR_H - 6, K_RESET, null, 0));

        // ayar listesi
        viewTop = top + HEAD_H + BAR_H + 4;
        int viewBottom = bottom - 4;
        viewH = viewBottom - viewTop;
        contentH = f.settings.size() * (ROW_H + ROW_GAP);
        scroll = Math.max(0f, Math.min(scroll, Math.max(0, contentH - viewH)));

        int rx = x0 + 6, rw = w - 22;
        ctx.enableScissor(x0, viewTop, x0 + w, viewBottom);
        int y = viewTop - Math.round(scroll);
        for (Setting<?> s : f.settings) {
            if (y + ROW_H >= viewTop && y <= viewBottom) {
                row(ctx, tr, s, rx, y, rw, mx, my, a);
                int cy1 = Math.max(y, viewTop), cy2 = Math.min(y + ROW_H, viewBottom);
                if (cy2 > cy1) hits.add(new Hit(rx, cy1, rw, cy2 - cy1, K_SET, s, 0));
            }
            y += ROW_H + ROW_GAP;
        }
        ctx.disableScissor();

        // kaydirma cubugu
        if (contentH > viewH) {
            int tx = x0 + w - 10;
            ctx.fill(tx, viewTop, tx + 4, viewBottom, Draw.alpha(0xFF0A0A0A, a));
            int thumbH = Math.max(16, viewH * viewH / contentH);
            int thumbY = viewTop + Math.round((viewH - thumbH) * (scroll / (contentH - viewH)));
            ctx.fill(tx, thumbY, tx + 4, thumbY + thumbH, Draw.alpha(Draw.ACCENT, a));
            hits.add(new Hit(x0 + w - 14, viewTop, 14, viewH, K_BAR, null, 0));
        }

        // dropdown listesi (en ustte)
        if (popup != null) {
            int ph = popup.options.length * OPT_H;
            int py = popupY;
            if (py + ph > height - 4) py = popupY - ROW_H - ph;
            ctx.fill(popupX - 1, py - 1, popupX + popupW + 1, py + ph + 1, Draw.alpha(Draw.ACCENT, a));
            for (int i = 0; i < popup.options.length; i++) {
                int oy = py + i * OPT_H;
                boolean hover = mx >= popupX && mx < popupX + popupW && my >= oy && my < oy + OPT_H;
                int bg = i == popup.index() ? 0xFF1F2F4A : hover ? ROW_HOVER : 0xFF151515;
                ctx.fill(popupX, oy, popupX + popupW, oy + OPT_H, Draw.alpha(bg, a));
                ctx.drawText(tr, popup.options[i], popupX + 8, oy + 4, Draw.alpha(Draw.TEXT, a), false);
                hits.add(new Hit(popupX, oy, popupW, OPT_H, K_OPT, popup, i));
            }
        }
    }

    private void button(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h,
                        int mx, int my, float a, int bg, int fg) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        ctx.fill(x, y, x + w, y + h, Draw.alpha(hover ? Draw.lerpColor(bg, 0xFFFFFFFF, 0.12f) : bg, a));
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, Draw.alpha(fg, a), false);
    }

    private void row(DrawContext ctx, TextRenderer tr, Setting<?> s, int x, int y, int w, int mx, int my, float a) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + ROW_H && my >= viewTop;
        ctx.fill(x, y, x + w, y + ROW_H, Draw.alpha(hover ? ROW_HOVER : ROW_BG, a));
        if (s instanceof Setting.Bool b) {
            b.anim = ease(b.anim, b.get() ? 1f : 0f, 0.3f);
            ctx.drawText(tr, b.name, x + 8, y + 6, Draw.alpha(Draw.TEXT, a), false);
            int tx = x + w - 30, ty = y + 5;
            ctx.fill(tx, ty, tx + 22, ty + 10, Draw.alpha(Draw.lerpColor(0xFF3A3A3A, Draw.ACCENT, b.anim), a));
            int kx = tx + 1 + Math.round(12 * b.anim);
            ctx.fill(kx, ty + 1, kx + 8, ty + 9, Draw.alpha(0xFFFFFFFF, a));
        } else if (s instanceof Setting.Num n) {
            float frac = (float) ((n.get() - n.min) / (n.max - n.min));
            n.anim = ease(n.anim, frac, 0.35f);
            ctx.fill(x, y, x + Math.round(w * n.anim), y + ROW_H, Draw.alpha(Draw.ACCENT_DIM, a));
            ctx.drawText(tr, n.name, x + 8, y + 6, Draw.alpha(Draw.TEXT, a), false);
            String v = n.step >= 1 ? String.valueOf(n.i()) : String.valueOf(Math.round(n.get() * 100.0) / 100.0);
            v += n.unit;
            ctx.drawText(tr, v, x + w - 8 - tr.getWidth(v), y + 6, Draw.alpha(Draw.DIM, a), false);
        } else if (s instanceof Setting.Mode m) {
            ctx.drawText(tr, m.name, x + 8, y + 6, Draw.alpha(Draw.TEXT, a), false);
            String v = m.get() + " v";
            ctx.drawText(tr, v, x + w - 8 - tr.getWidth(v), y + 6, Draw.alpha(Draw.ACCENT, a), false);
        } else if (s instanceof Setting.Text t) {
            ctx.drawText(tr, t.name, x + 8, y + 6, Draw.alpha(Draw.TEXT, a), false);
            int bx = x + w / 2 - 12, bw = w - (w / 2 - 12) - 6;
            ctx.fill(bx - 1, y + 2, bx + bw + 1, y + ROW_H - 2, Draw.alpha(t == editing ? Draw.ACCENT : 0xFF2A2A2A, a));
            ctx.fill(bx, y + 3, bx + bw, y + ROW_H - 3, Draw.alpha(0xFF0A0A0A, a));
            String shown = t.get() + (t == editing && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
            while (shown.length() > 1 && tr.getWidth(shown) > bw - 6) shown = shown.substring(1);
            ctx.drawText(tr, shown, bx + 3, y + 6, Draw.alpha(Draw.TEXT, a), false);
        } else if (s instanceof Setting.Button bt) {
            ctx.fill(x, y, x + w, y + ROW_H, Draw.alpha(hover ? 0xFF2F3E5C : 0xFF222B3D, a));
            ctx.drawText(tr, bt.name, x + (w - tr.getWidth(bt.name)) / 2, y + 6, Draw.alpha(Draw.TEXT, a), false);
        } else if (s instanceof Setting.Color c) {
            ctx.drawText(tr, c.name, x + 8, y + 3, Draw.alpha(Draw.TEXT, a), false);
            ctx.fill(x + w - 26, y + 2, x + w - 8, y + 11, Draw.alpha(0xFF000000 | c.rgb(), a));
            int segs = 40;
            for (int k = 0; k < segs; k++) {
                int sx1 = x + k * w / segs, sx2 = x + (k + 1) * w / segs;
                ctx.fill(sx1, y + 14, sx2, y + 19, Draw.alpha(0xFF000000 | Setting.Color.fromPos(k / (segs - 1f)), a));
            }
            int mkx = x + Math.round(c.pos() * (w - 2));
            ctx.fill(mkx, y + 12, mkx + 2, y + 20, Draw.alpha(0xFFFFFFFF, a));
        }
    }

    private static float ease(float cur, float target, float speed) {
        float v = cur + (target - cur) * speed;
        return Math.abs(target - v) < 0.002f ? target : v;
    }

    // ----------------------------------------------------------------- input

    private Hit hitAt(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) { // en ustte cizilen once
            Hit h = hits.get(i);
            if (h.contains(mx, my)) return h;
        }
        return null;
    }

    private void applyDrag(double mx) {
        if (dragging == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragging.x()) / dragging.w()));
        if (dragging.s() instanceof Setting.Num n) {
            n.set(n.min + t * (n.max - n.min));
        } else if (dragging.s() instanceof Setting.Color c) {
            c.setPos((float) t);
        }
        Config.markDirty();
    }

    private void scrollFromMouse(double my) {
        if (contentH <= viewH) return;
        double t = Math.max(0, Math.min(1, (my - viewTop) / viewH));
        scroll = (float) (t * (contentH - viewH));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        editing = null; // baska yere tiklayinca metin girisi biter

        if (popup != null) { // acik dropdown tum tiklamalari alir
            Hit h = hitAt(mx, my);
            if (h != null && h.kind() == K_OPT && btn == 0) {
                popup.select(h.idx());
                Config.markDirty();
            }
            popup = null;
            return true;
        }

        Hit h = hitAt(mx, my);
        if (h == null) {
            bgDrag = true;
            return true;
        }
        if (btn != 0) return true;
        switch (h.kind()) {
            case K_BACK -> close();
            case K_ENABLE -> {
                Lumen.MODULES.set(f, !f.isEnabled());
                Config.markDirty();
            }
            case K_RESET -> {
                for (Setting<?> s : f.settings) s.reset();
                Config.markDirty();
            }
            case K_BAR -> {
                scrollDrag = true;
                scrollFromMouse(my);
            }
            case K_SET -> {
                if (h.s() instanceof Setting.Bool b) {
                    b.toggle();
                    Config.markDirty();
                } else if (h.s() instanceof Setting.Num || h.s() instanceof Setting.Color) {
                    dragging = h;
                    applyDrag(mx);
                } else if (h.s() instanceof Setting.Text t) {
                    editing = t;
                } else if (h.s() instanceof Setting.Button bt) {
                    bt.run();
                    Config.markDirty();
                } else if (h.s() instanceof Setting.Mode m) {
                    popup = m;
                    popupX = h.x();
                    popupY = h.y() + h.h();
                    popupW = h.w();
                }
            }
            default -> { }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) {
            applyDrag(click.x());
            return true;
        }
        if (scrollDrag) {
            scrollFromMouse(click.y());
            return true;
        }
        if (bgDrag) {
            scroll = Math.max(0f, Math.min(Math.max(0, contentH - viewH), scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        scrollDrag = false;
        bgDrag = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll = Math.max(0f, Math.min(Math.max(0, contentH - viewH), scroll - (float) (vertical * 20)));
        return true;
    }

    /** Klavye tusunu karaktere cevirir (blok kimligi icin: a-z, 0-9, _, :, ., /). */
    private static char keyChar(int key, boolean shift) {
        if (key >= 65 && key <= 90) return (char) ('a' + key - 65);
        if (key >= 48 && key <= 57) return (char) ('0' + key - 48);
        if (key >= 320 && key <= 329) return (char) ('0' + key - 320);
        if (key == 32 || key == 45) return '_';
        if (key == 59 && shift) return ':';
        if (key == 46) return '.';
        if (key == 47) return '/';
        return 0;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (editing != null) {
            int k = input.key();
            if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
                return true;
            }
            String cur = editing.get();
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (!cur.isEmpty()) {
                    editing.set(cur.substring(0, cur.length() - 1));
                    Config.markDirty();
                }
                return true;
            }
            char ch = keyChar(k, (input.modifiers() & 1) != 0);
            if (ch != 0) {
                editing.set(cur + ch);
                Config.markDirty();
            }
            return true;
        }
        int bound = InputUtil.fromTranslationKey(Lumen.openGuiKey.getBoundKeyTranslationKey()).getCode();
        if (input.key() == bound) { // GUI tusu: tamamen kapat
            Config.saveIfDirty(Lumen.MODULES);
            client.setScreen(null);
            return true;
        }
        return super.keyPressed(input);
    }
}
