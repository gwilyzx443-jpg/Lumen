package dev.lumen.gui;

import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.Config;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 112, HEADER_H = 20, ROW_H = 18, SET_H = 16, GAP = 10;
    private static final int HEADER = 0xFF0A0A0A, ROW = 0xF0181818, ROW_HOVER = 0xF0242424, SET_BG = 0xF0121212;

    private record Hit(int x, int y, int w, int h, Feature feature, Setting<?> setting) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Hit dragging;
    private float open;
    private float scrollX;
    private boolean bgDrag;
    private String tip;

    public ClickGuiScreen() {
        super(Text.literal("Lumen"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Config.saveIfDirty(Lumen.MODULES);
        super.close();
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        tip = null;
        open += (1f - open) * 0.2f;
        if (open > 0.995f) open = 1f;
        float a = open;
        TextRenderer tr = client.textRenderer;

        ctx.fill(0, 0, width, height, Draw.alpha(0xFF000000, 0.5f * a));

        List<Category> cats = new ArrayList<>(); // bos kategoriler gizlenir
        for (Category c : Category.values()) {
            if (!Lumen.MODULES.in(c).isEmpty()) cats.add(c);
        }
        int total = cats.size() * PANEL_W + (cats.size() - 1) * GAP;
        scrollX = Math.max(Math.min(0, width - total - 16), Math.min(0, scrollX));
        int x0 = total + 16 <= width ? (width - total) / 2 : 8 + Math.round(scrollX);
        int y0 = 30 + Math.round((1f - a) * -14f);

        String title = "LUMEN";
        ctx.drawText(tr, title, (width - tr.getWidth(title)) / 2, y0 - 16, Draw.alpha(Draw.TEXT, a), true);

        for (int i = 0; i < cats.size(); i++) {
            panel(ctx, tr, cats.get(i), x0 + i * (PANEL_W + GAP), y0, mx, my, a);
        }
        if (tip != null) {
            ctx.drawText(tr, tip, (width - tr.getWidth(tip)) / 2, height - 18, Draw.alpha(Draw.DIM, a), true);
        }
    }

    private void panel(DrawContext ctx, TextRenderer tr, Category cat, int px, int py, int mx, int my, float a) {
        ctx.fill(px, py, px + PANEL_W, py + HEADER_H, Draw.alpha(HEADER, a));
        ctx.fill(px, py + HEADER_H - 1, px + PANEL_W, py + HEADER_H, Draw.alpha(Draw.ACCENT, a));
        ctx.drawText(tr, cat.label, px + 8, py + 6, Draw.alpha(0xFFFFFFFF, a), true);
        int y = py + HEADER_H;

        for (Feature f : Lumen.MODULES.in(cat)) {
            f.toggleAnim = ease(f.toggleAnim, f.isEnabled() ? 1f : 0f, 0.25f);
            f.expandAnim = ease(f.expandAnim, f.expanded && !f.settings.isEmpty() ? 1f : 0f, 0.25f);

            boolean hover = mx >= px && mx < px + PANEL_W && my >= y && my < y + ROW_H;
            if (hover) tip = f.description;
            int bg = hover ? ROW_HOVER : ROW;
            ctx.fill(px, y, px + PANEL_W, y + ROW_H, Draw.alpha(bg, a));
            ctx.fill(px, y, px + 2, y + ROW_H, Draw.alpha(Draw.ACCENT, a * f.toggleAnim));
            int fg = Draw.lerpColor(Draw.DIM, 0xFFFFFFFF, f.toggleAnim);
            ctx.drawText(tr, f.name, px + 8, y + 5, Draw.alpha(fg, a), true);
            if (!f.settings.isEmpty()) {
                String mark = ">"; // sag tik: modulun ayar ekrani
                ctx.drawText(tr, mark, px + PANEL_W - 12, y + 5, Draw.alpha(Draw.DIM, a), true);
            }
            hits.add(new Hit(px, y, PANEL_W, ROW_H, f, null));
            y += ROW_H;

            if (f.expandAnim > 0.01f && !f.settings.isEmpty()) {
                int vis = Math.round(f.settings.size() * SET_H * f.expandAnim);
                ctx.enableScissor(px, y, px + PANEL_W, y + vis);
                int sy = y;
                for (Setting<?> s : f.settings) {
                    setting(ctx, tr, s, px, sy, mx, my, a);
                    if (sy + SET_H <= y + vis) hits.add(new Hit(px, sy, PANEL_W, SET_H, f, s));
                    sy += SET_H;
                }
                ctx.disableScissor();
                y += vis;
            }
        }
        ctx.fill(px, y, px + PANEL_W, y + 2, Draw.alpha(HEADER, a));
    }

    private void setting(DrawContext ctx, TextRenderer tr, Setting<?> s, int x, int y, int mx, int my, float a) {
        ctx.fill(x, y, x + PANEL_W, y + SET_H, Draw.alpha(SET_BG, a));
        if (s instanceof Setting.Bool b) {
            b.anim = ease(b.anim, b.get() ? 1f : 0f, 0.3f);
            ctx.drawText(tr, b.name, x + 8, y + 4, Draw.alpha(Draw.TEXT, a), false);
            int tx = x + PANEL_W - 28, ty = y + 4;
            ctx.fill(tx, ty, tx + 18, ty + 8, Draw.alpha(Draw.lerpColor(0xFF3A3A3A, Draw.ACCENT, b.anim), a));
            int kx = tx + 1 + Math.round(10 * b.anim);
            ctx.fill(kx, ty + 1, kx + 6, ty + 7, Draw.alpha(0xFFFFFFFF, a));
        } else if (s instanceof Setting.Num n) {
            float frac = (float) ((n.get() - n.min) / (n.max - n.min));
            n.anim = ease(n.anim, frac, 0.35f);
            ctx.fill(x, y, x + Math.round(PANEL_W * n.anim), y + SET_H, Draw.alpha(Draw.ACCENT_DIM, a));
            ctx.drawText(tr, n.name, x + 8, y + 4, Draw.alpha(Draw.TEXT, a), false);
            String v = String.valueOf(Math.round(n.get() * 100.0) / 100.0);
            if (n.step >= 1) v = String.valueOf(n.i());
            v += n.unit;
            ctx.drawText(tr, v, x + PANEL_W - 8 - tr.getWidth(v), y + 4, Draw.alpha(Draw.DIM, a), false);
        } else if (s instanceof Setting.Mode m) {
            ctx.drawText(tr, m.name, x + 8, y + 4, Draw.alpha(Draw.TEXT, a), false);
            String v = m.get();
            ctx.drawText(tr, v, x + PANEL_W - 8 - tr.getWidth(v), y + 4, Draw.alpha(Draw.ACCENT, a), false);
        }
    }

    private static float ease(float cur, float target, float speed) {
        float v = cur + (target - cur) * speed;
        return Math.abs(target - v) < 0.002f ? target : v;
    }

    // ----------------------------------------------------------------- input

    private Hit hitAt(double mx, double my) {
        for (Hit h : hits) {
            if (h.contains(mx, my)) return h;
        }
        return null;
    }

    private void drag(double mx) {
        if (dragging == null || !(dragging.setting() instanceof Setting.Num n)) return;
        double t = Math.max(0, Math.min(1, (mx - dragging.x()) / dragging.w()));
        n.set(n.min + t * (n.max - n.min));
        Config.markDirty();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        Hit h = hitAt(click.x(), click.y());
        if (h == null) {
            bgDrag = true;
            return super.mouseClicked(click, doubled);
        }
        int btn = click.button();
        if (h.setting() == null) {
            if (btn == 0) {
                Lumen.MODULES.set(h.feature(), !h.feature().isEnabled());
                Config.markDirty();
            } else if (btn == 1 && !h.feature().settings.isEmpty()) {
                client.setScreen(new ModuleScreen(this, h.feature()));
            }
        } else if (h.setting() instanceof Setting.Mode m && (btn == 0 || btn == 1)) {
            if (btn == 0) m.next();
            else m.prev();
            Config.markDirty();
        } else if (btn == 0) {
            if (h.setting() instanceof Setting.Bool b) {
                b.toggle();
                Config.markDirty();
            } else if (h.setting() instanceof Setting.Num) {
                dragging = h;
                drag(click.x());
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) {
            drag(click.x());
            return true;
        }
        if (bgDrag) {
            scrollX += (float) dx; // bos alani surukleyerek paneller arasinda kaydir
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        bgDrag = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        Hit h = hitAt(mx, my);
        if (h != null && h.setting() instanceof Setting.Num n) {
            n.set(n.get() + Math.signum(vertical) * n.step);
            Config.markDirty();
            return true;
        }
        scrollX += (float) (vertical * 24);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int bound = InputUtil.fromTranslationKey(Lumen.openGuiKey.getBoundKeyTranslationKey()).getCode();
        if (input.key() == bound) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
