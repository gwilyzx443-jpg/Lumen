package dev.lumen.module;

import dev.lumen.Lumen;
import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;

import java.util.Collection;

public final class PotionHud extends HudFeature {
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    // X burada sag kenardan uzaklik.
    public PotionHud() {
        super("Potion HUD", "Aktif efektleri ve kalan sureyi gosterir.", Category.HUD, 4, 60);
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (mc.player == null || mc.world == null) return;
        Collection<StatusEffectInstance> effects = mc.player.getStatusEffects();
        if (effects.isEmpty()) return;
        float tickRate = mc.world.getTickManager().getTickRate();
        int y = py();
        for (StatusEffectInstance e : effects) {
            // Fullbright'in kendi eklediği efekti listeleme
            if (Lumen.FULLBRIGHT.isEnabled() && e.isInfinite()
                    && e.getEffectType().equals(StatusEffects.NIGHT_VISION)) continue;
            int amp = e.getAmplifier();
            String level = amp < ROMAN.length ? ROMAN[amp] : String.valueOf(amp + 1);
            String line = e.getEffectType().value().getName().getString() + " " + level + "  "
                    + StatusEffectUtil.getDurationText(e, 1.0f, tickRate).getString();
            int lw = mc.textRenderer.getWidth(line) + 8;
            Draw.label(ctx, mc.textRenderer, line, w - lw - px(), y);
            y += 14;
        }
    }
}
