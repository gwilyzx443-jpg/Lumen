package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class ElytraHud extends HudFeature {
    private final Setting.Bool onlyElytra = add(new Setting.Bool("Only With Elytra", true));
    private final Setting.Bool showStatus = add(new Setting.Bool("Show Status", true));
    private final Setting.Bool showSpeed = add(new Setting.Bool("Show Speed", true));
    private final Setting.Bool showAlt = add(new Setting.Bool("Show Altitude", true));
    private final Setting.Bool showDur = add(new Setting.Bool("Show Durability", true));
    private final Setting.Bool showCoords = add(new Setting.Bool("Show Coordinates", true));
    private final List<String> lines = new ArrayList<>();

    public ElytraHud() {
        super("Elytra HUD", "Elytra durumu, hiz, yukseklik, dayaniklilik ve koordinat.", Category.HUD, 300, 4);
    }

    @Override
    public void onTick() {
        lines.clear();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        boolean has = chest.isOf(Items.ELYTRA);
        if (onlyElytra.get() && !has) return;

        int max = has ? chest.getMaxDamage() : 0;
        int left = has ? max - chest.getDamage() : 0;
        if (showStatus.get()) {
            String st = !has ? "None" : p.isGliding() ? "Gliding" : left <= 1 ? "Broken" : "Ready";
            lines.add("Elytra: " + st);
        }
        if (showSpeed.get()) {
            Vec3d v = p.getVelocity();
            lines.add(String.format("Speed: %.1f b/s", v.length() * 20.0));
        }
        if (showAlt.get()) lines.add("Altitude: " + (int) Math.floor(p.getY()) + "m");
        if (showDur.get() && has) lines.add("Durability: " + left + "/" + max);
        if (showCoords.get()) lines.add(String.format("XYZ: %.0f %.0f %.0f", p.getX(), p.getY(), p.getZ()));
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        int y = py();
        for (String line : lines) {
            Draw.label(ctx, mc.textRenderer, line, px(), y);
            y += 14;
        }
    }
}
