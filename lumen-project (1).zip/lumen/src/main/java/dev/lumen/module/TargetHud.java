package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.Feature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import dev.lumen.util.TargetManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Antrenman icin: yalnizca tek oyunculu dunyada, kilitli veya nisan alinan varligin bilgisini gosterir. */
public final class TargetHud extends Feature {
    private static final int RED = 0xFFE5484D;

    private final Setting.Num offX = add(new Setting.Num("Offset X", 16, -200, 200, 1));
    private final Setting.Num offY = add(new Setting.Num("Offset Y", 16, -200, 200, 1));
    private final Setting.Num width = add(new Setting.Num("Width", 112, 80, 180, 4));
    private final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    private final Setting.Bool showArmor = add(new Setting.Bool("Show Armor", true));

    private LivingEntity target;
    private LivingEntity drawn;
    private long lastSeen;
    private boolean isLocked;
    private String name = "";
    private String info = "";
    private float hp, max = 20f, shown, alpha;

    public TargetHud() {
        super("Target HUD", "Hedefin can, zirh, mesafe ve kilit durumu (tek oyunculu).", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            target = null;
            isLocked = false;
            return;
        }
        long now = System.currentTimeMillis();
        LivingEntity locked = TargetManager.get(mc);
        if (locked != null) {
            target = locked;
            lastSeen = now;
            isLocked = true;
        } else {
            isLocked = false;
            LivingEntity assist = TargetManager.assist(mc);
            HitResult hr = mc.crosshairTarget;
            if (assist != null) {
                target = assist;
                lastSeen = now;
            } else if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && le.isAlive()) {
                target = le;
                lastSeen = now;
            } else if (target != null && (now - lastSeen > 1500 || !target.isAlive() || target.isRemoved())) {
                target = null;
            }
        }
        if (target != null && mc.player != null) {
            StringBuilder sb = new StringBuilder();
            if (isLocked) sb.append("LOCKED  ");
            if (showDist.get()) sb.append(Math.round(mc.player.distanceTo(target) * 10f) / 10f).append("m  ");
            if (showArmor.get()) sb.append("Armor ").append(target.getArmor());
            info = sb.toString().trim();
        }
    }

    @Override
    protected void onDisable() {
        target = null;
        drawn = null;
        alpha = 0f;
        isLocked = false;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (target != null) {
            if (target != drawn) {
                drawn = target;
                shown = target.getHealth();
                alpha = 0f;
            }
            name = target.getName().getString();
            hp = target.getHealth();
            max = Math.max(1f, target.getMaxHealth());
            alpha += (1f - alpha) * 0.25f;
        } else {
            alpha += (0f - alpha) * 0.25f;
            if (alpha < 0.03f) return;
        }
        shown += (hp - shown) * 0.2f;

        int bw = width.i();
        int barW = bw - 12;
        int x = w / 2 + offX.i();
        int y = h / 2 + offY.i();
        boolean hasInfo = !info.isEmpty();
        int boxH = hasInfo ? 42 : 32;
        var tr = mc.textRenderer;
        ctx.fill(x, y, x + bw, y + boxH, Draw.alpha(Draw.BG, alpha));
        ctx.fill(x, y, x + 2, y + boxH, Draw.alpha(isLocked ? RED : Draw.ACCENT, alpha));
        ctx.drawText(tr, name, x + 6, y + 4, Draw.alpha(0xFFFFFFFF, alpha), true);

        float frac = Math.max(0f, Math.min(1f, shown / max));
        int bx = x + 6, by = y + 18;
        ctx.fill(bx, by, bx + barW, by + 8, Draw.alpha(0xFF2A2A2A, alpha));
        int color = Draw.lerpColor(RED, 0xFF46C25B, frac);
        ctx.fill(bx, by, bx + (int) (barW * frac), by + 8, Draw.alpha(color, alpha));
        if (hasInfo) ctx.drawText(tr, info, x + 6, y + 30, Draw.alpha(isLocked ? RED : Draw.DIM, alpha), true);
    }
}
