package dev.lumen.module;

import dev.lumen.core.Category;
import dev.lumen.core.HudFeature;
import dev.lumen.core.Setting;
import dev.lumen.util.Draw;
import dev.lumen.util.TargetManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

public final class TargetControl extends HudFeature {
    private final Setting.Bool auto = add(new Setting.Bool("Auto Reselect", true));
    private final Setting.Num range = add(new Setting.Num("Search Range", 10, 3, 20, 1));
    private final Setting.Bool showName = add(new Setting.Bool("Show Name", true));
    private final Setting.Bool lockNearest = add(new Setting.Bool("Lock Nearest", false));
    private final Setting.Bool clearTarget = add(new Setting.Bool("Clear Target", false));

    private boolean searching;
    private int seenVersion;
    private int tick;
    private String text = "Target: none";

    public TargetControl() {
        super("Target Manager", "Hedef sec/kaldir (Controls'te tus). Sadece tek oyunculu.", Category.COMBAT, 90, 4);
    }

    @Override
    public void onTick() {
        if (!TargetManager.isSafeWorld(mc)) {
            TargetManager.clear();
            searching = false;
            text = "Target: n/a";
            return;
        }
        if (clearTarget.get()) {
            clearTarget.set(false);
            TargetManager.clear();
        }
        if (lockNearest.get()) {
            lockNearest.set(false);
            LivingEntity n = TargetManager.nearest(mc, range.get());
            if (n != null) TargetManager.lock(n);
        }

        LivingEntity t = TargetManager.get(mc);
        if (TargetManager.version() != seenVersion) { // kullanici hedefi elle degistirdi
            seenVersion = TargetManager.version();
            searching = false;
        }
        if (t == null && TargetManager.consumeLost() && auto.get()) searching = true;
        if (t == null && searching && ++tick % 10 == 0) {
            LivingEntity n = TargetManager.nearest(mc, range.get());
            if (n != null) {
                TargetManager.autoLock(n);
                searching = false;
                t = n;
            }
        }
        text = t == null ? "Target: none" : "Target: " + t.getName().getString();
    }

    @Override
    protected void onDisable() {
        searching = false;
    }

    @Override
    public void onHud(DrawContext ctx, int w, int h) {
        if (showName.get()) Draw.label(ctx, mc.textRenderer, text, px(), py());
    }
}
